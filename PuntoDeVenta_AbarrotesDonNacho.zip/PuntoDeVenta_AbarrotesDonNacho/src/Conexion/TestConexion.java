package Conexion;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.SQLException;

public class TestConexion {
    public static void testConnection() {
        try {
            Connection conn = ConexionBD.getConnection();
            DatabaseMetaData metaData = conn.getMetaData();
            System.out.println("Conexión exitosa a la base de datos!");
            System.out.println("Driver: " + metaData.getDriverName());
            System.out.println("Versión: " + metaData.getDriverVersion());
            conn.close();
        } catch (SQLException e) {
            System.out.println("Error de conexión: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        testConnection();
    }
}
