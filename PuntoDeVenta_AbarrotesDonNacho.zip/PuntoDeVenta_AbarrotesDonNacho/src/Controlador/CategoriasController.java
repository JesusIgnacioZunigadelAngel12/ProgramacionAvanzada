package Controlador;

import Modelo.CategoriaModel;
import Vista.CategoriasView;

import javax.swing.*;
import java.awt.event.ActionEvent;

public class CategoriasController {
    private CategoriaModel model;
    private CategoriasView view;

    public CategoriasController(CategoriaModel model, CategoriasView view) {
        this.model = model;
        this.view = view;

        // Cargar datos iniciales
        cargarCategorias();

        // Acciones
        view.getBtnAgregar().addActionListener(this::agregarCategoria);
        view.getBtnEditar().addActionListener(this::editarCategoria);
        view.getBtnEliminar().addActionListener(this::eliminarCategoria);
        view.getBtnSalir().addActionListener(e -> view.dispose());
    }

    private void cargarCategorias() {
        view.getModeloLista().clear();
        for (String categoria : model.getCategorias()) {
            view.getModeloLista().addElement(categoria);
        }
    }

    private void agregarCategoria(ActionEvent e) {
        String categoria = view.getTxtCategoria().getText().trim();
        if (categoria.isEmpty()) {
            view.mostrarError("Ingrese una categoría válida");
            return;
        }
        if (model.existeCategoria(categoria)) {
            view.mostrarError("La categoría ya existe");
            return;
        }
        model.agregarCategoria(categoria);
        view.getTxtCategoria().setText("");
        cargarCategorias();
        view.mostrarMensaje("Categoría agregada correctamente", "Éxito");
    }

    private void editarCategoria(ActionEvent e) {
        String seleccionada = view.getListaCategorias().getSelectedValue();
        if (seleccionada == null) {
            view.mostrarError("Seleccione una categoría para editar");
            return;
        }
        String nueva = view.pedirNuevoValor("Ingrese el nuevo nombre para la categoría:");
        if (nueva == null || nueva.trim().isEmpty()) return;
        if (model.existeCategoria(nueva)) {
            view.mostrarError("Ya existe una categoría con ese nombre");
            return;
        }
        model.actualizarCategoria(seleccionada, nueva);
        cargarCategorias();
        view.mostrarMensaje("Categoría actualizada correctamente", "Éxito");
    }

    private void eliminarCategoria(ActionEvent e) {
        String seleccionada = view.getListaCategorias().getSelectedValue();
        if (seleccionada == null) {
            view.mostrarError("Seleccione una categoría para eliminar");
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(view, "¿Está seguro de eliminar esta categoría?", "Confirmar eliminación", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            model.eliminarCategoria(seleccionada);
            cargarCategorias();
            view.mostrarMensaje("Categoría eliminada correctamente", "Éxito");
        }
    }
}