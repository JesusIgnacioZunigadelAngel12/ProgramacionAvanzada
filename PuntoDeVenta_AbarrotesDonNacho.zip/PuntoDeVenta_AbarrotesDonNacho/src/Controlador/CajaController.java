package Controlador;

import Modelo.CajaModel;
import Vista.CajaView;
import Vista.MainMenuView;
import java.awt.event.ActionEvent;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.JOptionPane;

public class CajaController {
    private final CajaModel model;
    private final CajaView view;

    public CajaController(CajaModel model, CajaView view) {
        this.model = model;
        this.view = view;
        configurarListeners();
        actualizarEstado();
    }

    private void configurarListeners() {
        view.setAbrirListener(this::abrirCaja);
        view.setCerrarListener(this::cerrarCaja);
        view.setDepositoListener(e -> registrarMovimiento("DEPOSITO"));
        view.setRetiroListener(e -> registrarMovimiento("RETIRO"));
        view.setHistorialListener(this::mostrarHistorial);
        view.setSalirListener(e -> view.dispose());
    }

    private void abrirCaja(ActionEvent e) {
        try {
            String montoStr = view.pedirMonto("Ingrese monto inicial de caja:");
            if (montoStr == null || montoStr.trim().isEmpty()) {
                view.mostrarError("Debe ingresar un monto válido");
                return;
            }
            double monto = Double.parseDouble(montoStr);
            String usuario = MainMenuView.getInstance().getUsuarioActivo();
            model.abrirCaja(monto, usuario);
            view.mostrarMensaje("Caja abierta correctamente", "Éxito");
            actualizarEstado();
        } catch (NumberFormatException ex) {
            view.mostrarError("El monto debe ser un número válido");
        } catch (IllegalStateException ex) {
            view.mostrarError(ex.getMessage());
        } catch (SQLException ex) {
            view.mostrarError("Error en base de datos: " + ex.getMessage());
        }
    }

    private void cerrarCaja(ActionEvent e) {
        try {
            double saldo = model.getSaldoActual();
            int confirm = view.confirmarCierre("¿Cerrar caja? Saldo actual: $" + saldo);
            if (confirm == JOptionPane.YES_OPTION) {
                String usuario = MainMenuView.getInstance().getUsuarioActivo();
                model.cerrarCaja(usuario);
                view.mostrarMensaje("Caja cerrada correctamente. Saldo final: $" + saldo, "Éxito");
                actualizarEstado();
            }
        } catch (SQLException ex) {
            view.mostrarError("Error al cerrar caja: " + ex.getMessage());
        }
    }

    private void registrarMovimiento(String tipo) {
        String montoStr = view.pedirMonto("Ingrese monto a " + tipo.toLowerCase() + ":");
        if (montoStr == null || montoStr.trim().isEmpty()) {
            view.mostrarError("Debe ingresar un monto válido");
            return;
        }
        try {
            double monto = Double.parseDouble(montoStr);
            String usuario = MainMenuView.getInstance().getUsuarioActivo();
            model.registrarMovimiento(tipo, monto, usuario);
            String mensaje = tipo.equals("DEPOSITO") 
                ? "Depósito registrado correctamente"
                : "Retiro registrado correctamente";
            view.mostrarMensaje(mensaje, "Éxito");
            actualizarEstado();
        } catch (NumberFormatException ex) {
            view.mostrarError("El monto debe ser un número válido");
        } catch (IllegalArgumentException ex) {
            view.mostrarError(ex.getMessage());
        } catch (SQLException ex) {
            view.mostrarError("Error al registrar movimiento: " + ex.getMessage());
        }
    }

    private void mostrarHistorial(ActionEvent e) {
        try {
            String historial = model.obtenerHistorialDelDia();
            view.mostrarHistorial(historial);
        } catch (SQLException ex) {
            view.mostrarError("Error al obtener historial: " + ex.getMessage());
        }
    }

    private void actualizarEstado() {
        try {
            boolean cajaAbierta = model.isCajaAbierta();
            double saldo = cajaAbierta ? model.getSaldoActual() : 0;
            String hora = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));
            String infoAdicional = "";
            if (cajaAbierta) {
                infoAdicional = model.obtenerInfoApertura();
            }
            view.actualizarInterfaz(saldo, cajaAbierta, hora, infoAdicional);
            view.actualizarEstadoBotones(cajaAbierta, model.tieneMovimientosHoy());
        } catch (SQLException ex) {
            view.mostrarError("Error al actualizar estado: " + ex.getMessage());
        }
    }
}