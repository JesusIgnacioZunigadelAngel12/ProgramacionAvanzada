package Controlador;

import Modelo.*;
import Vista.*;

import java.awt.event.ActionEvent;
import java.sql.SQLException;

public class MainController {
    private final CajaModel cajaModel;
    private final ProductoModel productoModel;
    private final VentaModel ventaModel;
    private final UsuarioModel usuarioModel;
    private final ClienteModel clienteModel;
    private final CategoriaModel categoriaModel;
    private final ProveedorModel proveedorModel;

    public MainController(MainMenuView view) throws SQLException {
        // Inicializa los modelos
        this.cajaModel = new CajaModel();
        this.productoModel = new ProductoModel();
        this.ventaModel = new VentaModel();
        this.clienteModel = new ClienteModel();
        this.proveedorModel = new ProveedorModel();
        this.categoriaModel = new CategoriaModel();
        this.usuarioModel = new UsuarioModel();
        
        // Configura los listeners
        view.getItemPuntoVenta().addActionListener(e -> abrirPuntoVenta());
        view.getItemProveedores().addActionListener(e -> abrirProveedores());
        view.getItemClientes().addActionListener(e -> abrirClientes());
        view.getItemReportes().addActionListener(e -> {
			try {
				abrirReportes();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		});
        view.getItemProductos().addActionListener(e -> abrirAdministracionProductos());
        view.getItemCaja().addActionListener(e -> abrirCaja());
        view.getItemCategorias().addActionListener(e -> abrirCategorias());
        view.getItemUsuarios().addActionListener(e -> abrirUsuarios());
        view.getItemSalir().addActionListener(e -> System.exit(0));
    }

    private void abrirPuntoVenta() {
        PuntoVentaView puntoVentaView = new PuntoVentaView();
        new PuntoVentaController(productoModel, ventaModel, puntoVentaView, clienteModel, cajaModel); // Pasar ventaModel
        puntoVentaView.setVisible(true);
    }

    private void abrirProveedores() {
        ProveedoresView proveedoresView = new ProveedoresView();
        new ProveedoresController(proveedorModel, proveedoresView);
        proveedoresView.setVisible(true);
    }

    private void abrirClientes() {
        ClientesView clientesView = new ClientesView();
        new ClientesController(clienteModel, clientesView);
        clientesView.setVisible(true);
    }

    private void abrirReportes() throws SQLException {
        ReportesView reportesView = new ReportesView();
        new ReportesController(reportesView, ventaModel, cajaModel);
        reportesView.setVisible(true);
    }

    private void abrirAdministracionProductos() {
        AdministracionProductosView adminView = new AdministracionProductosView();
        new AdministracionProductosController(productoModel, categoriaModel, adminView);
        adminView.setVisible(true);
    }

    private void abrirCaja() {
        CajaView cajaView = new CajaView();
        new CajaController(cajaModel, cajaView);
        cajaView.setVisible(true);
    }
    
    private void abrirCategorias() {
        CategoriasView categoriasView = new CategoriasView(MainMenuView.getInstance());
        new CategoriasController(categoriaModel, categoriasView);
        categoriasView.setVisible(true);
    }
    
    private void abrirUsuarios() {
        UsuariosView usuariosView = new UsuariosView();
        new UsuariosController(usuarioModel, usuariosView);
        usuariosView.setVisible(true);
    }
}