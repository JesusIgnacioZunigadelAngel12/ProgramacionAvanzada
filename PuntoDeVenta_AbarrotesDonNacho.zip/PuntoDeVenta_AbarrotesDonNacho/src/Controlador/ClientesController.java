package Controlador;

import Modelo.ClienteModel;
import Vista.ClientesView;
import javax.swing.*;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.sql.SQLException;
import java.util.List;

public class ClientesController {

    private final ClienteModel model;
    private final ClientesView view;

    public ClientesController(ClienteModel model, ClientesView view) {
        this.model = model;
        this.view = view;

        view.getBtnNuevo().addActionListener(this::nuevoCliente);
        view.getBtnBuscar().addActionListener(e -> buscarClientes());
        view.getBtnEditar().addActionListener(this::editarCliente);
        view.getBtnEliminar().addActionListener(this::eliminarCliente);
        view.getBtnSalir().addActionListener(e -> view.dispose());
        view.getBtnLimpiar().addActionListener(e -> limpiarBusqueda());


        cargarClientes();
    }

    private void cargarClientes() {
        try {
            List<ClienteModel.Cliente> clientes = model.getTodosClientes();
            Object[][] datos = convertirAArray(clientes);
            view.cargarClientes(datos);
        } catch (SQLException ex) {
            view.mostrarError("Error al cargar clientes: " + ex.getMessage());
        }
    }

    private Object[][] convertirAArray(List<ClienteModel.Cliente> clientes) {
        Object[][] datos = new Object[clientes.size()][4];
        int i = 0;
        for (ClienteModel.Cliente c : clientes) {
            datos[i][0] = c.getId();
            datos[i][1] = c.getNombre();
            datos[i][2] = c.getTelefono();
            datos[i][3] = c.getCorreoElectronico();
            i++;
        }
        return datos;
    }

    private void nuevoCliente(ActionEvent e) {
        try {
            // Obtener cantidad total de clientes
            int totalClientes = model.getTodosClientes().size();

            // Generar la nueva ID: C001, C002, etc.
            String nuevaId = String.format("C%03d", totalClientes + 1);

            // Campos para el diálogo
            JTextField txtNombre = new JTextField();
            JTextField txtTelefono = new JTextField();
            JTextField txtCorreo = new JTextField();

            JPanel panel = new JPanel(new GridLayout(3, 2, 10, 10));
            panel.add(new JLabel("Nombre:"));
            panel.add(txtNombre);
            panel.add(new JLabel("Teléfono:"));
            panel.add(txtTelefono);
            panel.add(new JLabel("Correo Electrónico:"));
            panel.add(txtCorreo);

            int result = JOptionPane.showConfirmDialog(
                    view,
                    panel,
                    "Nuevo Cliente",
                    JOptionPane.OK_CANCEL_OPTION
            );

            if (result == JOptionPane.OK_OPTION) {
                String nombre = txtNombre.getText().trim();
                String telefono = txtTelefono.getText().trim();
                String correo = txtCorreo.getText().trim();

                if (nombre.isEmpty()) {
                    view.mostrarError("El nombre del cliente es obligatorio.");
                    return;
                }

                // Crear el nuevo cliente con la ID generada
                ClienteModel.Cliente nuevoCliente = new ClienteModel.Cliente(
                        nuevaId,
                        nombre,
                        telefono,
                        correo
                );

                model.agregarCliente(nuevoCliente);
                cargarClientes(); // Refrescar tabla
                view.mostrarMensaje("Cliente agregado correctamente con ID: " + nuevaId, "Éxito");
            }
        } catch (SQLException ex) {
            view.mostrarError("Error al guardar cliente: " + ex.getMessage());
        }
    }

    private void buscarClientes() {
    	 String busqueda = view.obtenerBusqueda();
    	    
    	    if (busqueda != null && !busqueda.trim().isEmpty()) {
    	        try {
    	            List<ClienteModel.Cliente> resultados = model.buscarClientes(busqueda);
    	            
    	            if (resultados.isEmpty()) {
    	                view.mostrarMensaje("No se encontraron clientes", "Resultados de búsqueda");
    	                cargarClientes(); // Mostrar todos los clientes si no hay coincidencias
    	            } else {
    	                // Convertir resultados a matriz para la tabla
    	                Object[][] datos = new Object[resultados.size()][3];
    	                int i = 0;
    	                for (ClienteModel.Cliente c : resultados) {
    	                    datos[i][0] = c.getId();
    	                    datos[i][1] = c.getNombre();
    	                    datos[i][2] = c.getTelefono();
    	                    i++;
    	                }
    	                view.cargarClientes(datos); // Actualiza la vista con los resultados
    	            }
    	        } catch (SQLException ex) {
    	            view.mostrarError("Error al buscar clientes: " + ex.getMessage());
    	        }
    	    } else {
    	        // Si el campo de búsqueda está vacío, mostrar todos los clientes
    	        cargarClientes();
    	    }
    }
    
    private void limpiarBusqueda() {
        view.limpiarBusqueda();
        cargarClientes();
    }

    private void editarCliente(ActionEvent e) {
        int filaSeleccionada = view.getFilaSeleccionada();
        if (filaSeleccionada >= 0) {
            String idCliente = (String) view.modeloTabla.getValueAt(filaSeleccionada, 0);
            try {
                ClienteModel.Cliente cliente = model.buscarClientePorId(idCliente);
                if (cliente != null) {
                    JTextField txtNombre = new JTextField(cliente.getNombre());
                    JTextField txtTelefono = new JTextField(cliente.getTelefono());
                    JTextField txtCorreo = new JTextField(cliente.getCorreoElectronico());

                    JPanel panel = new JPanel(new GridLayout(3, 2));
                    panel.add(new JLabel("Nombre:"));
                    panel.add(txtNombre);
                    panel.add(new JLabel("Teléfono:"));
                    panel.add(txtTelefono);
                    panel.add(new JLabel("Correo Electrónico:"));
                    panel.add(txtCorreo);

                    int result = JOptionPane.showConfirmDialog(view, panel, "Editar Cliente", JOptionPane.OK_CANCEL_OPTION);
                    if (result == JOptionPane.OK_OPTION) {
                        cliente.setNombre(txtNombre.getText());
                        cliente.setTelefono(txtTelefono.getText());
                        cliente.setCorreoElectronico(txtCorreo.getText());
                        model.actualizarCliente(cliente);
                        cargarClientes();
                        view.mostrarMensaje("Cliente actualizado correctamente", "Éxito");
                    }
                }
            } catch (SQLException ex) {
                view.mostrarError("Error al editar cliente: " + ex.getMessage());
            }
        } else {
            view.mostrarError("Seleccione un cliente para editar");
        }
    }

    private void eliminarCliente(ActionEvent e) {
        int filaSeleccionada = view.getFilaSeleccionada();
        if (filaSeleccionada >= 0) {
            String idCliente = (String) view.modeloTabla.getValueAt(filaSeleccionada, 0);
            int confirm = JOptionPane.showConfirmDialog(
                view,
                "¿Está seguro de eliminar este cliente?",
                "Confirmar Eliminación",
                JOptionPane.YES_NO_OPTION
            );
            if (confirm == JOptionPane.YES_OPTION) {
                try {
                    model.eliminarCliente(idCliente);
                    cargarClientes();
                    view.mostrarMensaje("Cliente eliminado correctamente", "Éxito");
                } catch (SQLException ex) {
                    view.mostrarError("Error al eliminar cliente: " + ex.getMessage());
                }
            }
        } else {
            view.mostrarError("Seleccione un cliente para eliminar");
        }
    }
}