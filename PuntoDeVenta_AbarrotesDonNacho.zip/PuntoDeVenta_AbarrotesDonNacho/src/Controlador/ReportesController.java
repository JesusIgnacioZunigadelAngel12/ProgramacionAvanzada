
package Controlador;

import Modelo.CajaModel;
import Modelo.VentaModel;
import Modelo.VentaModel.ProductoVendido;
import Vista.MainMenuView;
import Vista.ReportesView;

import java.awt.Color;
import java.awt.Desktop;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.util.List;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.font.Standard14Fonts;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.SQLException;

public class ReportesController {
    private ReportesView view;
    private VentaModel ventaModel;
    private CajaModel cajaModel;

    public ReportesController(ReportesView view, VentaModel ventaModel, CajaModel cajaModel) throws SQLException {
        this.view = view;
        this.ventaModel = ventaModel;
        this.cajaModel = cajaModel;
        
        view.getBtnVentasDiarias().addActionListener(this::generarReporteVentasDiarias);
        view.getBtnProductosVendidos().addActionListener(this::generarReporteProductosVendidos);
        view.getBtnMovimientosCaja().addActionListener(this::generarReporteMovimientosCaja);
        view.getBtnExportar().addActionListener(this::exportarReporte);
        view.getBtnSalir().addActionListener(e -> view.dispose());
    }

    private void generarReporteVentasDiarias(ActionEvent e) {
        // Usamos LocalDate.now() directamente, sin formatear como String
        LocalDate fechaHoy = LocalDate.now();

        try {
            // Ahora pasamos LocalDate, no String
            List<VentaModel.Venta> ventasHoy = ventaModel.getVentasPorFecha(fechaHoy);

            if (ventasHoy.isEmpty()) {
                view.mostrarMensaje("No hay ventas registradas hoy", "Ventas Diarias");
                return;
            }

            StringBuilder reporte = new StringBuilder();
            reporte.append("REPORTE DE VENTAS DIARIAS - ")
                   .append(fechaHoy.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))) // Formato solo para mostrar
                   .append("\n")
                   .append(String.format("%-8s %-10s %-15s %-15s %-15s\n",
                           "Folio", "Hora", "Total", "Método Pago", "Atendió"));

            double totalDia = 0;

            for (VentaModel.Venta v : ventasHoy) {
                // Formatear la hora
                String horaFormateada = v.getHora().substring(0, 5); // Tomar solo las primeras 5 posiciones (HH:mm)

                // Obtener el nombre del usuario actual
                String atendio = MainMenuView.getInstance().getUsuarioActivo(); // Nombre del usuario activo

                reporte.append(String.format("%-8s %-10s $%-15.2f %-15s %-15s\n",
                        v.getFolio(), horaFormateada, v.getTotal(), v.getMetodoPago(), atendio));
                totalDia += v.getTotal();
            }

            reporte.append("TOTAL DEL DÍA: $").append(String.format("%.2f", totalDia));

            view.mostrarReporte(reporte.toString(), "Ventas Diarias");

        } catch (SQLException ex) {
            view.mostrarError("Error al generar reporte de ventas diarias: " + ex.getMessage());
        }
    }

    private void generarReporteProductosVendidos(ActionEvent e) {
        JPanel panelFechas = new JPanel(new GridLayout(2, 2));
        JTextField txtDesde = new JTextField();
        JTextField txtHasta = new JTextField();

        panelFechas.add(new JLabel("Desde:"));
        panelFechas.add(txtDesde);
        panelFechas.add(new JLabel("Hasta:"));
        panelFechas.add(txtHasta);

        int opcion = JOptionPane.showConfirmDialog(view, panelFechas, "Seleccionar Rango de Fechas", JOptionPane.OK_CANCEL_OPTION);

        if (opcion == JOptionPane.OK_OPTION) {
            String desde = txtDesde.getText();
            String hasta = txtHasta.getText();

            try {
                Map<String, Integer> productos = ventaModel.getProductosMasVendidos(desde, hasta);

                if (productos.isEmpty()) {
                    view.mostrarMensaje("No hay ventas en el período seleccionado", "Productos Más Vendidos");
                    return;
                }

                StringBuilder reporte = new StringBuilder();
                reporte.append("PRODUCTOS MÁS VENDIDOS\n");
                reporte.append("Período: ").append(desde).append(" a ").append(hasta).append("\n");
                reporte.append(String.format("%-30s %-10s\n", "Producto", "Cantidad"));

                productos.forEach((nombre, cantidad) -> {
                    reporte.append(String.format("%-30s %-10d\n", nombre, cantidad));
                });

                view.mostrarReporte(reporte.toString(), "Productos Más Vendidos");

            } catch (SQLException ex) {
                view.mostrarError("Error al generar reporte de productos más vendidos: " + ex.getMessage());
            }
        }
    }

    private void generarReporteMovimientosCaja(ActionEvent e) {
        try {
            List<String> movimientos = cajaModel.getMovimientosDelDia();

            if (movimientos.isEmpty()) {
                view.mostrarMensaje("No hay movimientos de caja registrados", "Movimientos de Caja");
                return;
            }

            StringBuilder reporte = new StringBuilder();
            reporte.append("MOVIMIENTOS DE CAJA\n");

            for (String movimiento : movimientos) {
                reporte.append("- ").append(movimiento).append("\n");
            }

            reporte.append("SALDO ACTUAL: $").append(String.format("%.2f", cajaModel.getSaldoActual()));
            view.mostrarReporte(reporte.toString(), "Movimientos de Caja");

        } catch (SQLException ex) {
            view.mostrarError("Error al generar reporte de movimientos de caja: " + ex.getMessage());
        }
    }
    
    private void exportarReporte(ActionEvent e) {
        try (PDDocument document = new PDDocument()) {
            PDPage page = new PDPage();
            document.addPage(page);

            // Configuración inicial
            float margin = 50;
            float leading = 16;
            float yPosition = page.getMediaBox().getHeight() - margin;

            PDType1Font fontBold = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
            PDType1Font fontRegular = new PDType1Font(Standard14Fonts.FontName.HELVETICA);

            PDPageContentStream contentStream = new PDPageContentStream(document, page);

            // Título centrado
            String titulo = "Abarrotes Don Nacho";
            float titleWidth = fontBold.getStringWidth(titulo) / 1000 * 18;
            contentStream.setFont(fontBold, 18);
            contentStream.beginText();
            contentStream.newLineAtOffset((page.getMediaBox().getWidth() - titleWidth) / 2, yPosition);
            contentStream.showText(titulo);
            contentStream.endText();

            yPosition -= leading * 2;

            // Subtítulo: Información del reporte
            contentStream.setFont(fontBold, 14);
            contentStream.beginText();
            contentStream.newLineAtOffset(margin, yPosition);
            contentStream.showText("Reporte Consolidado de Ventas");
            contentStream.endText();
            yPosition -= leading;

            // Fecha del reporte
            LocalDate fechaHoy = LocalDate.now();
            String fechaActual = fechaHoy.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
            contentStream.setFont(fontRegular, 12);
            contentStream.beginText();
            contentStream.newLineAtOffset(margin, yPosition);
            contentStream.showText("Fecha del reporte: " + fechaActual);
            contentStream.endText();
            yPosition -= leading;

            // Nombre de quien generó el reporte
            String usuarioGenerador = MainMenuView.getInstance().getUsuarioActivo();
            contentStream.setFont(fontRegular, 12);
            contentStream.beginText();
            contentStream.newLineAtOffset(margin, yPosition);
            contentStream.showText("Generado por: " + usuarioGenerador);
            contentStream.endText();
            yPosition -= leading * 2;

            // Línea divisoria
            drawHorizontalLine(contentStream, margin, yPosition, page.getMediaBox().getWidth() - 2 * margin, Color.BLACK, 1f);
            yPosition -= leading;

            // Sección 1: Ventas diarias
            contentStream.setFont(fontBold, 12);
            contentStream.beginText();
            contentStream.newLineAtOffset(margin, yPosition);
            contentStream.showText("VENTAS DIARIAS");
            contentStream.endText();
            yPosition -= leading;

            // CORRECCIÓN: Usar LocalDate en lugar de String
            List<VentaModel.Venta> ventasHoy = ventaModel.getVentasPorFecha(fechaHoy);
            
            if (ventasHoy.isEmpty()) {
                contentStream.setFont(fontRegular, 12);
                contentStream.beginText();
                contentStream.newLineAtOffset(margin, yPosition);
                contentStream.showText("No hay ventas registradas hoy.");
                contentStream.endText();
                yPosition -= leading;
            } else {
                // Encabezados de la tabla
                contentStream.setFont(fontBold, 10);
                contentStream.beginText();
                contentStream.newLineAtOffset(margin, yPosition);
                contentStream.showText(String.format("%-10s %-8s %-10s %-15s %-15s",
                        "Folio", "Hora", "Total", "Método Pago", "Atendió"));
                contentStream.endText();
                yPosition -= leading;

                // Datos de las ventas
                contentStream.setFont(fontRegular, 10);
                for (VentaModel.Venta v : ventasHoy) {
                    String horaFormateada = v.getHora().substring(0, 5);
                    contentStream.beginText();
                    contentStream.newLineAtOffset(margin, yPosition);
                    contentStream.showText(String.format("%-10s %-8s $%-10.2f %-15s %-15s",
                            v.getFolio(), horaFormateada, v.getTotal(), v.getMetodoPago(), v.getAtendio()));
                    contentStream.endText();
                    yPosition -= leading;

                    // Verificar si se necesita una nueva página
                    if (yPosition < margin) {
                        contentStream.close();
                        page = new PDPage();
                        document.addPage(page);
                        contentStream = new PDPageContentStream(document, page);
                        yPosition = page.getMediaBox().getHeight() - margin;
                        contentStream.setFont(fontRegular, 10);
                    }
                }
            }

            // Línea divisoria
            drawHorizontalLine(contentStream, margin, yPosition, page.getMediaBox().getWidth() - 2 * margin, Color.BLACK, 1f);
            yPosition -= leading;

            // Sección 2: Productos más vendidos
            contentStream.setFont(fontBold, 12);
            contentStream.beginText();
            contentStream.newLineAtOffset(margin, yPosition);
            contentStream.showText("PRODUCTOS MÁS VENDIDOS (ÚLTIMO MES)");
            contentStream.endText();
            yPosition -= leading;

            String fechaInicio = LocalDate.now().minusMonths(1).format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            String fechaFin = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            Map<String, Integer> productosMasVendidos = ventaModel.getProductosMasVendidos(fechaInicio, fechaFin);
            
            if (productosMasVendidos.isEmpty()) {
                contentStream.setFont(fontRegular, 12);
                contentStream.beginText();
                contentStream.newLineAtOffset(margin, yPosition);
                contentStream.showText("No hay productos vendidos en el último mes.");
                contentStream.endText();
                yPosition -= leading;
            } else {
                // Encabezados de la tabla
                contentStream.setFont(fontBold, 10);
                contentStream.beginText();
                contentStream.newLineAtOffset(margin, yPosition);
                contentStream.showText(String.format("%-30s %-10s", "Producto", "Cantidad"));
                contentStream.endText();
                yPosition -= leading;

                // Datos de los productos más vendidos
                contentStream.setFont(fontRegular, 10);
                for (Map.Entry<String, Integer> entry : productosMasVendidos.entrySet()) {
                    contentStream.beginText();
                    contentStream.newLineAtOffset(margin, yPosition);
                    contentStream.showText(String.format("%-30s %-10d", entry.getKey(), entry.getValue()));
                    contentStream.endText();
                    yPosition -= leading;

                    // Crear nueva página si no hay espacio
                    if (yPosition < margin) {
                        contentStream.close();
                        page = new PDPage();
                        document.addPage(page);
                        contentStream = new PDPageContentStream(document, page);
                        yPosition = page.getMediaBox().getHeight() - margin;
                        contentStream.setFont(fontRegular, 10);
                    }
                }
            }
            
            drawHorizontalLine(contentStream, margin, yPosition, page.getMediaBox().getWidth() - 2 * margin, Color.BLACK, 1f);
            yPosition -= leading;
            
            // Sección 3: Movimientos de caja
            contentStream.setFont(fontBold, 12);
            contentStream.beginText();
            contentStream.newLineAtOffset(margin, yPosition);
            contentStream.showText("MOVIMIENTOS DE CAJA");
            contentStream.endText();
            yPosition -= leading;

            List<String> movimientosCaja = cajaModel.getMovimientosDelDia();
            if (movimientosCaja.isEmpty()) {
                contentStream.setFont(fontRegular, 12);
                contentStream.beginText();
                contentStream.newLineAtOffset(margin, yPosition);
                contentStream.showText("No hay movimientos de caja registrados hoy.");
                contentStream.endText();
                yPosition -= leading;
            } else {
                contentStream.setFont(fontRegular, 10);
                for (String movimiento : movimientosCaja) {
                    contentStream.beginText();
                    contentStream.newLineAtOffset(margin, yPosition);
                    contentStream.showText("- " + movimiento);
                    contentStream.endText();
                    yPosition -= leading;

                    // Verificar si se necesita una nueva página
                    if (yPosition < margin) {
                        contentStream.close();
                        page = new PDPage();
                        document.addPage(page);
                        contentStream = new PDPageContentStream(document, page);
                        yPosition = page.getMediaBox().getHeight() - margin;
                        contentStream.setFont(fontRegular, 10);
                    }
                }
            }

            // Pie de página
            contentStream.setFont(fontRegular, 10);
            contentStream.beginText();
            contentStream.newLineAtOffset(margin, 30);
            contentStream.showText("Reporte generado automáticamente por Abarrotes Don Nacho - " +
                    LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss")));
            contentStream.endText();

            contentStream.close();

            // Guardar el documento
            String nombreArchivo = "reporte_abarrotes_" + LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) + ".pdf";
            document.save(nombreArchivo);
            view.mostrarMensaje("Reporte generado exitosamente: " + nombreArchivo, "Éxito");

            // Abrir el archivo automáticamente (opcional)
            if (Desktop.isDesktopSupported()) {
                Desktop.getDesktop().open(new File(nombreArchivo));
            }

        } catch (IOException | SQLException ex) {
            view.mostrarError("Error al generar el reporte: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    // Métodos auxiliares (deben estar en la misma clase)
    private void drawHorizontalLine(PDPageContentStream contentStream, float x, float y, float length, Color color, float thickness) throws IOException {
        contentStream.setLineWidth(thickness);
        contentStream.setStrokingColor(color);
        contentStream.moveTo(x, y);
        contentStream.lineTo(x + length, y);
        contentStream.stroke();
    }

    private float calculateOffset(float[] columnWidths, int columnIndex) {
        float offset = 0;
        for (int i = 0; i < columnIndex; i++) {
            offset += columnWidths[i];
        }
        return offset;
    }
   
    // Métodos auxiliares
    private void addSectionTitle(PDPageContentStream contentStream, String title, float margin, float yPosition, PDType1Font font, float fontSize) throws IOException {
        contentStream.setFont(font, fontSize);
        contentStream.beginText();
        contentStream.newLineAtOffset(margin, yPosition);
        contentStream.showText(title);
        contentStream.endText();
    }

    private PDPageContentStream addTextLine(PDPageContentStream contentStream, PDDocument document, PDPage page, String text, float margin, float yPosition, PDType1Font font, float fontSize) throws IOException {
        // Verificar si necesitamos nueva página
        if (yPosition < 100) {
            contentStream.endText();
            contentStream.close();
            page = new PDPage();
            document.addPage(page);
            contentStream = new PDPageContentStream(document, page);
            yPosition = page.getMediaBox().getHeight() - margin;
        }
        
        contentStream.setFont(font, fontSize);
        contentStream.beginText();
        contentStream.newLineAtOffset(margin, yPosition);
        contentStream.showText(text);
        contentStream.endText();
        
        return contentStream;
    }
}