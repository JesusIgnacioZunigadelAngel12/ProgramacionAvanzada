package Controlador;

import Modelo.CajaModel;
import Modelo.VentaModel;
import Modelo.VentaModel.ProductoVendido;
import Vista.MainMenuView;
import Vista.ReportesView;
import Vista.PdfToImageRenderer;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.util.List;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.font.Standard14Fonts;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.SQLException;

public class ReportesController {
    private ReportesView view;
    private VentaModel ventaModel;
    private CajaModel cajaModel;
    private byte[] currentPdfBytes;

    public ReportesController(ReportesView view, VentaModel ventaModel, CajaModel cajaModel) throws SQLException {
        this.view = view;
        this.ventaModel = ventaModel;
        this.cajaModel = cajaModel;
        view.getBtnVentasDiarias().addActionListener(this::generarReporteVentasDiarias);
        view.getBtnProductosVendidos().addActionListener(this::generarReporteProductosVendidos);
        view.getBtnMovimientosCaja().addActionListener(this::generarReporteMovimientosCaja);
        view.getBtnSalir().addActionListener(e -> view.dispose());
    }

    private void generarReporteVentasDiarias(ActionEvent e) {
        LocalDate fechaHoy = LocalDate.now();
        try {
            List<VentaModel.Venta> ventasHoy = ventaModel.getVentasPorFecha(fechaHoy);
            if (ventasHoy.isEmpty()) {
                view.mostrarMensaje("No hay ventas registradas hoy", "Ventas Diarias");
                return;
            }
            // Generar el PDF en memoria
            ByteArrayOutputStream pdfOutputStream = new ByteArrayOutputStream();
            generarReportePDF(ventasHoy, null, null, pdfOutputStream);
            currentPdfBytes = pdfOutputStream.toByteArray();
            // Mostrar vista previa
            mostrarVistaPrevia(currentPdfBytes);
        } catch (SQLException | IOException ex) {
            view.mostrarError("Error al generar reporte: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    private void generarReporteProductosVendidos(ActionEvent e) {
        try {
            String fechaDesde = view.getFechaDesde();
            String fechaHasta = view.getFechaHasta();
            if (!validarFormatoFecha(fechaDesde) || !validarFormatoFecha(fechaHasta)) {
                view.mostrarError("Formato de fecha incorrecto. Debe ser YYYY-MM-DD.");
                return;
            }
            Map<String, Integer> productosMasVendidos = ventaModel.getProductosMasVendidos(fechaDesde, fechaHasta);
            if (productosMasVendidos.isEmpty()) {
                view.mostrarMensaje("No hay productos vendidos en el rango seleccionado.", "Informe de Productos Más Vendidos");
                return;
            }
            // Generar el PDF en memoria
            ByteArrayOutputStream pdfOutputStream = new ByteArrayOutputStream();
            generarReportePDF(null, productosMasVendidos, null, pdfOutputStream);
            currentPdfBytes = pdfOutputStream.toByteArray();
            // Mostrar vista previa
            mostrarVistaPrevia(currentPdfBytes);
        } catch (SQLException | IOException ex) {
            view.mostrarError("Error al generar reporte: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    private void generarReporteMovimientosCaja(ActionEvent e) {
        try {
            List<String> movimientos = cajaModel.getMovimientosDelDia();
            if (movimientos.isEmpty()) {
                view.mostrarMensaje("No hay movimientos de caja registrados", "Movimientos de Caja");
                return;
            }
            // Generar el PDF en memoria
            ByteArrayOutputStream pdfOutputStream = new ByteArrayOutputStream();
            generarReportePDF(null, null, movimientos, pdfOutputStream);
            currentPdfBytes = pdfOutputStream.toByteArray();
            // Mostrar vista previa
            mostrarVistaPrevia(currentPdfBytes);
        } catch (SQLException | IOException ex) {
            view.mostrarError("Error al generar reporte: " + ex.getMessage());
            ex.printStackTrace();
        }
    }



    private void mostrarVistaPrevia(byte[] pdfBytes) {
        PdfToImageRenderer preview = new PdfToImageRenderer(view, pdfBytes);
        preview.setVisible(true);
    }

    private void generarReportePDF(List<VentaModel.Venta> ventas,
                                   Map<String, Integer> productosVendidos,
                                   List<String> movimientosCaja,
                                   OutputStream outputStream) throws IOException {
        PDDocument document = new PDDocument();
        try {
            PDPage page = new PDPage(PDRectangle.A4);
            document.addPage(page);

            PDType1Font fontBold = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
            PDType1Font fontRegular = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
            float margin = 50;
            float yPosition = page.getMediaBox().getHeight() - margin;
            float lineHeight = 14;
            float smallLineHeight = 12;

            PDPageContentStream contentStream = new PDPageContentStream(document, page);
            try {
                // --- ENCABEZADO ---
                contentStream.setFont(fontBold, 18);
                drawCenteredText(contentStream, "ABARROTES DON NACHO", page.getMediaBox().getWidth()/2, yPosition, fontBold, 18);
                yPosition -= lineHeight * 1.5f;
                contentStream.setFont(fontRegular, 12);
                drawCenteredText(contentStream, "Reporte de Ventas y Movimientos", page.getMediaBox().getWidth()/2, yPosition, fontRegular, 12);
                yPosition -= lineHeight;
                String fechaReporte = LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                drawCenteredText(contentStream, "Fecha: " + fechaReporte, page.getMediaBox().getWidth()/2, yPosition, fontRegular, 12);
                yPosition -= lineHeight * 1.5f;
                drawLine(contentStream, margin, yPosition, page.getMediaBox().getWidth() - 2 * margin);
                yPosition -= lineHeight;

                // --- SECCIÓN DE VENTAS DIARIAS ---
                if (ventas != null && !ventas.isEmpty()) {
                    contentStream.setFont(fontBold, 14);
                    contentStream.beginText();
                    contentStream.newLineAtOffset(margin, yPosition);
                    contentStream.showText("VENTAS DIARIAS");
                    contentStream.endText();
                    yPosition -= lineHeight;

                    float[] columnWidths = {80, 60, 80, 100, 80};
                    drawTableRow(contentStream, margin, yPosition, columnWidths,
                            new String[]{"Folio", "Hora", "Total", "Método Pago", "Atendió"},
                            fontBold, 10);
                    yPosition -= lineHeight;
                    drawLine(contentStream, margin, yPosition, page.getMediaBox().getWidth() - 2 * margin, 0.5f);
                    yPosition -= smallLineHeight;

                    contentStream.setFont(fontRegular, 10);
                    double totalDia = 0;
                    for (VentaModel.Venta v : ventas) {
                        String horaFormateada = v.getHora().substring(0, 5);
                        drawTableRow(contentStream, margin, yPosition, columnWidths,
                                new String[]{
                                        v.getFolio(),
                                        horaFormateada,
                                        String.format("$%.2f", v.getTotal()),
                                        v.getMetodoPago(),
                                        v.getAtendio()
                                },
                                fontRegular, 10);
                        yPosition -= smallLineHeight;
                        totalDia += v.getTotal();

                        if (yPosition < margin + 100) {
                            contentStream.close();
                            page = new PDPage(PDRectangle.A4);
                            document.addPage(page);
                            contentStream = new PDPageContentStream(document, page);
                            yPosition = page.getMediaBox().getHeight() - margin;
                            contentStream.setFont(fontRegular, 10);
                        }
                    }

                    drawLine(contentStream, margin, yPosition, page.getMediaBox().getWidth() - 2 * margin, 0.5f);
                    yPosition -= smallLineHeight;
                    contentStream.setFont(fontBold, 12);
                    drawRightAlignedText(contentStream, "TOTAL DEL DÍA:", margin + 300, yPosition, fontBold, 12);
                    drawRightAlignedText(contentStream, String.format("$%.2f", totalDia), margin + 380, yPosition, fontBold, 12);
                    yPosition -= lineHeight * 1.5f;
                }

                // --- SECCIÓN DE PRODUCTOS MÁS VENDIDOS ---
                if (productosVendidos != null && !productosVendidos.isEmpty()) {
                    contentStream.setFont(fontBold, 14);
                    contentStream.beginText();
                    contentStream.newLineAtOffset(margin, yPosition);
                    contentStream.showText("PRODUCTOS MÁS VENDIDOS");
                    contentStream.endText();
                    yPosition -= lineHeight;

                    float[] columnWidths = {250, 80};
                    drawTableRow(contentStream, margin, yPosition, columnWidths,
                            new String[]{"Producto", "Cantidad"},
                            fontBold, 10);
                    yPosition -= lineHeight;
                    drawLine(contentStream, margin, yPosition, page.getMediaBox().getWidth() - 2 * margin, 0.5f);
                    yPosition -= smallLineHeight;

                    contentStream.setFont(fontRegular, 10);
                    for (Map.Entry<String, Integer> entry : productosVendidos.entrySet()) {
                        drawTableRow(contentStream, margin, yPosition, columnWidths,
                                new String[]{
                                        entry.getKey(),
                                        String.valueOf(entry.getValue())
                                },
                                fontRegular, 10);
                        yPosition -= smallLineHeight;

                        if (yPosition < margin + 100) {
                            contentStream.close();
                            page = new PDPage(PDRectangle.A4);
                            document.addPage(page);
                            contentStream = new PDPageContentStream(document, page);
                            yPosition = page.getMediaBox().getHeight() - margin;
                            contentStream.setFont(fontRegular, 10);
                        }
                    }
                    yPosition -= lineHeight * 0.5f;
                }

                // --- SECCIÓN DE MOVIMIENTOS DE CAJA ---
                if (movimientosCaja != null && !movimientosCaja.isEmpty()) {
                    contentStream.setFont(fontBold, 14);
                    contentStream.beginText();
                    contentStream.newLineAtOffset(margin, yPosition);
                    contentStream.showText("MOVIMIENTOS DE CAJA");
                    contentStream.endText();
                    yPosition -= lineHeight;

                    contentStream.setFont(fontRegular, 10);
                    for (String movimiento : movimientosCaja) {
                        contentStream.beginText();
                        contentStream.newLineAtOffset(margin, yPosition);
                        contentStream.showText("- " + movimiento);
                        contentStream.endText();
                        yPosition -= smallLineHeight;

                        if (yPosition < margin + 100) {
                            contentStream.close();
                            page = new PDPage(PDRectangle.A4);
                            document.addPage(page);
                            contentStream = new PDPageContentStream(document, page);
                            yPosition = page.getMediaBox().getHeight() - margin;
                            contentStream.setFont(fontRegular, 10);
                        }
                    }

                    try {
                        double saldoActual = cajaModel.getSaldoActual();
                        yPosition -= smallLineHeight;
                        contentStream.setFont(fontBold, 12);
                        drawRightAlignedText(contentStream, "SALDO ACTUAL:", margin + 300, yPosition, fontBold, 12);
                        drawRightAlignedText(contentStream, String.format("$%.2f", saldoActual), margin + 380, yPosition, fontBold, 12);
                        yPosition -= lineHeight * 1.5f;
                    } catch (SQLException ex) {
                        // Ignorar error de saldo
                    }
                }

                // --- PIE DE PÁGINA ---
                drawLine(contentStream, margin, yPosition, page.getMediaBox().getWidth() - 2 * margin, 0.5f);
                yPosition -= lineHeight;
                String fechaHoraGeneracion = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));
                contentStream.setFont(fontRegular, 10);
                drawCenteredText(contentStream, "Reporte generado el " + fechaHoraGeneracion,
                        page.getMediaBox().getWidth()/2, yPosition, fontRegular, 10);
                yPosition -= lineHeight;
                String usuarioGenerador = MainMenuView.getInstance().getUsuarioActivo();
                drawCenteredText(contentStream, "Generado por: " + usuarioGenerador,
                        page.getMediaBox().getWidth()/2, yPosition, fontRegular, 10);

            } finally {
                contentStream.close();
            }

            document.save(outputStream);
        } finally {
            document.close();
        }
    }

    // Métodos auxiliares...
    private void drawCenteredText(PDPageContentStream contentStream, String text, float x, float y, PDType1Font font, float fontSize) throws IOException {
        float textWidth = font.getStringWidth(text) / 1000 * fontSize;
        contentStream.beginText();
        contentStream.setFont(font, fontSize);
        contentStream.newLineAtOffset(x - textWidth/2, y);
        contentStream.showText(text);
        contentStream.endText();
    }

    private void drawRightAlignedText(PDPageContentStream contentStream, String text, float x, float y, PDType1Font font, float fontSize) throws IOException {
        float textWidth = font.getStringWidth(text) / 1000 * fontSize;
        contentStream.beginText();
        contentStream.setFont(font, fontSize);
        contentStream.newLineAtOffset(x - textWidth, y);
        contentStream.showText(text);
        contentStream.endText();
    }

    private void drawTableRow(PDPageContentStream contentStream, float startX, float startY, float[] columnWidths, String[] texts, PDType1Font font, float fontSize) throws IOException {
        float x = startX;
        contentStream.setFont(font, fontSize);
        for (int i = 0; i < texts.length; i++) {
            contentStream.beginText();
            contentStream.newLineAtOffset(x, startY);
            contentStream.showText(texts[i]);
            contentStream.endText();
            x += columnWidths[i];
        }
    }

    private void drawLine(PDPageContentStream contentStream, float x, float y, float width) throws IOException {
        drawLine(contentStream, x, y, width, 1f);
    }

    private void drawLine(PDPageContentStream contentStream, float x, float y, float width, float thickness) throws IOException {
        contentStream.setLineWidth(thickness);
        contentStream.moveTo(x, y);
        contentStream.lineTo(x + width, y);
        contentStream.stroke();
    }

    private boolean validarFormatoFecha(String fecha) {
        try {
            java.time.LocalDate.parse(fecha, java.time.format.DateTimeFormatter.ISO_LOCAL_DATE);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}