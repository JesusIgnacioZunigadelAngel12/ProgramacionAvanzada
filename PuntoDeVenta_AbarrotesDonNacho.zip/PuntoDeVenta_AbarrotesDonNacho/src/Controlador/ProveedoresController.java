package Controlador;

import Modelo.ProveedorModel;
import Vista.ProveedoresView;
import java.awt.*;
import java.util.List;
import java.util.UUID;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.sql.SQLException;

public class ProveedoresController {
    private ProveedorModel model;
    private ProveedoresView view;

    public ProveedoresController(ProveedorModel model, ProveedoresView view) {
        this.model = model;
        this.view = view;

        // Configurar acciones
        view.getBtnNuevo().addActionListener(this::nuevoProveedor);
        view.getBtnBuscar().addActionListener(e -> buscarProveedor());
        view.getBtnEliminar().addActionListener(this::eliminarProveedor);
        view.getBtnEditar().addActionListener(this::editarProveedor);
        view.getBtnSalir().addActionListener(e -> view.dispose());
        view.getBtnLimpiar().addActionListener(e -> limpiarBusqueda()); // Nuevo listener


        cargarProveedores();
    }

    private void cargarProveedores() {
        try {
            Object[][] datos = convertirAArray(model.getProveedores());
            view.cargarProveedores(datos);
        } catch (SQLException ex) {
            view.mostrarError("Error al cargar proveedores: " + ex.getMessage());
        }
    }

    private Object[][] convertirAArray(List<ProveedorModel.Proveedor> proveedores) {
        Object[][] datos = new Object[proveedores.size()][4];
        int i = 0;
        for (ProveedorModel.Proveedor p : proveedores) {
            datos[i][0] = p.getId();
            datos[i][1] = p.getEmpresa();
            datos[i][2] = p.getContacto();
            datos[i][3] = p.getTelefonoContacto();
            i++;
        }
        return datos;
    }

    private void nuevoProveedor(ActionEvent e) {
        JDialog dialogo = new JDialog(view, "Agregar Proveedor", true);
        dialogo.setSize(500, 300);
        dialogo.setLayout(new GridLayout(5, 2, 5, 5));

        JTextField txtEmpresa = new JTextField();
        JTextField txtNombreContacto = new JTextField();
        JTextField txtTelefonoContacto = new JTextField();
        JButton btnGuardar = new JButton("Guardar");

        dialogo.add(new JLabel("Empresa:"));
        dialogo.add(txtEmpresa);
        dialogo.add(new JLabel("Nombre de Contacto:"));
        dialogo.add(txtNombreContacto);
        dialogo.add(new JLabel("Teléfono de Contacto:"));
        dialogo.add(txtTelefonoContacto);
        dialogo.add(new JLabel());
        dialogo.add(btnGuardar);

        btnGuardar.addActionListener(evt -> {
            try {
                String empresa = txtEmpresa.getText().trim();
                String nombreContacto = txtNombreContacto.getText().trim();
                String telefonoContacto = txtTelefonoContacto.getText().trim();

                if (empresa.isEmpty() || nombreContacto.isEmpty() || telefonoContacto.isEmpty()) {
                    throw new IllegalArgumentException("Todos los campos son obligatorios");
                }
                if (!telefonoContacto.matches("^\\+?[0-9\\s\\-]*$")) {
                    throw new IllegalArgumentException("El teléfono debe contener solo números, '+', espacios o guiones");
                }

                String id = generarIdProveedor();
                ProveedorModel.Proveedor nuevoProveedor = new ProveedorModel.Proveedor(id, empresa, nombreContacto, telefonoContacto);
                model.agregarProveedor(nuevoProveedor);
                cargarProveedores();
                view.mostrarMensaje("Proveedor agregado correctamente", "Éxito");
                dialogo.dispose();
            } catch (Exception ex) {
                view.mostrarError(ex.getMessage());
            }
        });

        dialogo.setVisible(true);
    }

    private String generarIdProveedor() throws SQLException {
        int numeroProveedores = model.getProveedores().size();
        
        return String.format("P%03d", numeroProveedores + 1);
    }

    private void buscarProveedor() {
        String busqueda = view.obtenerBusqueda();
        if (busqueda != null && !busqueda.trim().isEmpty()) {
            try {
                List<ProveedorModel.Proveedor> resultados = model.buscarProveedores(busqueda);
                if (resultados.isEmpty()) {
                    view.mostrarMensaje("No se encontraron proveedores", "Resultados de búsqueda");
                    cargarProveedores();
                } else {
                    Object[][] datos = convertirAArray(resultados);
                    view.cargarProveedores(datos);
                }
            } catch (SQLException ex) {
                view.mostrarError("Error al buscar proveedores: " + ex.getMessage());
            }
        } else {
            cargarProveedores();
        }
    }

    private void eliminarProveedor(ActionEvent e) {
        int filaSeleccionada = view.getFilaSeleccionada();
        if (filaSeleccionada >= 0) {
            String idProveedor = (String) view.modeloTabla.getValueAt(filaSeleccionada, 0);
            int confirm = JOptionPane.showConfirmDialog(view,
                "¿Está seguro de eliminar este proveedor?", "Confirmar Eliminación",
                JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                try {
                    model.eliminarProveedor(idProveedor);
                    cargarProveedores();
                    view.mostrarMensaje("Proveedor eliminado correctamente", "Éxito");
                } catch (SQLException ex) {
                    view.mostrarError("Error al eliminar proveedor: " + ex.getMessage());
                }
            }
        } else {
            view.mostrarError("Seleccione un proveedor para eliminar");
        }
    }

    private void editarProveedor(ActionEvent e) {
        int filaSeleccionada = view.getFilaSeleccionada();
        if (filaSeleccionada >= 0) {
            String idProveedor = (String) view.modeloTabla.getValueAt(filaSeleccionada, 0);
            try {
                ProveedorModel.Proveedor proveedor = model.buscarProveedores(idProveedor).get(0);

                JDialog dialogo = new JDialog(view, "Editar Proveedor", true);
                dialogo.setSize(500, 300);
                dialogo.setLayout(new GridLayout(5, 2, 5, 5));

                JTextField txtEmpresa = new JTextField(proveedor.getEmpresa());
                JTextField txtNombreContacto = new JTextField(proveedor.getContacto());
                JTextField txtTelefonoContacto = new JTextField(proveedor.getTelefonoContacto());
                JButton btnGuardar = new JButton("Guardar");

                dialogo.add(new JLabel("Empresa:"));
                dialogo.add(txtEmpresa);
                dialogo.add(new JLabel("Nombre de Contacto:"));
                dialogo.add(txtNombreContacto);
                dialogo.add(new JLabel("Teléfono de Contacto:"));
                dialogo.add(txtTelefonoContacto);
                dialogo.add(new JLabel());
                dialogo.add(btnGuardar);

                btnGuardar.addActionListener(evt -> {
                    try {
                        String nuevaEmpresa = txtEmpresa.getText().trim();
                        String nuevoNombreContacto = txtNombreContacto.getText().trim();
                        String nuevoTelefonoContacto = txtTelefonoContacto.getText().trim();

                        if (nuevaEmpresa.isEmpty() || nuevoNombreContacto.isEmpty() || nuevoTelefonoContacto.isEmpty()) {
                            throw new IllegalArgumentException("Todos los campos son obligatorios");
                        }
                        if (!nuevoTelefonoContacto.matches("^\\+?[0-9\\s\\-]*$")) {
                            throw new IllegalArgumentException("El teléfono debe contener solo números, '+', espacios o guiones");
                        }

                        proveedor.setEmpresa(nuevaEmpresa);
                        proveedor.setContacto(nuevoNombreContacto);
                        proveedor.setTelefonoContacto(nuevoTelefonoContacto);
                        model.actualizarProveedor(proveedor);
                        cargarProveedores();
                        view.mostrarMensaje("Proveedor editado correctamente", "Éxito");
                        dialogo.dispose();
                    } catch (Exception ex) {
                        view.mostrarError(ex.getMessage());
                    }
                });

                dialogo.setVisible(true);
            } catch (SQLException ex) {
                view.mostrarError("Error al buscar proveedor: " + ex.getMessage());
            }
        } else {
            view.mostrarError("Seleccione un proveedor para editar");
        }
    }
    
    private void limpiarBusqueda() {
        view.limpiarBusqueda();
        cargarProveedores();
    }
}