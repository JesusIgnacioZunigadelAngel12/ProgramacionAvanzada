package Controlador;

import Modelo.UsuarioModel;
import Vista.LoginView;
import Vista.MainMenuView;
import Vista.RecuperarPasswordView;
import Vista.RegistroView;
import java.awt.event.ActionEvent;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class LoginController {
    private final LoginView view;
    private final UsuarioModel usuarioModel;

    public LoginController(LoginView view, UsuarioModel usuarioModel) {
        this.view = view;
        this.usuarioModel = usuarioModel;

        // Configurar listeners
        view.getBtnEntrar().addActionListener(this::autenticarUsuario);
        view.getBtnRegistrarUsuario().addActionListener(e -> mostrarRegistro());
        view.getBtnRecuperarContrasena().addActionListener(e -> mostrarRecuperarPassword());
    }

    private boolean verificarTelefonoRequerido(String username) throws SQLException {
        // Aquí puedes implementar lógica para determinar si requiere verificación de teléfono
        // Por ejemplo, solo para ciertos roles o en ciertas circunstancias
        return true; // Por ahora siempre requerimos teléfono
    }

    private void mostrarRegistro() {
        RegistroView registroView = new RegistroView(view);
        registroView.addRegistrarListener(e -> registrarUsuario(registroView));
        registroView.addCancelarListener(e -> registroView.cerrar());
        registroView.setVisible(true);
    }

    private void autenticarUsuario(ActionEvent e) {
        String username = view.getUsuario().trim();
        String password = view.getPassword().trim();

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(view, 
                "Usuario y contraseña son obligatorios", 
                "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            if (usuarioModel.autenticar(username, password)) {
                // Autenticación exitosa sin verificación adicional de teléfono
                MainMenuView mainMenu = MainMenuView.getInstance();
                mainMenu.setUsuarioActivo(username);
                mainMenu.setVisible(true);
                view.dispose();
                new MainController(mainMenu);
            } else {
                JOptionPane.showMessageDialog(view, 
                    "Credenciales incorrectas o usuario no existe", 
                    "Error de autenticación", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(view, 
                "Error de conexión con la base de datos: " + ex.getMessage(), 
                "Error del sistema", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }
    
    
    private void registrarUsuario(RegistroView registroView) {
        String adminUser = registroView.getAdminUser();
        String adminPassword = registroView.getAdminPassword();
        String nuevoUsuario = registroView.getNuevoUsuario();
        String nuevoPassword = registroView.getNuevoPassword();
        String confirmPassword = registroView.getConfirmPassword();
        String telefono = registroView.getTelefono();
        String rol = registroView.getRol();

        // Validaciones básicas
        if (adminUser.isEmpty() || adminPassword.isEmpty() || 
            nuevoUsuario.isEmpty() || nuevoPassword.isEmpty() || telefono.isEmpty()) {
            registroView.mostrarError("Todos los campos son obligatorios");
            return;
        }

        if (!nuevoPassword.equals(confirmPassword)) {
            registroView.mostrarError("Las contraseñas del nuevo usuario no coinciden");
            return;
        }

        if (!telefono.matches("^[+]?[0-9\\s-]{10,15}$")) {
            registroView.mostrarError("Formato de teléfono inválido. Use 10-15 dígitos");
            return;
        }

        try {
            // Verificar que el usuario que intenta registrar es admin
            if (!usuarioModel.autenticar(adminUser, adminPassword) || 
                !usuarioModel.esAdmin(adminUser)) {
                registroView.mostrarError("Credenciales de administrador inválidas");
                return;
            }

            // Verificar que el nuevo usuario no exista
            if (usuarioModel.usuarioExiste(nuevoUsuario)) {
                registroView.mostrarError("El nombre de usuario ya existe");
                return;
            }

            // Registrar el nuevo usuario
            usuarioModel.agregarUsuario(nuevoUsuario, nuevoPassword, rol, telefono);
            registroView.mostrarMensaje("Usuario registrado exitosamente");
            registroView.cerrar();
        } catch (SQLException ex) {
            registroView.mostrarError("Error al registrar usuario: " + ex.getMessage());
        }
    }

    private void mostrarRecuperarPassword() {
        RecuperarPasswordView recuperarView = new RecuperarPasswordView(view);
        recuperarView.addConfirmarListener(e -> recuperarPassword(recuperarView));
        recuperarView.addCancelarListener(e -> recuperarView.cerrar());
        recuperarView.setVisible(true);
    }

    private void recuperarPassword(RecuperarPasswordView recuperarView) {
        String username = recuperarView.getUsuario();
        String telefono = recuperarView.getTelefono();
        String nuevaPassword = recuperarView.getNuevaPassword();
        String confirmarPassword = recuperarView.getConfirmarPassword();

        // Validaciones
        if (username.isEmpty() || telefono.isEmpty() || nuevaPassword.isEmpty()) {
            recuperarView.mostrarError("Todos los campos son obligatorios");
            return;
        }

        if (!nuevaPassword.equals(confirmarPassword)) {
            recuperarView.mostrarError("Las contraseñas no coinciden");
            return;
        }

        try {
            // Verificar que el usuario y teléfono coincidan
            if (!usuarioModel.verificarTelefono(username, telefono)) {
                recuperarView.mostrarError("Usuario o teléfono incorrectos");
                return;
            }

            // Actualizar contraseña
            usuarioModel.actualizarContrasena(username, nuevaPassword);
            recuperarView.mostrarMensaje("Contraseña actualizada exitosamente");
            recuperarView.cerrar();
        } catch (SQLException ex) {
            recuperarView.mostrarError("Error al recuperar contraseña: " + ex.getMessage());
        }
    }
}