package Controlador;

import Modelo.CajaModel;
import Modelo.ClienteModel;
import Modelo.ProductoModel;
import Modelo.VentaModel;
import Vista.MainMenuView;
import Vista.PuntoVentaView;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.font.Standard14Fonts;
import java.awt.Desktop;
import java.io.File;

public class PuntoVentaController {
    private ProductoModel productoModel;
    private VentaModel ventaModel;
    private PuntoVentaView view;
    private ClienteModel clienteModel;
    private CajaModel modelCaja;

    public PuntoVentaController(ProductoModel productoModel, VentaModel ventaModel,PuntoVentaView view, ClienteModel clienteModel, CajaModel cajaModel) {
    	    this.productoModel = productoModel;
    		this.ventaModel = ventaModel;
    		this.view = view;
    		this.clienteModel = clienteModel;
    		this.modelCaja = cajaModel;

        try {
            cargarTodosLosProductos();
            cargarClientes(); // Cargar clientes al iniciar
        } catch (SQLException e) {
            view.mostrarError("Error al cargar datos iniciales: " + e.getMessage());
        }

        view.setBuscarListener(this::buscarProducto);
        view.setLimpiarListener(e -> limpiarBusqueda()); // Nuevo listener

        view.setAgregarListener(e -> agregarProductoAVenta(e));
        view.setEliminarProductoListener(e -> eliminarProductoDeVenta(e));
        view.setEditarCantidadListener(e -> editarCantidad(e));
        view.setCancelarVentaListener(e -> cancelarVenta(e));
        view.setPagarListener(e -> pagar(e));
        view.setSalirListener(e -> view.dispose());
        
    }

    private void cargarTodosLosProductos() throws SQLException {
        List<ProductoModel.Producto> productos = productoModel.getProductos();
        Object[][] datos = new Object[productos.size()][7];
        int i = 0;
        for (ProductoModel.Producto producto : productos) {
            datos[i][0] = producto.getCodigo();
            datos[i][1] = producto.getNombre();
            datos[i][2] = producto.getPrecioConImpuesto(); // Precio CON IVA
            datos[i][3] = producto.getCantidad();
            datos[i][4] = producto.getCategoria();
            datos[i][5] = producto.getDescripcion();
            datos[i][6] = producto.getProveedor() != null ? producto.getProveedor().getEmpresa() : "Sin proveedor";
            i++;
        }
        view.cargarProductos(datos);
    }
    private void buscarProducto(ActionEvent e) {
        String busqueda = view.getTextoBusqueda();
        if (busqueda != null && !busqueda.trim().isEmpty()) {
            try {
                List<ProductoModel.Producto> resultados = productoModel.buscarProductos(busqueda);
                Object[][] datos = convertirProductosAMatriz(resultados);
                view.cargarProductos(datos);
            } catch (SQLException ex) {
                view.mostrarError("Error al buscar productos: " + ex.getMessage());
            }
        } else {
            try {
                cargarTodosLosProductos();
            } catch (SQLException ex) {
                view.mostrarError("Error al cargar productos: " + ex.getMessage());
            }
        }
    }
    
    private void limpiarBusqueda() {
        view.limpiarBusqueda();
        try {
            cargarTodosLosProductos();
        } catch (SQLException ex) {
            view.mostrarError("Error al cargar productos: " + ex.getMessage());
        }
    }
    
    private void cargarClientes() {
        try {
            List<ClienteModel.Cliente> clientes = clienteModel.getTodosClientes();
            view.cargarClientes(clientes);
        } catch (SQLException ex) {
            view.mostrarError("Error al cargar clientes: " + ex.getMessage());
        }
    }
    
    private void nuevoCliente() {
        JDialog dialogo = new JDialog(view, "Nuevo Cliente", true);
        dialogo.setSize(400, 300);
        dialogo.setLayout(new GridLayout(5, 2, 10, 10));

        JTextField txtNombre = new JTextField();
        JTextField txtTelefono = new JTextField();
        JTextField txtCorreo = new JTextField();
        
        JButton btnGuardar = new JButton("Guardar");

        dialogo.add(new JLabel("Nombre:"));
        dialogo.add(txtNombre);
        dialogo.add(new JLabel("Teléfono:"));
        dialogo.add(txtTelefono);
        dialogo.add(new JLabel("Correo:"));
        dialogo.add(txtCorreo);
        dialogo.add(new JLabel());
        dialogo.add(btnGuardar);

        btnGuardar.addActionListener(e -> {
            try {
                String nombre = txtNombre.getText().trim();
                String telefono = txtTelefono.getText().trim();
                String correo = txtCorreo.getText().trim();

                if (nombre.isEmpty()) {
                    view.mostrarError("El nombre es obligatorio");
                    return;
                }

                ClienteModel.Cliente nuevoCliente = new ClienteModel.Cliente(
                    java.util.UUID.randomUUID().toString().substring(0, 8),
                    nombre, 
                    telefono,
                    correo
                );
                
                clienteModel.agregarCliente(nuevoCliente);
                cargarClientes();
                view.getComboClientes().setSelectedItem(nuevoCliente); // Cambio aquí
                dialogo.dispose();
                view.mostrarMensaje("Cliente agregado correctamente", "Éxito");
                
            } catch (SQLException ex) {
                view.mostrarError("Error al guardar cliente: " + ex.getMessage());
            }
        });

        dialogo.setVisible(true);
    }

    private void agregarProductoAVenta(ActionEvent e) {
        int filaSeleccionada = view.getFilaSeleccionada();
        if (filaSeleccionada >= 0) {
            String codigo = (String) view.getModeloTablaProductos().getValueAt(filaSeleccionada, 0);
            try {
                ProductoModel.Producto producto = productoModel.buscarProductoPorCodigo(codigo);
                if (producto != null && producto.getCantidad() > 0) {
                    DefaultTableModel modeloTablaVenta = view.getModeloTablaVenta();

                    int filaEnVenta = -1;
                    for (int i = 0; i < modeloTablaVenta.getRowCount(); i++) {
                        if (codigo.equals(modeloTablaVenta.getValueAt(i, 0))) {
                            filaEnVenta = i;
                            break;
                        }
                    }

                    if (filaEnVenta >= 0) {
                        int cantidadActual = (int) modeloTablaVenta.getValueAt(filaEnVenta, 3);
                        modeloTablaVenta.setValueAt(cantidadActual + 1, filaEnVenta, 3);
                    } else {
                        modeloTablaVenta.addRow(new Object[]{
                            producto.getCodigo(),
                            producto.getNombre(),
                            producto.getPrecioConImpuesto(), // Precio CON IVA
                            1
                        });
                    }

                    producto.setCantidad(producto.getCantidad() - 1);
                    productoModel.ajustarCantidad(producto.getCodigo(), producto.getCantidad());
                    cargarTodosLosProductos();
                    view.actualizarTotal();
                } else {
                    view.mostrarError("No hay stock disponible");
                }
            } catch (SQLException ex) {
                view.mostrarError("Error al agregar producto: " + ex.getMessage());
            }
        } else {
            view.mostrarError("Seleccione un producto para agregar");
        }
    }

    private void eliminarProductoDeVenta(ActionEvent e) {
        int filaSeleccionada = view.getFilaSeleccionadaVenta();
        if (filaSeleccionada >= 0) {
            DefaultTableModel modeloTablaVenta = view.getModeloTablaVenta();
            String codigo = (String) modeloTablaVenta.getValueAt(filaSeleccionada, 0);
            int cantidad = (int) modeloTablaVenta.getValueAt(filaSeleccionada, 3);

            try {
                ProductoModel.Producto producto = productoModel.buscarProductoPorCodigo(codigo);
                if (producto != null) {
                    // Devolver al stock
                    producto.setCantidad(producto.getCantidad() + cantidad);
                    productoModel.ajustarCantidad(producto.getCodigo(), producto.getCantidad());
                }

                // Eliminar de la venta
                modeloTablaVenta.removeRow(filaSeleccionada);
                cargarTodosLosProductos(); // Refrescar la lista de productos
                view.actualizarTotal();
            } catch (SQLException ex) {
                view.mostrarError("Error al eliminar producto de la venta: " + ex.getMessage());
            }
        } else {
            view.mostrarError("Seleccione un producto en la venta para eliminar");
        }
    }

    private void editarCantidad(ActionEvent e) {
        int filaVenta = view.getFilaSeleccionadaVenta();
        if (filaVenta >= 0) {
            DefaultTableModel modeloTablaVenta = view.getModeloTablaVenta();
            String codigo = (String) modeloTablaVenta.getValueAt(filaVenta, 0);
            int cantidadActual = (int) modeloTablaVenta.getValueAt(filaVenta, 3);

            String nuevaCantidadStr = JOptionPane.showInputDialog(view,
                "Editar cantidad para " + modeloTablaVenta.getValueAt(filaVenta, 1),
                cantidadActual);

            try {
                int nuevaCantidad = Integer.parseInt(nuevaCantidadStr);
                if (nuevaCantidad <= 0) {
                    view.mostrarError("La cantidad debe ser mayor a cero");
                    return;
                }

                ProductoModel.Producto producto = productoModel.buscarProductoPorCodigo(codigo);
                int diferencia = nuevaCantidad - cantidadActual;

                // Verificar stock disponible
                if (producto.getCantidad() < diferencia) {
                    view.mostrarError("Stock insuficiente. Disponible: " + producto.getCantidad());
                    return;
                }

                // Actualizar cantidad en venta y stock
                modeloTablaVenta.setValueAt(nuevaCantidad, filaVenta, 3);
                producto.setCantidad(producto.getCantidad() - diferencia);
                productoModel.ajustarCantidad(producto.getCodigo(), producto.getCantidad());
                cargarTodosLosProductos(); // Refrescar la lista de productos
                view.actualizarTotal();
            } catch (NumberFormatException ex) {
                view.mostrarError("Ingrese un número válido");
            } catch (SQLException ex) {
                view.mostrarError("Error al editar cantidad: " + ex.getMessage());
            }
        } else {
            view.mostrarError("Seleccione un producto en la venta para editar");
        }
    }

    private void cancelarVenta(ActionEvent e) {
        DefaultTableModel modeloTablaVenta = view.getModeloTablaVenta();
        if (modeloTablaVenta.getRowCount() == 0) {
            view.mostrarError("No hay productos en la venta actual");
            return;
        }

        int confirmacion = JOptionPane.showConfirmDialog(view,
            "¿Está seguro de cancelar la venta actual?\nSe devolverán todos los productos al inventario.",
            "Confirmar Cancelación",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE);

        if (confirmacion == JOptionPane.YES_OPTION) {
            try {
                // Devolver productos al inventario
                for (int i = 0; i < modeloTablaVenta.getRowCount(); i++) {
                    String codigo = (String) modeloTablaVenta.getValueAt(i, 0);
                    int cantidad = (int) modeloTablaVenta.getValueAt(i, 3);

                    ProductoModel.Producto producto = productoModel.buscarProductoPorCodigo(codigo);
                    if (producto != null) {
                        producto.setCantidad(producto.getCantidad() + cantidad);
                        productoModel.ajustarCantidad(producto.getCodigo(), producto.getCantidad());
                    }
                }

                // Limpiar la venta
                modeloTablaVenta.setRowCount(0);
                cargarTodosLosProductos(); // Refrescar la lista de productos
                view.actualizarTotal();
                view.mostrarMensaje("Venta cancelada correctamente", "Operación Exitosa");
            } catch (SQLException ex) {
                view.mostrarError("Error al cancelar venta: " + ex.getMessage());
            }
        }
    }

    private void pagar(ActionEvent e) {
        if (view.getModeloTablaVenta().getRowCount() == 0) {
            view.mostrarError("No hay productos en la venta actual");
            return;
        }

        double total = calcularTotal();
        String montoRecibidoStr = JOptionPane.showInputDialog(view,
                "Total a pagar: $" + String.format("%.2f", total) + "\nIngrese el monto recibido:",
                "Procesar Pago",
                JOptionPane.PLAIN_MESSAGE);

        if (montoRecibidoStr == null || montoRecibidoStr.trim().isEmpty()) {
            return; // El usuario canceló
        }

        try {
            double montoRecibido = Double.parseDouble(montoRecibidoStr);
            if (montoRecibido < total) {
                view.mostrarError("El monto recibido es menor al total a pagar");
                return;
            }

            double cambio = montoRecibido - total;

            // Obtener el nombre del usuario activo y el cliente seleccionado
            String atendio = MainMenuView.getInstance().getUsuarioActivo();
            ClienteModel.Cliente cliente = view.getClienteSeleccionado();

            // Crear nueva venta con formato de fecha compatible con SQL Server DATETIME
            String folio = generarFolio();
            String fecha = java.time.LocalDate.now().format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            String hora = java.time.LocalTime.now().format(java.time.format.DateTimeFormatter.ofPattern("HH:mm:ss")); // Formato completo para hora
            
            VentaModel.Venta nuevaVenta = new VentaModel.Venta(folio, fecha, hora, total, "EFECTIVO", atendio, cliente);
            nuevaVenta.setMontoRecibido(montoRecibido);
            nuevaVenta.setCambio(cambio);

            // Agregar productos a la venta
            for (int i = 0; i < view.getModeloTablaVenta().getRowCount(); i++) {
                String codigo = (String) view.getModeloTablaVenta().getValueAt(i, 0);
                String nombre = (String) view.getModeloTablaVenta().getValueAt(i, 1);
                double precio = (double) view.getModeloTablaVenta().getValueAt(i, 2);
                int cantidad = (int) view.getModeloTablaVenta().getValueAt(i, 3);

                nuevaVenta.agregarProducto(new VentaModel.ProductoVendido(codigo, nombre, cantidad, precio));
            }

            // Guardar venta en la base de datos
            ventaModel.agregarVenta(nuevaVenta);

            // Registrar el ingreso en caja
            if ("EFECTIVO".equals(nuevaVenta.getMetodoPago())) {
                String usuario = MainMenuView.getInstance().getUsuarioActivo();
                modelCaja.registrarMovimientoEnCaja("DEPOSITO", total, "Venta registrada (efectivo)", usuario);
            }

            // Limpiar la venta actual
            view.getModeloTablaVenta().setRowCount(0);
            view.actualizarTotal();

            // Mostrar mensaje con el detalle (usando formato legible para el usuario)
            String fechaLegible = java.time.LocalDate.now().format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy"));
            String horaLegible = java.time.LocalTime.now().format(java.time.format.DateTimeFormatter.ofPattern("HH:mm"));
            
            StringBuilder detalleVenta = new StringBuilder();
            detalleVenta.append("VENTA REGISTRADA EXITOSAMENTE\n")
                       .append("Folio: ").append(folio).append("\n")
                       .append("Fecha: ").append(fechaLegible).append(" ").append(horaLegible).append("\n")
                       .append("Atendió: ").append(atendio).append("\n");
            
            // Agregar información del cliente si existe
            if (cliente != null) {
                detalleVenta.append("Cliente: ").append(cliente.getNombre())
                           .append(" (").append(cliente.getTelefono()).append(")\n");
            }
            
            detalleVenta.append("Productos:\n");

            for (VentaModel.ProductoVendido producto : nuevaVenta.getProductos()) {
                detalleVenta.append("- ").append(producto.getNombre())
                           .append(" x").append(producto.getCantidad())
                           .append(" ($").append(producto.getPrecio()).append(" c/u)\n");
            }

            detalleVenta.append("TOTAL: $").append(String.format("%.2f", total)).append("\n")
                       .append("Recibido: $").append(String.format("%.2f", montoRecibido)).append("\n")
                       .append("Cambio: $").append(String.format("%.2f", cambio)).append("\n");

            view.mostrarMensaje(detalleVenta.toString(), "Venta Registrada");

            // Exportar ticket
            exportarTicket(nuevaVenta);

        } catch (NumberFormatException ex) {
            view.mostrarError("Ingrese un monto válido");
        } catch (SQLException ex) {
            view.mostrarError("Error al procesar pago: " + ex.getMessage());
            ex.printStackTrace(); // Para depuración
        } catch (Exception ex) {
            view.mostrarError("Error inesperado: " + ex.getMessage());
            ex.printStackTrace(); // Para depuración
        }
    }
    
    private void exportarTicket(VentaModel.Venta venta) {
        try (PDDocument document = new PDDocument()) {
            PDPage page = new PDPage(PDRectangle.A6); // Tamaño adecuado para tickets
            document.addPage(page);
            
            // Configurar fuentes
            PDType1Font fontBold = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
            PDType1Font fontRegular = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
            
            PDPageContentStream contentStream = new PDPageContentStream(document, page);
            try {
                // Configuración inicial
                float margin = 20;
                float yPosition = page.getMediaBox().getHeight() - margin;
                float lineHeight = 14;
                float centerX = page.getMediaBox().getWidth() / 2;
                float tableWidth = page.getMediaBox().getWidth() - 2 * margin;
                
                // Encabezado del ticket
                contentStream.beginText();
                contentStream.setFont(fontBold, 14);
                contentStream.newLineAtOffset(centerX - 60, yPosition);
                contentStream.showText("ABARROTES DON NACHO");
                contentStream.endText();
                yPosition -= lineHeight * 1.5f;
                
                // Línea divisoria
                drawLine(contentStream, margin, yPosition, tableWidth);
                yPosition -= lineHeight;
                
                // Información de la venta
                contentStream.beginText();
                contentStream.setFont(fontRegular, 10);
                contentStream.newLineAtOffset(margin, yPosition);
                contentStream.showText("Folio: " + venta.getFolio());
                contentStream.endText();
                yPosition -= lineHeight;
                
                contentStream.beginText();
                contentStream.setFont(fontRegular, 10);
                contentStream.newLineAtOffset(margin, yPosition);
                contentStream.showText("Fecha: " + venta.getFecha() + " " + venta.getHora());
                contentStream.endText();
                yPosition -= lineHeight;
                
                contentStream.beginText();
                contentStream.setFont(fontRegular, 10);
                contentStream.newLineAtOffset(margin, yPosition);
                contentStream.showText("Atendió: " + venta.getAtendio());
                contentStream.endText();
                yPosition -= lineHeight;
                
                // Información del cliente si existe
                if (venta.getCliente() != null) {
                    contentStream.beginText();
                    contentStream.setFont(fontRegular, 10);
                    contentStream.newLineAtOffset(margin, yPosition);
                    contentStream.showText("Cliente: " + venta.getCliente().getNombre());
                    contentStream.endText();
                    yPosition -= lineHeight;
                }
                
                yPosition -= lineHeight * 0.5f;
                drawLine(contentStream, margin, yPosition, tableWidth);
                yPosition -= lineHeight;
                
                // Encabezados de productos
                contentStream.beginText();
                contentStream.setFont(fontBold, 10);
                contentStream.newLineAtOffset(margin, yPosition);
                contentStream.showText("Cant  Descripción         Precio  Total");
                contentStream.endText();
                yPosition -= lineHeight;
                
                // Productos
                for (VentaModel.ProductoVendido producto : venta.getProductos()) {
                    if (yPosition < margin + 50) { // Verificar espacio en página
                        contentStream.close();
                        PDPage newPage = new PDPage(PDRectangle.A6);
                        document.addPage(newPage);
                        contentStream = new PDPageContentStream(document, newPage);
                        yPosition = newPage.getMediaBox().getHeight() - margin;
                        
                        // Repetir encabezado en nueva página
                        contentStream.beginText();
                        contentStream.setFont(fontBold, 10);
                        contentStream.newLineAtOffset(margin, yPosition);
                        contentStream.showText("Cant  Descripción         Precio  Total");
                        contentStream.endText();
                        yPosition -= lineHeight;
                    }
                    
                    double totalProducto = producto.getPrecio() * producto.getCantidad();
                    String nombre = producto.getNombre().length() > 18 ? 
                        producto.getNombre().substring(0, 15) + "..." : producto.getNombre();
                    
                    contentStream.beginText();
                    contentStream.setFont(fontRegular, 9);
                    contentStream.newLineAtOffset(margin, yPosition);
                    contentStream.showText(String.format("%-4d  %-18s  $%-6.2f  $%.2f", 
                        producto.getCantidad(), 
                        nombre,
                        producto.getPrecio(), 
                        totalProducto));
                    contentStream.endText();
                    yPosition -= lineHeight;
                }
                
                yPosition -= lineHeight * 0.5f;
                drawLine(contentStream, margin, yPosition, tableWidth);
                yPosition -= lineHeight;
                
                // Totales
                contentStream.beginText();
                contentStream.setFont(fontBold, 10);
                contentStream.newLineAtOffset(margin, yPosition);
                contentStream.showText("Total: $" + String.format("%.2f", venta.getTotal()));
                contentStream.endText();
                yPosition -= lineHeight;
                
                contentStream.beginText();
                contentStream.setFont(fontRegular, 10);
                contentStream.newLineAtOffset(margin, yPosition);
                contentStream.showText("Recibido: $" + String.format("%.2f", venta.getMontoRecibido()));
                contentStream.endText();
                yPosition -= lineHeight;
                
                contentStream.beginText();
                contentStream.setFont(fontRegular, 10);
                contentStream.newLineAtOffset(margin, yPosition);
                contentStream.showText("Cambio: $" + String.format("%.2f", venta.getCambio()));
                contentStream.endText();
                yPosition -= lineHeight * 1.5f;
                
                // Mensaje final
                contentStream.beginText();
                contentStream.setFont(fontBold, 12);
                contentStream.newLineAtOffset(centerX - 50, yPosition);
                contentStream.showText("¡GRACIAS POR SU COMPRA!");
                contentStream.endText();
                yPosition -= lineHeight;
                
                contentStream.beginText();
                contentStream.setFont(fontRegular, 10);
                contentStream.newLineAtOffset(centerX - 40, yPosition);
                contentStream.showText("¡VUELVA PRONTO!");
                contentStream.endText();
            } finally {
                if (contentStream != null) {
                    contentStream.close();
                }
            }
            
            // Guardar el PDF
            String nombreArchivo = "ticket_" + venta.getFolio() + ".pdf";
            document.save(nombreArchivo);
            view.mostrarMensaje("Ticket PDF generado exitosamente: " + nombreArchivo, "Éxito");
            
            // Opcional: Abrir el PDF automáticamente
            if (Desktop.isDesktopSupported()) {
                try {
                    Desktop.getDesktop().open(new File(nombreArchivo));
                } catch (IOException ex) {
                    System.err.println("No se pudo abrir el PDF automáticamente: " + ex.getMessage());
                }
            }
        } catch (IOException ex) {
            view.mostrarError("Error al exportar ticket PDF: " + ex.getMessage());
        }
    }

    // Método auxiliar para dibujar líneas
    private void drawLine(PDPageContentStream contentStream, float x, float y, float width) throws IOException {
        contentStream.moveTo(x, y);
        contentStream.lineTo(x + width, y);
        contentStream.stroke();
    }

    private double calcularTotal() {
        double total = 0;
        for (int i = 0; i < view.getModeloTablaVenta().getRowCount(); i++) {
            double precio = (double) view.getModeloTablaVenta().getValueAt(i, 2);
            int cantidad = (int) view.getModeloTablaVenta().getValueAt(i, 3);
            
            // Obtener el producto completo para calcular el impuesto
            String codigo = (String) view.getModeloTablaVenta().getValueAt(i, 0);
            try {
                ProductoModel.Producto producto = productoModel.buscarProductoPorCodigo(codigo);
                if (producto != null) {
                    total += producto.getPrecioConImpuesto() * cantidad;
                } else {
                    total += precio * cantidad;
                }
            } catch (SQLException ex) {
                total += precio * cantidad;
            }
        }
        return total;
    }

    private String generarFolio() {
        return java.util.UUID.randomUUID().toString().substring(0, 8).toUpperCase();
    }

    private Object[][] convertirProductosAMatriz(List<ProductoModel.Producto> productos) {
        Object[][] datos = new Object[productos.size()][7];
        int i = 0;
        for (ProductoModel.Producto producto : productos) {
            datos[i][0] = producto.getCodigo();
            datos[i][1] = producto.getNombre();
            datos[i][2] = producto.getPrecio();
            datos[i][3] = producto.getCantidad();
            datos[i][4] = producto.getCategoria();
            datos[i][5] = producto.getDescripcion();
            datos[i][6] = producto.getProveedor() != null ? producto.getProveedor().getEmpresa() : "Sin proveedor";
            i++;
        }
        return datos;
    }
}