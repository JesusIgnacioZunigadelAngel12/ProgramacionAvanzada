package Controlador;

import Modelo.UsuarioModel;
import Vista.UsuariosView;
import java.util.List;
import javax.swing.*;
import java.sql.SQLException;

public class UsuariosController {
    private UsuarioModel model;
    private UsuariosView view;

    public UsuariosController(UsuarioModel model, UsuariosView view) {
        this.model = model;
        this.view = view;

        // Configurar listeners
        view.getBtnAgregar().addActionListener(e -> agregarUsuario());
        view.getBtnEditar().addActionListener(e -> editarUsuario());
        view.getBtnEliminar().addActionListener(e -> eliminarUsuario());
        view.getBtnBuscar().addActionListener(e -> buscarUsuario());
        view.getBtnLimpiar().addActionListener(e -> limpiarBusqueda());
        view.getBtnSalir().addActionListener(e -> view.dispose());

        cargarUsuarios();
    }

    private void cargarUsuarios() {
        try {
            List<UsuarioModel.Usuario> listaUsuarios = model.getUsuarios();
            Object[][] datos = new Object[listaUsuarios.size()][4];
            
            for (int i = 0; i < listaUsuarios.size(); i++) {
                datos[i][0] = listaUsuarios.get(i).getUsername();
                datos[i][1] = listaUsuarios.get(i).getPassword();
                datos[i][2] = listaUsuarios.get(i).getRol();
                datos[i][3] = listaUsuarios.get(i).getTelefono();// Agregar rol a los datos
            }
            
            view.cargarUsuarios(datos);
        } catch (SQLException ex) {
            view.mostrarError("Error al cargar usuarios: " + ex.getMessage());
        }
    }

    private void agregarUsuario() {
        String resultado = view.mostrarDialogoUsuario("Agregar Usuario", "", "");
        
        if (resultado != null) {
        	
            String[] partes = resultado.split(";");
            String username = partes[0];
            String password = partes[1];
            String rol = partes[2]; // Obtener rol del diálogo
            String telefono = partes[3]; // Obtener teléfono del diálogo
            
            if (username.isEmpty() || password.isEmpty()) {
                view.mostrarError("Usuario y contraseña son obligatorios");
                return;
            }
            
            if (!telefono.matches("^[+]?[0-9\\s-]*$")) {
                view.mostrarError("Formato de teléfono inválido. Use solo números, espacios, guiones o '+'");
                return;
            }
            
            try {
                if (model.usuarioExiste(username)) {
                    view.mostrarError("El usuario ya existe");
                    return;
                }
                
                model.agregarUsuario(username, password, rol, telefono); // Por defecto, rol de usuario);
                cargarUsuarios();
                view.mostrarMensaje("Usuario agregado correctamente", "Éxito");
            } catch (SQLException ex) {
                view.mostrarError("Error al agregar usuario: " + ex.getMessage());
            }
        }
    }

    private void editarUsuario() {
        int filaSeleccionada = view.getFilaSeleccionada();
        if (filaSeleccionada >= 0) {
            String usuarioActual = (String) view.getModeloTabla().getValueAt(filaSeleccionada, 0);
            String passwordActual = (String) view.getModeloTabla().getValueAt(filaSeleccionada, 1);
            String telefonoActual = (String) view.getModeloTabla().getValueAt(filaSeleccionada, 3); // Obtener teléfono actual
            
            String resultado = view.mostrarDialogoUsuario("Editar Usuario", usuarioActual, passwordActual);
            
            if (resultado != null) {
                String[] partes = resultado.split(";");
                String nuevoUsername = partes[0];
                String nuevoPassword = partes[1];
                String rol = partes[2]; 
                String nuevoTelefono  = partes[3];// Obtén el rol del diálogo
                
                if (nuevoUsername.isEmpty() || nuevoPassword.isEmpty()) {
                    view.mostrarError("Usuario y contraseña son obligatorios");
                    return;
                }
                
                if (!nuevoTelefono.matches("^[+]?[0-9\\s-]*$")) {
                    view.mostrarError("Formato de teléfono inválido. Use solo números, espacios, guiones o '+'");
                    return;
                }
                
                try {
                    model.eliminarUsuario(usuarioActual);
                    model.agregarUsuario(nuevoUsername, nuevoPassword, rol, nuevoTelefono );
                    cargarUsuarios();
                    view.mostrarMensaje("Usuario actualizado correctamente", "Éxito");
                } catch (SQLException ex) {
                    view.mostrarError("Error al actualizar usuario: " + ex.getMessage());
                }
            }
        } else {
            view.mostrarError("Seleccione un usuario para editar");
        }
    }

    private void eliminarUsuario() {
        int filaSeleccionada = view.getFilaSeleccionada();
        if (filaSeleccionada >= 0) {
            String username = (String) view.getModeloTabla().getValueAt(filaSeleccionada, 0);
            
            int confirmacion = JOptionPane.showConfirmDialog(
                view, 
                "¿Está seguro de eliminar al usuario " + username + "?", 
                "Confirmar eliminación", 
                JOptionPane.YES_NO_OPTION);
            
            if (confirmacion == JOptionPane.YES_OPTION) {
                try {
                    model.eliminarUsuario(username);
                    cargarUsuarios();
                    view.mostrarMensaje("Usuario eliminado correctamente", "Éxito");
                } catch (SQLException ex) {
                    view.mostrarError("Error al eliminar usuario: " + ex.getMessage());
                }
            }
        } else {
            view.mostrarError("Seleccione un usuario para eliminar");
        }
    }

    private void buscarUsuario() {
        String busqueda = view.getTextoBusqueda();
        
        if (busqueda != null && !busqueda.trim().isEmpty()) {
            try {
                List<UsuarioModel.Usuario> resultados = model.buscarUsuarios(busqueda);
                
                if (resultados.isEmpty()) {
                    view.mostrarMensaje("No se encontraron usuarios", "Resultados");
                    cargarUsuarios();
                } else {
                    Object[][] datos = new Object[resultados.size()][2];
                    for (int i = 0; i < resultados.size(); i++) {
                        datos[i][0] = resultados.get(i).getUsername();
                        datos[i][1] = resultados.get(i).getPassword();
                    }
                    view.cargarUsuarios(datos);
                }
            } catch (SQLException ex) {
                view.mostrarError("Error al buscar usuarios: " + ex.getMessage());
            }
        } else {
            cargarUsuarios();
        }
    }

    private void limpiarBusqueda() {
        view.limpiarBusqueda();
        cargarUsuarios();
    }
}