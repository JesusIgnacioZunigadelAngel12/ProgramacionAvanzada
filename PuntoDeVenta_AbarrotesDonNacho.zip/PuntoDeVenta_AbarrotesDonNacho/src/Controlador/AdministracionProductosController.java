package Controlador;

import Modelo.ProductoModel;
import Modelo.ProveedorModel;
import Modelo.CategoriaModel;
import Vista.AdministracionProductosView;
import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.font.Standard14Fonts;
import Conexion.ConexionBD;

public class AdministracionProductosController {
    private ProductoModel model;
    private AdministracionProductosView view;
    private final CategoriaModel categoriaModel;
    private static final int STOCK_MINIMO = 5;

    public AdministracionProductosController(ProductoModel model, CategoriaModel categoriaModel, AdministracionProductosView view) {
        this.model = model;
        this.view = view;
        this.categoriaModel = categoriaModel;

        view.getBtnAgregar().addActionListener(this::agregarProducto);
        view.getBtnEditar().addActionListener(this::editarProducto);
        view.getBtnBuscar().addActionListener(e -> buscarProducto());        
        view.getBtnEliminar().addActionListener(this::eliminarProducto);
        view.getBtnReportePDF().addActionListener(this::generarReportePDF);
        view.getBtnLimpiar().addActionListener(e -> limpiarBusqueda());
        view.getBtnSalir().addActionListener(e -> view.dispose());

        cargarProductos();
        actualizarAlertaStock();
    }

    private void cargarProductos() {
        try {
            List<ProductoModel.Producto> listaProductos = model.getProductos();

            if (listaProductos == null || listaProductos.isEmpty()) {
                view.mostrarError("No hay productos disponibles");
                return;
            }

            Object[][] datos = new Object[listaProductos.size()][9];
            int i = 0;
            for (ProductoModel.Producto producto : listaProductos) {
                datos[i][0] = producto.getCodigo();
                datos[i][1] = producto.getNombre();
                datos[i][2] = producto.getPrecio();
                datos[i][3] = producto.getPrecioConImpuesto();
                datos[i][4] = producto.getCantidad();
                datos[i][5] = producto.getCategoria();
                datos[i][6] = producto.getDescripcion();
                datos[i][7] = producto.getProveedor() != null ? producto.getProveedor().getEmpresa() : "Sin proveedor";
                datos[i][8] = producto.getImpuesto();
                i++;
            }

            view.cargarProductos(datos);
        } catch (SQLException ex) {
            view.mostrarError("Error al cargar productos: " + ex.getMessage());
        }
    }
    
    private void actualizarAlertaStock() {
        try {
            int productosBajoStock = 0;
            List<ProductoModel.Producto> productos = model.getProductos();
            for (ProductoModel.Producto producto : productos) {
                if (producto.getCantidad() < STOCK_MINIMO) {
                    productosBajoStock++;
                }
            }
            view.actualizarAlertaStock(productosBajoStock);
        } catch (SQLException ex) {
            view.mostrarError("Error al verificar stock bajo: " + ex.getMessage());
        }
    }

    private void agregarProducto(ActionEvent e) {
        JDialog dialogo = new JDialog(view, "Agregar Producto", true);
        dialogo.setSize(500, 650);
        dialogo.setLayout(new GridLayout(13, 2, 5, 5));

        JTextField txtCodigo = new JTextField();
        JTextField txtNombre = new JTextField();
        JTextField txtCosto = new JTextField();
        JTextField txtPorcentajeGanancia = new JTextField("20");
        JTextField txtPrecioFinal = new JTextField();
        txtPrecioFinal.setEditable(false);
        JTextField txtCantidad = new JTextField();
        
        DefaultComboBoxModel<String> modeloCategoria = new DefaultComboBoxModel<>();
        JComboBox<String> comboImpuestos = new JComboBox<>(ProductoModel.IMPUESTOS);
        
        for (String cat : categoriaModel.getCategorias()) {
            modeloCategoria.addElement(cat);
        }
        JComboBox<String> comboCategoria = new JComboBox<>(modeloCategoria);

        JTextArea txtDescripcion = new JTextArea(3, 20);
        JScrollPane scrollPaneDescripcion = new JScrollPane(txtDescripcion);

        JComboBox<ProveedorModel.Proveedor> comboProveedor = new JComboBox<>();
        comboProveedor.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index,
                                                        boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (value instanceof ProveedorModel.Proveedor) {
                    ProveedorModel.Proveedor prov = (ProveedorModel.Proveedor) value;
                    setText(prov.getEmpresa());
                } else if (value == null) {
                    setText("Seleccione proveedor");
                }
                return this;
            }
        });

        try {
            List<ProveedorModel.Proveedor> proveedores = ProveedorModel.getProveedores();
            DefaultComboBoxModel<ProveedorModel.Proveedor> modeloProveedor = new DefaultComboBoxModel<>();
            modeloProveedor.addElement(null);
            for (ProveedorModel.Proveedor prov : proveedores) {
                modeloProveedor.addElement(prov);
            }
            comboProveedor.setModel(modeloProveedor);
        } catch (SQLException ex) {
            view.mostrarError("Error al cargar proveedores: " + ex.getMessage());
        }

        JButton btnGuardar = new JButton("Guardar");

        DocumentListener dl = new DocumentListener() {
            public void changedUpdate(DocumentEvent e) { calcularPrecio(); }
            public void removeUpdate(DocumentEvent e) { calcularPrecio(); }
            public void insertUpdate(DocumentEvent e) { calcularPrecio(); }

            private void calcularPrecio() {
                try {
                    double costo = Double.parseDouble(txtCosto.getText().trim());
                    double porcentaje = Double.parseDouble(txtPorcentajeGanancia.getText().trim());
                    double precioFinal = costo + (costo * porcentaje / 100);
                    txtPrecioFinal.setText(String.format("%.2f", precioFinal));
                } catch (NumberFormatException ex) {
                    txtPrecioFinal.setText("");
                }
            }
        };

        txtCosto.getDocument().addDocumentListener(dl);
        txtPorcentajeGanancia.getDocument().addDocumentListener(dl);

        dialogo.add(new JLabel("Código*:"));
        dialogo.add(txtCodigo);
        dialogo.add(new JLabel("Nombre*:"));
        dialogo.add(txtNombre);
        dialogo.add(new JLabel("Costo*:"));
        dialogo.add(txtCosto);
        dialogo.add(new JLabel("Margen de Ganancia (%)*:"));
        dialogo.add(txtPorcentajeGanancia);
        dialogo.add(new JLabel("Precio Final*:"));
        dialogo.add(txtPrecioFinal);
        dialogo.add(new JLabel("Cantidad*:"));
        dialogo.add(txtCantidad);
        dialogo.add(new JLabel("Categoría*:"));
        dialogo.add(comboCategoria);
        dialogo.add(new JLabel("Impuesto:"));
        dialogo.add(comboImpuestos);
        dialogo.add(new JLabel("Descripción:"));
        dialogo.add(scrollPaneDescripcion);
        dialogo.add(new JLabel("Proveedor:"));
        dialogo.add(comboProveedor);
        dialogo.add(new JLabel());
        dialogo.add(btnGuardar);

        btnGuardar.addActionListener(a -> {
            try {
                String codigo = txtCodigo.getText().trim();
                String nombre = txtNombre.getText().trim();
                String costoStr = txtCosto.getText().trim();
                String porcentajeStr = txtPorcentajeGanancia.getText().trim();
                String cantidadStr = txtCantidad.getText().trim();
                String categoria = (String) comboCategoria.getSelectedItem();
                String impuesto = (String) comboImpuestos.getSelectedItem();
                String descripcion = txtDescripcion.getText().trim();
                ProveedorModel.Proveedor proveedor = (ProveedorModel.Proveedor) comboProveedor.getSelectedItem();

                if (codigo.isEmpty() || nombre.isEmpty() || costoStr.isEmpty() ||
                    porcentajeStr.isEmpty() || cantidadStr.isEmpty() || categoria.isEmpty()) {
                    view.mostrarError("Los campos marcados con * son obligatorios");
                    return;
                }

                double costo = Double.parseDouble(costoStr);
                double porcentaje = Double.parseDouble(porcentajeStr);
                double precioFinal = Double.parseDouble(txtPrecioFinal.getText().trim());
                int cantidad = Integer.parseInt(cantidadStr);

                if (model.buscarProductoPorCodigo(codigo) != null) {
                    view.mostrarError("El producto con este código ya existe");
                    return;
                }

                ProductoModel.Producto nuevoProducto = new ProductoModel.Producto(
                    codigo, nombre, precioFinal, cantidad, categoria, 
                    descripcion, proveedor, impuesto);

                model.agregarProducto(nuevoProducto, proveedor);
                cargarProductos();
                dialogo.dispose();

            } catch (NumberFormatException ex) {
                view.mostrarError("Datos numéricos inválidos");
            } catch (SQLException ex) {
                view.mostrarError("Error al guardar producto: " + ex.getMessage());
            }
        });

        dialogo.setVisible(true);
    }
    
    private void buscarProducto() {
        String busqueda = view.getTextoBusqueda();
        if (busqueda != null && !busqueda.trim().isEmpty()) {
            try {
                List<ProductoModel.Producto> resultados = model.buscarProductos(busqueda);
                
                if (resultados.isEmpty()) {
                    view.mostrarMensaje("No se encontraron productos", "Resultados de búsqueda");
                    cargarProductos();
                } else {
                    Object[][] datos = new Object[resultados.size()][7];
                    for (int i = 0; i < resultados.size(); i++) {
                        ProductoModel.Producto p = resultados.get(i);
                        datos[i][0] = p.getCodigo();
                        datos[i][1] = p.getNombre();
                        datos[i][2] = p.getPrecio();
                        datos[i][3] = p.getCantidad();
                        datos[i][4] = p.getCategoria();
                        datos[i][5] = p.getDescripcion();
                        datos[i][6] = p.getProveedor() != null ? p.getProveedor().getEmpresa() : "Sin proveedor";
                    }
                    view.cargarProductos(datos);
                }
            } catch (SQLException ex) {
                view.mostrarError("Error al buscar productos: " + ex.getMessage());
            }
        } else {
            cargarProductos();
        }
    }

    private void ajustarInventario(ActionEvent e) {
        int filaSeleccionada = view.getFilaSeleccionada();
        if (filaSeleccionada >= 0) {
            String codigo = view.getCodigoProductoSeleccionado();
            String nombre = (String) view.getModeloTabla().getValueAt(filaSeleccionada, 1);
            String[] opciones = {"Ajustar cantidad", "Modificar precio", "Cancelar"};
            int opcion = view.mostrarOpcionesAjuste("Ajustar Inventario",
                    "Seleccione el tipo de ajuste para " + nombre, opciones);

            if (opcion == 0) {
                String nuevaCantidadStr = view.pedirNuevoValor("Ingrese nueva cantidad para " + nombre + ":",
                        view.getModeloTabla().getValueAt(filaSeleccionada, 3));

                try {
                    int nuevaCantidad = Integer.parseInt(nuevaCantidadStr);
                    model.ajustarCantidad(codigo, nuevaCantidad);
                    cargarProductos();
                    actualizarAlertaStock();
                    view.mostrarMensaje("Cantidad actualizada correctamente", "Éxito");
                } catch (NumberFormatException ex) {
                    view.mostrarError("Cantidad inválida");
                } catch (SQLException ex) {
                    view.mostrarError("Error al actualizar cantidad: " + ex.getMessage());
                }
            } else if (opcion == 1) {
                String nuevoPrecioStr = view.pedirNuevoValor("Ingrese nuevo precio para " + nombre + ":",
                        view.getModeloTabla().getValueAt(filaSeleccionada, 2));

                try {
                    double nuevoPrecio = Double.parseDouble(nuevoPrecioStr);
                    model.modificarPrecio(codigo, nuevoPrecio);
                    cargarProductos();
                    view.mostrarMensaje("Precio actualizado correctamente", "Éxito");
                } catch (NumberFormatException ex) {
                    view.mostrarError("Precio inválido");
                } catch (SQLException ex) {
                    view.mostrarError("Error al actualizar precio: " + ex.getMessage());
                }
            }
        } else {
            view.mostrarError("Seleccione un producto para ajustar");
        }
    }

    private void eliminarProducto(ActionEvent e) {
        int filaSeleccionada = view.getFilaSeleccionada();
        if (filaSeleccionada >= 0) {
            String codigo = view.getCodigoProductoSeleccionado();
            int confirm = JOptionPane.showConfirmDialog(view,
                    "¿Está seguro de eliminar este producto?", "Confirmar Eliminación",
                    JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {
                try {
                    model.eliminarProducto(codigo);
                    cargarProductos();
                    actualizarAlertaStock();
                    view.mostrarMensaje("Producto eliminado correctamente", "Éxito");
                } catch (SQLException ex) {
                    view.mostrarError("Error al eliminar producto: " + ex.getMessage());
                }
            }
        } else {
            view.mostrarError("Seleccione un producto para eliminar");
        }
    }

    private void generarReportePDF(ActionEvent e) {
        try (PDDocument document = new PDDocument()) {
            PDPage page = new PDPage();
            document.addPage(page);

            try (PDPageContentStream contentStream = new PDPageContentStream(document, page)) {
                PDType1Font fontBold = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
                PDType1Font fontRegular = new PDType1Font(Standard14Fonts.FontName.HELVETICA);

                contentStream.setFont(fontBold, 16);
                contentStream.beginText();
                contentStream.newLineAtOffset(50, 750);
                contentStream.showText("La Esquinita");
                contentStream.newLineAtOffset(0, -20);
                contentStream.setFont(fontRegular, 12);
                contentStream.showText("Reporte de Inventario");
                contentStream.newLineAtOffset(0, -20);
                contentStream.showText("Fecha: " + java.time.LocalDate.now());
                contentStream.endText();

                float margin = 50;
                float yStart = 700;
                float tableWidth = page.getMediaBox().getWidth() - 2 * margin;
                float yPosition = yStart;
                float rowHeight = 20f;

                String[] headers = {"Código", "Producto", "Precio Unitario", "Cantidad"};
                float[] columnWidths = {80, 300, 100, 100};

                contentStream.setFont(fontBold, 12);
                for (int i = 0; i < headers.length; i++) {
                    contentStream.beginText();
                    contentStream.newLineAtOffset(margin + calculateOffset(columnWidths, i), yPosition);
                    contentStream.showText(headers[i]);
                    contentStream.endText();
                }

                contentStream.setLineWidth(1f);
                yPosition -= rowHeight;
                drawHorizontalLine(contentStream, margin, yPosition, tableWidth);

                contentStream.setFont(fontRegular, 12);
                for (int i = 0; i < view.getModeloTabla().getRowCount(); i++) {
                    yPosition -= rowHeight;
                    String codigo = (String) view.getModeloTabla().getValueAt(i, 0);
                    String producto = (String) view.getModeloTabla().getValueAt(i, 1);
                    double precio = (double) view.getModeloTabla().getValueAt(i, 2);
                    int cantidad = (int) view.getModeloTabla().getValueAt(i, 3);

                    String[] rowData = {codigo, producto, String.format("$%.2f", precio), String.valueOf(cantidad)};
                    for (int j = 0; j < rowData.length; j++) {
                        contentStream.beginText();
                        contentStream.newLineAtOffset(margin + calculateOffset(columnWidths, j), yPosition + 5);
                        contentStream.showText(rowData[j]);
                        contentStream.endText();
                    }
                    drawHorizontalLine(contentStream, margin, yPosition, tableWidth);
                }

                contentStream.setFont(fontRegular, 10);
                contentStream.beginText();
                contentStream.newLineAtOffset(margin, yPosition - 20);
                contentStream.showText("Generado automáticamente por el sistema.");
                contentStream.endText();
            }

            document.save("reporte_inventario.pdf");
            view.mostrarMensaje("Reporte generado exitosamente.", "Éxito");
        } catch (IOException ex) {
            view.mostrarError("Error al generar el reporte: " + ex.getMessage());
        }
    }
    
    private float calculateOffset(float[] columnWidths, int columnIndex) {
        float offset = 0;
        for (int i = 0; i < columnIndex; i++) {
            offset += columnWidths[i];
        }
        return offset;
    }
    
    private void drawHorizontalLine(PDPageContentStream contentStream, float xStart, float y, float width) throws IOException {
        contentStream.moveTo(xStart, y);
        contentStream.lineTo(xStart + width, y);
        contentStream.stroke();
    }

    private void editarProducto(ActionEvent e) {
        int filaSeleccionada = view.getFilaSeleccionada();
        if (filaSeleccionada >= 0) {
            String codigoProducto = (String) view.getModeloTabla().getValueAt(filaSeleccionada, 0);
            try {
                ProductoModel.Producto producto = model.buscarProductoPorCodigo(codigoProducto);
                if (producto != null) {
                    JDialog dialogoEditar = new JDialog(view, "Editar Producto", true);
                    dialogoEditar.setSize(500, 500);
                    dialogoEditar.setLayout(new GridLayout(10, 2, 5, 5));

                    JTextField txtCodigo = new JTextField(producto.getCodigo());
                    txtCodigo.setEditable(false);
                    JTextField txtNombre = new JTextField(producto.getNombre());
                    JTextField txtPrecio = new JTextField(String.valueOf(producto.getPrecio()));
                    JTextField txtCantidad = new JTextField(String.valueOf(producto.getCantidad()));

                    DefaultComboBoxModel<String> modeloCategoria = new DefaultComboBoxModel<>();
                    for (String cat : categoriaModel.getCategorias()) {
                        modeloCategoria.addElement(cat);
                    }
                    JComboBox<String> comboCategoria = new JComboBox<>(modeloCategoria);
                    comboCategoria.setSelectedItem(producto.getCategoria());

                    JComboBox<String> comboImpuestos = new JComboBox<>(ProductoModel.IMPUESTOS);
                    comboImpuestos.setSelectedItem(producto.getImpuesto());

                    JTextArea txtDescripcion = new JTextArea(3, 20);
                    txtDescripcion.setText(producto.getDescripcion());
                    JScrollPane scrollPaneDescripcion = new JScrollPane(txtDescripcion);

                    JComboBox<ProveedorModel.Proveedor> comboProveedor = new JComboBox<>();
                    comboProveedor.setRenderer(new DefaultListCellRenderer() {
                        @Override
                        public Component getListCellRendererComponent(JList<?> list, Object value, 
                                int index, boolean isSelected, boolean cellHasFocus) {
                            super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                            if (value instanceof ProveedorModel.Proveedor) {
                                setText(((ProveedorModel.Proveedor) value).getEmpresa());
                            } else if (value == null) {
                                setText("Sin proveedor");
                            }
                            return this;
                        }
                    });

                    try {
                        List<ProveedorModel.Proveedor> proveedores = ProveedorModel.getProveedores();
                        DefaultComboBoxModel<ProveedorModel.Proveedor> modeloProveedor = new DefaultComboBoxModel<>();
                        modeloProveedor.addElement(null);
                        for (ProveedorModel.Proveedor prov : proveedores) {
                            modeloProveedor.addElement(prov);
                        }
                        comboProveedor.setModel(modeloProveedor);
                        comboProveedor.setSelectedItem(producto.getProveedor());
                    } catch (SQLException ex) {
                        view.mostrarError("Error al cargar proveedores: " + ex.getMessage());
                    }

                    JButton btnGuardar = new JButton("Guardar");

                    dialogoEditar.add(new JLabel("Código (no editable):"));
                    dialogoEditar.add(txtCodigo);
                    dialogoEditar.add(new JLabel("Nombre:"));
                    dialogoEditar.add(txtNombre);
                    dialogoEditar.add(new JLabel("Precio unitario:"));
                    dialogoEditar.add(txtPrecio);
                    dialogoEditar.add(new JLabel("Cantidad en stock:"));
                    dialogoEditar.add(txtCantidad);
                    dialogoEditar.add(new JLabel("Categoría:"));
                    dialogoEditar.add(comboCategoria);
                    dialogoEditar.add(new JLabel("Impuesto:"));
                    dialogoEditar.add(comboImpuestos);
                    dialogoEditar.add(new JLabel("Descripción:"));
                    dialogoEditar.add(scrollPaneDescripcion);
                    dialogoEditar.add(new JLabel("Proveedor:"));
                    dialogoEditar.add(comboProveedor);
                    dialogoEditar.add(new JLabel());
                    dialogoEditar.add(btnGuardar);

                    btnGuardar.addActionListener(a -> {
                        try {
                            String nuevoNombre = txtNombre.getText().trim();
                            String nuevoPrecioStr = txtPrecio.getText().trim();
                            String nuevaCantidadStr = txtCantidad.getText().trim();
                            String nuevaCategoria = (String) comboCategoria.getSelectedItem();
                            String nuevoImpuesto = (String) comboImpuestos.getSelectedItem();
                            String nuevaDescripcion = txtDescripcion.getText().trim();
                            ProveedorModel.Proveedor nuevoProveedor = (ProveedorModel.Proveedor) comboProveedor.getSelectedItem();

                            if (nuevoNombre.isEmpty() || nuevoPrecioStr.isEmpty() || 
                                nuevaCantidadStr.isEmpty() || nuevaCategoria.isEmpty()) {
                                view.mostrarError("Todos los campos son obligatorios");
                                return;
                            }

                            double nuevoPrecio = Double.parseDouble(nuevoPrecioStr);
                            int nuevaCantidad = Integer.parseInt(nuevaCantidadStr);

                            producto.setNombre(nuevoNombre);
                            producto.setPrecio(nuevoPrecio);
                            producto.setCantidad(nuevaCantidad);
                            producto.setCategoria(nuevaCategoria);
                            producto.setImpuesto(nuevoImpuesto);
                            producto.setDescripcion(nuevaDescripcion);
                            producto.setProveedor(nuevoProveedor);

                            model.modificarPrecio(producto.getCodigo(), nuevoPrecio);
                            model.ajustarCantidad(producto.getCodigo(), nuevaCantidad);
                            
                            String query = "UPDATE productos SET id_proveedor = ?, impuesto = ? WHERE codigo = ?";
                            try (Connection conn = ConexionBD.getConnection();
                                 PreparedStatement stmt = conn.prepareStatement(query)) {
                                stmt.setString(1, nuevoProveedor != null ? nuevoProveedor.getId() : null);
                                stmt.setString(2, nuevoImpuesto);
                                stmt.setString(3, producto.getCodigo());
                                stmt.executeUpdate();
                            }

                            cargarProductos();
                            actualizarAlertaStock();
                            dialogoEditar.dispose();
                            
                        } catch (NumberFormatException ex) {
                            view.mostrarError("Precio y cantidad deben ser números válidos");
                        } catch (SQLException ex) {
                            view.mostrarError("Error al actualizar producto: " + ex.getMessage());
                        }
                    });

                    dialogoEditar.setVisible(true);
                } else {
                    view.mostrarError("Producto no encontrado");
                }
            } catch (SQLException ex) {
                view.mostrarError("Error al buscar producto: " + ex.getMessage());
            }
        } else {
            view.mostrarError("Seleccione un producto para editar");
        }
    }
    
    private void limpiarBusqueda() {
        view.limpiarBusqueda();
        cargarProductos();
    }
}