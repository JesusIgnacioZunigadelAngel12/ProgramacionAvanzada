package Controlador;

import Modelo.VentaModel;
import Vista.VentasView;
import java.awt.event.ActionEvent;
import javax.swing.JOptionPane;
import java.util.List;

public class VentasController {
    private VentaModel model;
    private VentasView view;

    public VentasController(VentaModel model, VentasView view) {
        this.model = model;
        this.view = view;

        view.getBtnDetalle().addActionListener(this::verDetalleVenta);
        view.getBtnReimprimir().addActionListener(this::reimprimirTicket);
        view.getBtnSalir().addActionListener(e -> view.dispose());

        cargarVentas();
    }

    private void cargarVentas() {
        try {
            List<VentaModel.Venta> ventas = model.getVentas();
            Object[][] datos = convertirVentasAMatriz(ventas);
            view.cargarVentas(datos);
        } catch (Exception e) {
            view.mostrarError("Error al cargar ventas: " + e.getMessage());
        }
    }

    private void verDetalleVenta(ActionEvent e) {
        int filaSeleccionada = view.getFilaSeleccionada();
        if (filaSeleccionada >= 0) {
            String folio = (String) view.getModeloTabla().getValueAt(filaSeleccionada, 0);
            try {
                String detalle = model.getDetalleVenta(folio);
                view.mostrarMensaje(detalle, "Detalle de Venta");
            } catch (Exception ex) {
                view.mostrarError("Error al obtener detalle: " + ex.getMessage());
            }
        } else {
            view.mostrarError("Seleccione una venta para ver el detalle");
        }
    }

    private void reimprimirTicket(ActionEvent e) {
        int filaSeleccionada = view.getFilaSeleccionada();
        if (filaSeleccionada >= 0) {
            String folio = (String) view.getModeloTabla().getValueAt(filaSeleccionada, 0);
            try {
                String detalle = model.getDetalleVenta(folio);
                view.mostrarMensaje("SIMULANDO IMPRESIÓN DE TICKET:\n" + detalle, "Reimpresión Ticket #" + folio);
            } catch (Exception ex) {
                view.mostrarError("Error al reimprimir ticket: " + ex.getMessage());
            }
        } else {
            view.mostrarError("Seleccione una venta para reimprimir");
        }
    }

    private Object[][] convertirVentasAMatriz(List<VentaModel.Venta> ventas) {
        Object[][] datos = new Object[ventas.size()][6];
        int i = 0;
        for (VentaModel.Venta v : ventas) {
            datos[i][0] = v.getFolio();
            datos[i][1] = v.getFecha();
            datos[i][2] = v.getHora();
            datos[i][3] = v.getTotal();
            datos[i][4] = v.getMetodoPago();
            datos[i][5] = v.getAtendio();
            i++;
        }
        return datos;
    }
}