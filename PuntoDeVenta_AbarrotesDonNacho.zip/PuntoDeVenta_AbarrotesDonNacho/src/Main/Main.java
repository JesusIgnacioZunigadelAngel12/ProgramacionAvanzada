package Main;

import javax.swing.SwingUtilities;
import Modelo.*;
import Modelo.UsuarioModel;

import Vista.*;
import Controlador.*;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
        	
            UsuarioModel usuarioModel = new UsuarioModel();
            LoginView loginView = new LoginView();
            new LoginController(loginView, usuarioModel);
            
            loginView.setVisible(true);
        });
    }
}