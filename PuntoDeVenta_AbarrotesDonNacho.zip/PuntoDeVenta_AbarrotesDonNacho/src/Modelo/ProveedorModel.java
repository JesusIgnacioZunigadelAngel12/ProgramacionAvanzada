package Modelo;

import java.util.ArrayList;
import java.util.List;

import Conexion.ConexionBD;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProveedorModel {
    private static ConexionBD conexionBD;

    public ProveedorModel() {
        this.conexionBD = new ConexionBD();
    }

    // Método para agregar un proveedor
    public void agregarProveedor(Proveedor proveedor) throws SQLException {
        String query = "INSERT INTO proveedores (id, empresa, nombre_contacto, telefono_contacto) VALUES (?, ?, ?, ?)";
        try (Connection conn = conexionBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, proveedor.getId());
            stmt.setString(2, proveedor.getEmpresa());
            stmt.setString(3, proveedor.getContacto());
            stmt.setString(4, proveedor.getTelefonoContacto());
            stmt.executeUpdate();
        }
    }

    // Método para buscar proveedores por texto
    public List<Proveedor> buscarProveedores(String busqueda) throws SQLException {
        List<Proveedor> resultados = new ArrayList<>();
        String query = "SELECT * FROM proveedores WHERE empresa LIKE ? OR id = ?";
        try (Connection conn = conexionBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, "%" + busqueda + "%");
            stmt.setString(2, busqueda);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                resultados.add(new Proveedor(
                    rs.getString("id"),
                    rs.getString("empresa"),
                    rs.getString("nombre_contacto"),
                    rs.getString("telefono_contacto")
                ));
            }
        }
        return resultados;
    }

    // Método para eliminar un proveedor
    public void eliminarProveedor(String id) throws SQLException {
        String query = "DELETE FROM proveedores WHERE id = ?";
        try (Connection conn = conexionBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, id);
            stmt.executeUpdate();
        }
    }

    // Método para actualizar un proveedor
    public void actualizarProveedor(Proveedor proveedor) throws SQLException {
        String query = "UPDATE proveedores SET empresa = ?, nombre_contacto = ?, telefono_contacto = ? WHERE id = ?";
        try (Connection conn = conexionBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, proveedor.getEmpresa());
            stmt.setString(2, proveedor.getContacto());
            stmt.setString(3, proveedor.getTelefonoContacto());
            stmt.setString(4, proveedor.getId());
            stmt.executeUpdate();
        }
    }

    // Método para obtener todos los proveedores
    public static List<Proveedor> getProveedores() throws SQLException {
        List<Proveedor> proveedores = new ArrayList<>();
        String query = "SELECT * FROM proveedores";
        try (Connection conn = conexionBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                proveedores.add(new Proveedor(
                    rs.getString("id"),
                    rs.getString("empresa"),
                    rs.getString("nombre_contacto"),
                    rs.getString("telefono_contacto")
                ));
            }
        }
        return proveedores;
    }

    // Clase interna para representar un proveedor
    public static class Proveedor {
        private String id;
        private String empresa;
        private String contacto;
        private String telefonoContacto;

        public Proveedor(String id, String empresa, String contacto, String telefonoContacto) {
            this.id = id;
            this.empresa = empresa;
            this.contacto = contacto;
            this.telefonoContacto = telefonoContacto;
        }

        // Getters y setters
        public String getId() { return id; }
        public void setId(String id) { this.id = id; }
        public String getEmpresa() { return empresa; }
        public void setEmpresa(String empresa) { this.empresa = empresa; }
        public String getContacto() { return contacto; }
        public void setContacto(String contacto) { this.contacto = contacto; }
        public String getTelefonoContacto() { return telefonoContacto; }
        public void setTelefonoContacto(String telefonoContacto) { this.telefonoContacto = telefonoContacto; }
    }
}