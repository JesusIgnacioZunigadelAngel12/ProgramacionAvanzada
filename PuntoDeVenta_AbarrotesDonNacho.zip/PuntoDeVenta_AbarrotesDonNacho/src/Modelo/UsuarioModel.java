package Modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Conexion.ConexionBD;

public class UsuarioModel {
    private ConexionBD conexionBD;

    public UsuarioModel() {
        this.conexionBD = new ConexionBD();
    }

    public class Usuario {
        private String username;
        private String password;
        private String rol;
        private String telefono;  // Nuevo campo

        public Usuario(String username, String password, String rol, String telefono) {
            this.username = username;
            this.password = password;
            this.rol = rol;
            this.telefono = telefono;
        }

        // Getters y setters
        public String getUsername() { return username; }
        public String getPassword() { return password; }
        public String getRol() { return rol; }
        public String getTelefono() { return telefono; }  // Nuevo getter
    }

    public void agregarUsuario(String username, String password, String rol, String telefono) throws SQLException {
        String query = "INSERT INTO usuarios (username, password, rol, telefono) VALUES (?, ?, ?, ?)";
        try (Connection conn = conexionBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, username);
            stmt.setString(2, password);
            stmt.setString(3, rol);
            stmt.setString(4, telefono);
            stmt.executeUpdate();
        }
    }

    public boolean autenticar(String username, String password) throws SQLException {
        String query = "SELECT * FROM usuarios WHERE username = ? AND password = ?";
        try (Connection conn = conexionBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, username);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        }
    }
    
    public boolean esAdmin(String username) throws SQLException {
        String query = "SELECT COUNT(*) FROM usuarios WHERE username = ? AND rol = 'ADMIN'";
        try (Connection conn = conexionBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, username);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        }
        return false;
    }

    public boolean usuarioExiste(String username) throws SQLException {
        String query = "SELECT * FROM usuarios WHERE username = ?";
        try (Connection conn = conexionBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        }
    }
    
    public void actualizarContrasena(String username, String nuevaPassword) throws SQLException {
        String query = "UPDATE usuarios SET password = ? WHERE username = ?";
        try (Connection conn = conexionBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, nuevaPassword);
            stmt.setString(2, username);
            stmt.executeUpdate();
        }
    }

    public List<Usuario> getUsuarios() throws SQLException {
        List<Usuario> usuarios = new ArrayList<>();
        String query = "SELECT username, password, rol, telefono FROM usuarios";
        try (Connection conn = conexionBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                usuarios.add(new Usuario(
                    rs.getString("username"),
                    rs.getString("password"),
                    rs.getString("rol"),
                    rs.getString("telefono")
                ));
            }
        }
        return usuarios;
    }
    
    public void eliminarUsuario(String username) throws SQLException {
        String query = "DELETE FROM usuarios WHERE username = ?";
        try (Connection conn = conexionBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, username);
            stmt.executeUpdate();
        }
    }

    public List<Usuario> buscarUsuarios(String busqueda) throws SQLException {
        List<Usuario> resultados = new ArrayList<>();
        String query = "SELECT * FROM usuarios WHERE username LIKE ? OR telefono LIKE ?";
        try (Connection conn = conexionBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, "%" + busqueda + "%");
            stmt.setString(2, "%" + busqueda + "%");
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                resultados.add(new Usuario(
                    rs.getString("username"),
                    rs.getString("password"),
                    rs.getString("rol"),
                    rs.getString("telefono")
                ));
            }
        }
        return resultados;
    }
    
    public void actualizarUsuario(String username, String password, String rol, String telefono) throws SQLException {
        String query = "UPDATE usuarios SET password = ?, rol = ?, telefono = ? WHERE username = ?";
        try (Connection conn = conexionBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, password);
            stmt.setString(2, rol);
            stmt.setString(3, telefono);
            stmt.setString(4, username);
            stmt.executeUpdate();
        }
    }
    
    public boolean verificarTelefono(String username, String telefono) throws SQLException {
        String query = "SELECT COUNT(*) FROM usuarios WHERE username = ? AND telefono = ?";
        try (Connection conn = conexionBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, username);
            stmt.setString(2, telefono);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        }
        return false;
    }

}