package Modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import Conexion.ConexionBD;

public class ProductoModel {
	
    private ConexionBD conexionBD;
    
    public static final String[] IMPUESTOS = {"Ninguno", "IVA 16%", "IVA 8%", "IEPS 5%"};
    public static final double[] PORCENTAJES_IMPUESTOS = {0.0, 0.16, 0.08, 0.05};
   
    public ProductoModel() {
        this.conexionBD = new ConexionBD();
    }
    
    public static class Producto {
        private String codigo;
        private String nombre;
        private double precio;
        private int cantidad;
        private String categoria;
        private String descripcion;
        private ProveedorModel.Proveedor proveedor;
        private String impuesto;
        private String imagenPath;
        
        public Producto(String codigo, String nombre, double precio, int cantidad, 
                       String categoria, String descripcion, 
                       ProveedorModel.Proveedor proveedor, String impuesto, String imagenPath) {
            this.codigo = codigo;
            this.nombre = nombre;
            this.precio = precio;
            this.cantidad = cantidad;
            this.categoria = categoria;
            this.descripcion = descripcion;
            this.proveedor = proveedor;
            this.impuesto = impuesto;
            this.imagenPath = imagenPath;
        }

        // Getters y setters
        public String getCodigo() { return codigo; }
        public void setCodigo(String codigo) { this.codigo = codigo; }
        
        public String getNombre() { return nombre; }
        public void setNombre(String nombre) { this.nombre = nombre; }
        
        public String getCategoria() { return categoria; }
        public void setCategoria(String categoria) { this.categoria = categoria; }
        
        public String getDescripcion() { return descripcion; }
        public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
       
        public double getPrecio() { return precio; }
        public void setPrecio(double precio) { this.precio = precio; }
        
        public int getCantidad() { return cantidad; }
        public void setCantidad(int cantidad) { this.cantidad = cantidad; }
        
        public ProveedorModel.Proveedor getProveedor() { return proveedor; }
        public void setProveedor(ProveedorModel.Proveedor proveedor) { this.proveedor = proveedor; }
        
        public String getImpuesto() { return impuesto; }
        public void setImpuesto(String impuesto) { this.impuesto = impuesto; }
        
        public String getImagenPath() { return imagenPath; }
        public void setImagenPath(String imagenPath) { this.imagenPath = imagenPath; }
        
        // Método para calcular el precio con impuesto
        public double getPrecioConImpuesto() {
            int index = -1;
            for (int i = 0; i < IMPUESTOS.length; i++) {
                if (IMPUESTOS[i].equals(impuesto)) {
                    index = i;
                    break;
                }
            }
            if (index >= 0) {
                return precio * (1 + PORCENTAJES_IMPUESTOS[index]);
            }
            return precio;
        }
    }
    
    // Método para agregar un producto
    public void agregarProducto(Producto producto, ProveedorModel.Proveedor proveedor) throws SQLException {
        String query = "INSERT INTO productos (codigo, nombre, precio, cantidad, categoria, descripcion, id_proveedor, impuesto, imagen) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = conexionBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, producto.getCodigo());
            stmt.setString(2, producto.getNombre());
            stmt.setDouble(3, producto.getPrecio());
            stmt.setInt(4, producto.getCantidad());
            stmt.setString(5, producto.getCategoria());
            stmt.setString(6, producto.getDescripcion());
            stmt.setString(7, proveedor != null ? proveedor.getId() : null);
            stmt.setString(8, producto.getImpuesto());
            stmt.setString(9, producto.getImagenPath());
            stmt.executeUpdate();
        }
    }

    // Método para ajustar la cantidad de un producto
    public void ajustarCantidad(String codigo, int nuevaCantidad) throws SQLException {
        String query = "UPDATE productos SET cantidad = ? WHERE codigo = ?";
        try (Connection conn = conexionBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, nuevaCantidad);
            stmt.setString(2, codigo);
            stmt.executeUpdate();
        }
    }

    // Método para modificar el precio de un producto
    public void modificarPrecio(String codigo, double nuevoPrecio) throws SQLException {
        String query = "UPDATE productos SET precio = ? WHERE codigo = ?";
        try (Connection conn = conexionBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setDouble(1, nuevoPrecio);
            stmt.setString(2, codigo);
            stmt.executeUpdate();
        }
    }

    // Método para eliminar un producto
    public void eliminarProducto(String codigo) throws SQLException {
        String query = "DELETE FROM productos WHERE codigo = ?";
        try (Connection conn = conexionBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, codigo);
            stmt.executeUpdate();
        }
    }

    // Método para buscar un producto por código
    public Producto buscarProductoPorCodigo(String codigo) throws SQLException {
        String query = "SELECT p.*, pr.empresa FROM productos p LEFT JOIN proveedores pr ON p.id_proveedor = pr.id WHERE p.codigo = ?";
        try (Connection conn = conexionBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, codigo);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return mapearProducto(rs);
            }
            return null;
        }
    }

    public List<Producto> buscarProductos(String busqueda) throws SQLException {
        List<Producto> resultados = new ArrayList<>();
        String query = "SELECT p.*, pr.empresa FROM productos p LEFT JOIN proveedores pr ON p.id_proveedor = pr.id " +
                       "WHERE p.nombre LIKE ? OR p.codigo LIKE ?";
        try (Connection conn = conexionBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, "%" + busqueda + "%");
            stmt.setString(2, "%" + busqueda + "%");
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                resultados.add(mapearProducto(rs));
            }
        }
        return resultados;
    }
    
    public List<Producto> getProductos() throws SQLException {
        List<Producto> productos = new ArrayList<>();
        String query = "SELECT p.*, pr.empresa FROM productos p LEFT JOIN proveedores pr ON p.id_proveedor = pr.id";
        try (Connection conn = conexionBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                productos.add(mapearProducto(rs));
            }
        }
        return productos;
    }
    
    private Producto mapearProducto(ResultSet rs) throws SQLException {
        String idProveedor = rs.getString("id_proveedor");
        ProveedorModel.Proveedor proveedor = null;
        
        if (idProveedor != null) {
            proveedor = new ProveedorModel.Proveedor(
                idProveedor,
                rs.getString("empresa"),
                null,
                null
            );
        }
        
        return new Producto(
            rs.getString("codigo"),
            rs.getString("nombre"),
            rs.getDouble("precio"),
            rs.getInt("cantidad"),
            rs.getString("categoria"),
            rs.getString("descripcion"),
            proveedor,
            rs.getString("impuesto"),
            rs.getString("imagen")// Nuevo campo
        );
    }
    
    public int contarProductosConStockBajo(int stockMinimo) throws SQLException {
        String query = "SELECT COUNT(*) FROM productos WHERE cantidad < ?";
        try (Connection conn = conexionBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, stockMinimo);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return 0;
    }
    
    
}