package Modelo;

import Conexion.ConexionBD;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ClienteModel {

    private ConexionBD conexionBD;

    public ClienteModel() throws SQLException {
        this.conexionBD = new ConexionBD();
    }

    // CRUD Operations

    public void agregarCliente(Cliente cliente) throws SQLException {
        String query = "INSERT INTO Clientes (id_cliente, nombre, telefono, correo_electronico) VALUES (?, ?, ?, ?)";
        try (Connection conn = conexionBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, cliente.getId());
            stmt.setString(2, cliente.getNombre());
            stmt.setString(3, cliente.getTelefono());
            stmt.setString(4, cliente.getCorreoElectronico());
            stmt.executeUpdate();
        }
    }

    public void actualizarCliente(Cliente cliente) throws SQLException {
        String query = "UPDATE Clientes SET nombre = ?, telefono = ?, correo_electronico = ? WHERE id_cliente = ?";
        try (Connection conn = conexionBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, cliente.getNombre());
            stmt.setString(2, cliente.getTelefono());
            stmt.setString(3, cliente.getCorreoElectronico());
            stmt.setString(4, cliente.getId());
            stmt.executeUpdate();
        }
    }

    public void eliminarCliente(String idCliente) throws SQLException {
        String query = "DELETE FROM Clientes WHERE id_cliente = ?";
        try (Connection conn = conexionBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, idCliente);
            stmt.executeUpdate();
        }
    }

    public Cliente buscarClientePorId(String id) throws SQLException {
        String query = "SELECT * FROM Clientes WHERE id_cliente = ?";
        try (Connection conn = conexionBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Cliente(
                    rs.getString("id_cliente"),
                    rs.getString("nombre"),
                    rs.getString("telefono"),
                    rs.getString("correo_electronico")
                );
            }
        }
        return null;
    }

    public List<Cliente> buscarClientes(String busqueda) throws SQLException {
        List<Cliente> resultados = new ArrayList<>();
        String query = "SELECT * FROM Clientes WHERE nombre LIKE ? OR id_cliente LIKE ?";
        try (Connection conn = conexionBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            String param = "%" + busqueda + "%";
            stmt.setString(1, param);
            stmt.setString(2, param);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                resultados.add(new Cliente(
                    rs.getString("id_cliente"),
                    rs.getString("nombre"),
                    rs.getString("telefono"),
                    rs.getString("correo_electronico")
                ));
            }
        }
        return resultados;
    }

    public List<Cliente> getTodosClientes() throws SQLException {
        List<Cliente> clientes = new ArrayList<>();
        String query = "SELECT * FROM Clientes ORDER BY nombre ASC";
        try (Connection conn = conexionBD.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                clientes.add(new Cliente(
                    rs.getString("id_cliente"),
                    rs.getString("nombre"),
                    rs.getString("telefono"),
                    rs.getString("correo_electronico")
                ));
            }
        }
        return clientes;
    }

    public static class Cliente {
        private String id;
        private String nombre;
        private String telefono;
        private String correoElectronico;

        public Cliente(String id, String nombre, String telefono, String correoElectronico) {
            this.id = id;
            this.nombre = nombre;
            this.telefono = telefono;
            this.correoElectronico = correoElectronico;
        }

        // Getters and Setters
        public String getId() { return id; }
        public void setId(String id) { this.id = id; }
        public String getNombre() { return nombre; }
        public void setNombre(String nombre) { this.nombre = nombre; }
        public String getTelefono() { return telefono; }
        public void setTelefono(String telefono) { this.telefono = telefono; }
        public String getCorreoElectronico() { return correoElectronico; }
        public void setCorreoElectronico(String correoElectronico) { this.correoElectronico = correoElectronico; }
    }
}