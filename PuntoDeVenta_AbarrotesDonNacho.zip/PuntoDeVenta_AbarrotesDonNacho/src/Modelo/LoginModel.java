package Modelo;

import Conexion.ConexionBD;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginModel {
    private UsuarioModel usuarioModel;
    
    public LoginModel() {
        this.usuarioModel = new UsuarioModel();
    }
    
    public boolean autenticar(String username, String password) throws SQLException {
        String query = "SELECT * FROM usuarios WHERE username = ? AND password = ?";
        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, username);
            stmt.setString(2, password);
            try (ResultSet rs = stmt.executeQuery()) {
                return rs.next(); // Retorna true si encuentra un usuario con esas credenciales
            }
        }
    }
    
    public boolean probarConexion() {
        try (Connection conn = ConexionBD.getConnection()) {
            return conn != null && !conn.isClosed();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}