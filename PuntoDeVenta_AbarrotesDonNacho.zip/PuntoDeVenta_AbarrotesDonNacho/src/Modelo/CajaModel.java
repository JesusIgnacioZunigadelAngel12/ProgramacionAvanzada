package Modelo;

import Conexion.ConexionBD;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class CajaModel {
    private final ConexionBD conexionBD;

    public CajaModel() throws SQLException {
        this.conexionBD = new ConexionBD();
    }

    public void abrirCaja(double montoInicial, String usuario) throws SQLException {
        Connection conn = null;
        try {
            conn = conexionBD.getConnection();
            conn.setAutoCommit(false);
            
            // Registrar movimiento de apertura
            String sqlMov = "INSERT INTO MovimientosCaja (Tipo, Monto, Fecha, Descripcion, Usuario) " +
                           "VALUES (?, ?, GETDATE(), ?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(sqlMov)) {
                pstmt.setString(1, "APERTURA");
                pstmt.setDouble(2, montoInicial);
                pstmt.setString(3, "Apertura de caja");
                pstmt.setString(4, usuario);
                pstmt.executeUpdate();
            }
            
            // Registrar estado de caja
            String sqlEstado = "INSERT INTO EstadoCaja (FechaHora, SaldoInicial, Estado, Usuario) " +
                             "VALUES (GETDATE(), ?, ?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(sqlEstado)) {
                pstmt.setDouble(1, montoInicial);
                pstmt.setString(2, "ABIERTA");
                pstmt.setString(3, usuario);
                pstmt.executeUpdate();
            }
            
            conn.commit();
        } catch (SQLException e) {
            if (conn != null) conn.rollback();
            throw e;
        } finally {
            if (conn != null) conn.setAutoCommit(true);
        }
    }

    public boolean existeCajaAbierta() throws SQLException {
        String sql = "SELECT TOP 1 Estado FROM EstadoCaja WHERE Estado = 'ABIERTA' ORDER BY FechaHora DESC";
        try (Connection conn = conexionBD.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            return rs.next() && rs.getString("Estado").equals("ABIERTA");
        }
    }

    public void cerrarCaja(String usuario) throws SQLException {
        double saldoFinal = getSaldoActual();
        Connection conn = null;
        try {
            conn = conexionBD.getConnection();
            conn.setAutoCommit(false);
            
            // Registrar movimiento de cierre
            String sqlMov = "INSERT INTO MovimientosCaja (Tipo, Monto, Fecha, Descripcion, Usuario) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(sqlMov)) {
                pstmt.setString(1, "CIERRE");
                pstmt.setDouble(2, saldoFinal);
                pstmt.setString(3, LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
                pstmt.setString(4, "Cierre de caja");
                pstmt.setString(5, usuario);
                pstmt.executeUpdate();
            }
            
            // Actualizar estado de caja
            String sqlEstado = "UPDATE EstadoCaja SET SaldoFinal = ?, Estado = ?, Usuario = ?, FechaCierre = GETDATE() " + 
                               "WHERE Estado = 'ABIERTA'";
            try (PreparedStatement pstmt = conn.prepareStatement(sqlEstado)) {
                pstmt.setDouble(1, saldoFinal);
                pstmt.setString(2, "CERRADA");
                pstmt.setString(3, usuario);
                int affectedRows = pstmt.executeUpdate();
                if (affectedRows == 0) {
                    throw new SQLException("No se encontró registro de caja abierta");
                }
            }
            
            conn.commit();
        } catch (SQLException e) {
            if (conn != null) conn.rollback();
            throw e;
        } finally {
            if (conn != null) conn.setAutoCommit(true);
        }
    }

    public void registrarMovimiento(String tipo, double monto, String usuario) throws SQLException {
        if (tipo.equals("RETIRO") && monto > getSaldoActual()) {
            throw new IllegalArgumentException("Fondos insuficientes");
        }
        String sql = "INSERT INTO MovimientosCaja (Tipo, Monto, Fecha, Descripcion, Usuario) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = conexionBD.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, tipo);
            pstmt.setDouble(2, monto);
            pstmt.setString(3, LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
            pstmt.setString(4, tipo.equals("DEPOSITO") ? "Depósito en efectivo" : "Retiro de efectivo");
            pstmt.setString(5, usuario);
            pstmt.executeUpdate();
        }
    }

    public double getSaldoActual() throws SQLException {
        String sql = "SELECT SUM(CASE WHEN Tipo = 'APERTURA' OR Tipo = 'DEPOSITO' THEN Monto ELSE -Monto END) AS Saldo " +
                     "FROM MovimientosCaja";
        try (Connection conn = conexionBD.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            return rs.next() ? rs.getDouble("Saldo") : 0;
        }
    }

    public List<String> getMovimientosDelDia() throws SQLException {
        List<String> movimientos = new ArrayList<>();
        String sql = "SELECT Tipo, Monto, Fecha, Descripcion FROM MovimientosCaja " +
                     "WHERE CONVERT(DATE, Fecha) = CONVERT(DATE, GETDATE()) " +
                     "ORDER BY Fecha DESC";
        try (Connection conn = conexionBD.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                movimientos.add(String.format("%s - %s: $%.2f (%s)",
                    rs.getString("Fecha"),
                    rs.getString("Tipo"),
                    rs.getDouble("Monto"),
                    rs.getString("Descripcion")));
            }
        }
        return movimientos;
    }

    public boolean isCajaAbierta() throws SQLException {
        return existeCajaAbierta();
    }

    public String getEstadoCaja() throws SQLException {
        String sql = "SELECT TOP 1 Estado FROM EstadoCaja ORDER BY FechaHora DESC";
        try (Connection conn = conexionBD.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            return rs.next() ? rs.getString("Estado") : "CERRADA";
        }
    }

    public String obtenerHistorialDelDia() throws SQLException {
        StringBuilder historial = new StringBuilder();
        historial.append("=== HISTORIAL DE MOVIMIENTOS ===\n");
        String sql = "SELECT Tipo, Monto, Fecha, Descripcion FROM MovimientosCaja " +
                     "WHERE CONVERT(DATE, Fecha) = CONVERT(DATE, GETDATE()) " +
                     "ORDER BY Fecha DESC";
        try (Connection conn = conexionBD.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                // Formateamos la fecha para que sea más legible
                String fecha = rs.getTimestamp("Fecha").toLocalDateTime()
                              .format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));
                historial.append(String.format(
                    "• %s - %-8s: $%,.2f\n   (%s)\n",
                    fecha,
                    rs.getString("Tipo"),
                    rs.getDouble("Monto"),
                    rs.getString("Descripcion")
                ));
            }
        }
        historial.append(String.format("\nSALDO ACTUAL: $%,.2f", getSaldoActual()));
        return historial.toString();
    }

    public String obtenerInfoApertura() throws SQLException {
        String sql = "SELECT TOP 1 SaldoInicial, Usuario FROM EstadoCaja WHERE Estado = 'ABIERTA' ORDER BY FechaHora DESC";
        try (Connection conn = conexionBD.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) {
                return String.format(
                    "Saldo inicial: $%.2f | Abierta por: %s",
                    rs.getDouble("SaldoInicial"),
                    rs.getString("Usuario")
                );
            }
        }
        return "";
    }

    public boolean tieneMovimientosHoy() throws SQLException {
        String sql = "SELECT COUNT(*) AS Total FROM MovimientosCaja " +
                     "WHERE CONVERT(DATE, Fecha) = CONVERT(DATE, GETDATE())";
        try (Connection conn = conexionBD.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            return rs.next() && rs.getInt("Total") > 0;
        }
    }
    
    public void registrarMovimientoEnCaja(String tipo, double monto, String descripcion, String usuario) throws SQLException {
        String query = "INSERT INTO MovimientosCaja (Tipo, Monto, Fecha, Descripcion, Usuario) " +
                       "VALUES (?, ?, GETDATE(), ?, ?)";
        
        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, tipo);           // Tipo (ej: 'ENTRADA')
            stmt.setDouble(2, monto);          // Monto
            stmt.setString(3, descripcion);    // Descripción
            stmt.setString(4, usuario);        // Usuario

            stmt.executeUpdate();
        }
    }
}
