package Modelo;

import java.time.LocalDateTime;

public class MovimientoCaja {
    private String tipo;
    private double monto;
    private LocalDateTime fechaHora;
    
    public MovimientoCaja(String tipo, double monto) {
        this.tipo = tipo;
        this.monto = monto;
        this.fechaHora = LocalDateTime.now();
    }
    
    public String getTipo() { return tipo; }
    public double getMonto() { return monto; }
    public LocalDateTime getFechaHora() { return fechaHora; }
}