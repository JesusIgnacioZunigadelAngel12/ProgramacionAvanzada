package Modelo;

import Conexion.ConexionBD;
import Modelo.ClienteModel.Cliente;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class VentaModel {
	public static class Venta {
	    private String folio;
	    private String fecha;
	    private String hora;
	    private double total;
	    private String metodoPago;
	    private String atendio;
	    private List<ProductoVendido> productos;
	    private double montoRecibido;
	    private double cambio;
	    private ClienteModel.Cliente cliente; // Nuevo campo para el cliente

	    public Venta(String folio, String fecha, String hora, double total, 
	                String metodoPago, String atendio, ClienteModel.Cliente cliente) {
	        this.folio = folio;
	        this.fecha = fecha;
	        this.hora = hora;
	        this.total = total;
	        this.metodoPago = metodoPago;
	        this.atendio = atendio;
	        this.productos = new ArrayList<>();
	        this.cliente = cliente;
	    }

        public void agregarProducto(ProductoVendido producto) {
            productos.add(producto);
        }

        // Getters y setters
        public String getFolio() { return folio; }
        public String getFecha() { return fecha; }
        public String getHora() { return hora; }
        public double getTotal() { return total; }
        public String getMetodoPago() { return metodoPago; }
        public String getAtendio() { return atendio; }
        public List<ProductoVendido> getProductos() { return productos; }
        public double getMontoRecibido() { return montoRecibido; }
        public void setMontoRecibido(double montoRecibido) { this.montoRecibido = montoRecibido; }
        public double getCambio() { return cambio; }
        public void setCambio(double cambio) { this.cambio = cambio; }
        public ClienteModel.Cliente getCliente() { return cliente; }
        public void setCliente(ClienteModel.Cliente cliente) { this.cliente = cliente; }
    }

    public static class ProductoVendido {
        private String codigo;
        private String nombre;
        private int cantidad;
        private double precio;

        // Constructor, getters y setters
        public ProductoVendido(String codigo, String nombre, int cantidad, double precio) {
            this.codigo = codigo;
            this.nombre = nombre;
            this.cantidad = cantidad;
            this.precio = precio;
        }

        // Getters
        public String getCodigo() { return codigo; }
        public String getNombre() { return nombre; }
        public int getCantidad() { return cantidad; }
        public double getPrecio() { return precio; }
    }

    public void agregarVenta(Venta venta) throws SQLException {
        String queryVenta = "INSERT INTO ventas (folio, fecha, hora, total, metodo_pago, atendio, monto_recibido, cambio, id_cliente) " +
                           "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        String queryDetalle = "INSERT INTO detalles_venta (id_venta, codigo_producto, nombre_producto, cantidad, precio_unitario) " +
                             "VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = ConexionBD.getConnection()) {
            conn.setAutoCommit(false);

            try (PreparedStatement stmtVenta = conn.prepareStatement(queryVenta, Statement.RETURN_GENERATED_KEYS)) {
                // Insertar datos de la venta
                stmtVenta.setString(1, venta.getFolio());
                stmtVenta.setString(2, venta.getFecha());
                stmtVenta.setString(3, venta.getHora());
                stmtVenta.setDouble(4, venta.getTotal());
                stmtVenta.setString(5, venta.getMetodoPago());
                stmtVenta.setString(6, venta.getAtendio());
                stmtVenta.setDouble(7, venta.getMontoRecibido());
                stmtVenta.setDouble(8, venta.getCambio());
                
                // Setear el cliente (puede ser null)
                if (venta.getCliente() != null) {
                    stmtVenta.setString(9, venta.getCliente().getId());
                } else {
                    stmtVenta.setNull(9, Types.VARCHAR);
                }
                
                // Ejecutar inserción de la venta
                int affectedRows = stmtVenta.executeUpdate();
                
                if (affectedRows == 0) {
                    throw new SQLException("No se pudo insertar la venta, ninguna fila afectada.");
                }

                // Obtener el ID generado de la venta
                try (ResultSet generatedKeys = stmtVenta.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        int idVenta = generatedKeys.getInt(1);
                        
                        // Insertar los detalles de la venta
                        try (PreparedStatement stmtDetalle = conn.prepareStatement(queryDetalle)) {
                            for (ProductoVendido producto : venta.getProductos()) {
                                stmtDetalle.setInt(1, idVenta);
                                stmtDetalle.setString(2, producto.getCodigo());
                                stmtDetalle.setString(3, producto.getNombre());
                                stmtDetalle.setInt(4, producto.getCantidad());
                                stmtDetalle.setDouble(5, producto.getPrecio());
                                stmtDetalle.addBatch();
                            }
                            
                            // Ejecutar todos los inserts de detalles en un batch
                            int[] results = stmtDetalle.executeBatch();
                            
                            // Verificar que todos los inserts fueron exitosos
                            for (int result : results) {
                                if (result == PreparedStatement.EXECUTE_FAILED) {
                                    throw new SQLException("Error al insertar uno o más detalles de venta");
                                }
                            }
                        }
                    } else {
                        throw new SQLException("No se pudo obtener el ID generado para la venta.");
                    }
                }
            } catch (SQLException e) {
                // Hacer rollback en caso de error
                conn.rollback();
                throw e;
            }
            
            // Confirmar la transacción si todo salió bien
            conn.commit();
        }
    }
    
    

    public List<Venta> getVentas() throws SQLException {
        List<Venta> ventas = new ArrayList<>();
        // Modificamos la consulta para incluir los datos del cliente (LEFT JOIN)
        String query = "SELECT v.*, c.id_cliente, c.nombre as nombre_cliente, c.telefono, c.correo_electronico " +
                       "FROM ventas v LEFT JOIN Clientes c ON v.id_cliente = c.id_cliente";

        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                // Creamos el objeto cliente si existe en la venta
                Cliente cliente = null;
                String idCliente = rs.getString("id_cliente");
                if (idCliente != null) {
                    cliente = new Cliente(
                        idCliente,
                        rs.getString("nombre_cliente"),
                        rs.getString("telefono"),
                        rs.getString("correo_electronico")
                    );
                }

                Venta venta = new Venta(
                    rs.getString("folio"),
                    rs.getString("fecha"),
                    rs.getString("hora"),
                    rs.getDouble("total"),
                    rs.getString("metodo_pago"),
                    rs.getString("atendio"),
                    cliente  // Pasamos el objeto cliente (puede ser null)
                );
                venta.setMontoRecibido(rs.getDouble("monto_recibido"));
                venta.setCambio(rs.getDouble("cambio"));
                ventas.add(venta);
            }
        }
        return ventas;
    }

    public String getDetalleVenta(String folio) throws SQLException {
        StringBuilder detalle = new StringBuilder();
        String query = "SELECT dv.*, p.nombre FROM detalles_venta dv " +
                       "JOIN productos p ON dv.codigo_producto = p.codigo " +
                       "JOIN ventas v ON dv.id_venta = v.id " +  // Cambiado a v.id
                       "WHERE v.folio = ?";  // Pero mantenemos el filtro por folio

        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, folio);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                detalle.append("- ")
                       .append(rs.getString("nombre"))
                       .append(" x")
                       .append(rs.getInt("cantidad"))
                       .append(" ($")
                       .append(rs.getDouble("precio_unitario"))
                       .append(" c/u)\n");
            }
        }
        return detalle.toString();
    }
    
    public List<Venta> getVentasPorFecha(LocalDate fecha) throws SQLException {
        List<Venta> ventas = new ArrayList<>();
        
        // Modificamos la consulta para incluir los datos del cliente (LEFT JOIN)
        String query = "SELECT v.*, c.id_cliente, c.nombre as nombre_cliente, c.telefono, c.correo_electronico " +
                       "FROM ventas v LEFT JOIN Clientes c ON v.id_cliente = c.id_cliente " +
                       "WHERE CONVERT(DATE, v.fecha) = ?";

        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            // Convertimos LocalDate a java.sql.Date
            java.sql.Date sqlFecha = java.sql.Date.valueOf(fecha);

            // Usamos setDate() en lugar de setString()
            stmt.setDate(1, sqlFecha);
            
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                // Creamos el objeto cliente si existe en la venta
                Cliente cliente = null;
                String idCliente = rs.getString("id_cliente");
                if (idCliente != null) {
                    cliente = new Cliente(
                        idCliente,
                        rs.getString("nombre_cliente"),
                        rs.getString("telefono"),
                        rs.getString("correo_electronico")
                    );
                }

                Venta venta = new Venta(
                    rs.getString("folio"),
                    rs.getString("fecha"),  // Si necesitas seguir usando String en Venta
                    rs.getString("hora"),
                    rs.getDouble("total"),
                    rs.getString("metodo_pago"),
                    rs.getString("atendio"),
                    cliente  // Pasamos el objeto cliente (puede ser null)
                );
                venta.setMontoRecibido(rs.getDouble("monto_recibido"));
                venta.setCambio(rs.getDouble("cambio"));
                ventas.add(venta);
            }
        }
        return ventas;
    }

    public Map<String, Integer> getProductosMasVendidos(String desde, String hasta) throws SQLException {
        Map<String, Integer> productosVendidos = new HashMap<>();
        String query = "SELECT p.nombre, SUM(dv.cantidad) AS total_vendido " +
                       "FROM detalles_venta dv " +
                       "JOIN productos p ON dv.codigo_producto = p.codigo " +
                       "JOIN ventas v ON dv.id_venta = v.id " +  // Cambiado para usar v.id en lugar de v.folio
                       "WHERE v.fecha BETWEEN ? AND ? " +
                       "GROUP BY p.nombre " +
                       "ORDER BY total_vendido DESC";

        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, desde);
            stmt.setString(2, hasta);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    productosVendidos.put(rs.getString("nombre"), rs.getInt("total_vendido"));
                }
            }
        }
        return productosVendidos;
    }
}