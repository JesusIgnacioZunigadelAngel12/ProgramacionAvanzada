package Vista;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.rendering.PDFRenderer;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.rendering.PDFRenderer;

public class PDFViewerDialog extends JDialog {
    private JPanel pdfPanel;
    private BufferedImage pdfImage;
    private String pdfPath;
    
    public PDFViewerDialog(Frame parent, String pdfPath) {
        super(parent, "Vista previa del ticket", true);
        this.pdfPath = pdfPath;
        cargarPDF();
        inicializarComponentes();
    }
    
    private void cargarPDF() {
    try {
        PDDocument document = Loader.loadPDF(new File(pdfPath));
        PDFRenderer pdfRenderer = new PDFRenderer(document);
        pdfImage = pdfRenderer.renderImageWithDPI(0, 300);
        document.close();
    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, 
            "Error al cargar el PDF: " + e.getMessage(), 
            "Error", 
            JOptionPane.ERROR_MESSAGE);
    }
}
    
    private void inicializarComponentes() {
        setSize(400, 600);
        setLocationRelativeTo(null);
        
        pdfPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (pdfImage != null) {
                    // Mantener la proporción de la imagen
                    double scale = Math.min(
                        (double) getWidth() / pdfImage.getWidth(),
                        (double) getHeight() / pdfImage.getHeight()
                    );
                    int scaledWidth = (int) (pdfImage.getWidth() * scale);
                    int scaledHeight = (int) (pdfImage.getHeight() * scale);
                    
                    // Centrar la imagen
                    int x = (getWidth() - scaledWidth) / 2;
                    int y = (getHeight() - scaledHeight) / 2;
                    
                    g.drawImage(pdfImage, x, y, scaledWidth, scaledHeight, this);
                }
            }
        };
        
        JButton btnGuardar = new JButton("Guardar PDF");
        btnGuardar.addActionListener(e -> guardarPDF());
        
        JButton btnCerrar = new JButton("Cerrar");
        btnCerrar.addActionListener(e -> dispose());
        
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(btnGuardar);
        buttonPanel.add(btnCerrar);
        
        setLayout(new BorderLayout());
        add(new JScrollPane(pdfPanel), BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }
    
    private void guardarPDF() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Guardar PDF");
        fileChooser.setSelectedFile(new File("ticket_" + System.currentTimeMillis() + ".pdf"));
        
        if (fileChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            File destino = fileChooser.getSelectedFile();
            if (!destino.getName().toLowerCase().endsWith(".pdf")) {
                destino = new File(destino.getAbsolutePath() + ".pdf");
            }
            
            try {
                Files.copy(
                    new File(pdfPath).toPath(),
                    destino.toPath(),
                    StandardCopyOption.REPLACE_EXISTING
                );
                JOptionPane.showMessageDialog(this, 
                    "PDF guardado exitosamente en:\n" + destino.getPath(),
                    "Éxito", 
                    JOptionPane.INFORMATION_MESSAGE);
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, 
                    "Error al guardar el PDF: " + e.getMessage(), 
                    "Error", 
                    JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}