package Vista;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class CajaView extends JFrame {
    private JLabel lblSaldo;
    private JLabel lblEstado;
    private JLabel lblHora;
    private JLabel lblInfoAdicional;
    private JButton btnAbrir;
    private JButton btnCerrar;
    private JButton btnDeposito;
    private JButton btnRetiro;
    private JButton btnHistorial;
    private JButton btnSalir;

    // Paleta de colores
    private final Color COLOR_PRIMARIO = new Color(231, 76, 60);
    private final Color COLOR_SECUNDARIO = new Color(241, 196, 15);
    private final Color COLOR_FONDO = new Color(253, 245, 230);
    private final Color COLOR_TEXTO = Color.WHITE;
    private final Color COLOR_TEXTO_OSCURO = new Color(51, 51, 51);
    private final Color COLOR_CAJA_ABIERTA = new Color(39, 174, 96);
    private final Color COLOR_CAJA_CERRADA = new Color(192, 57, 43);
    private final Color COLOR_INFO = new Color(41, 128, 185);

    public CajaView() {
        setTitle("CONTROL DE CAJA - La Esquinita");
        setSize(1000, 700); // Aumenté el tamaño para una mejor disposición
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(COLOR_FONDO);

        JPanel panelPrincipal = new JPanel(new BorderLayout(20, 20));
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panelPrincipal.setBackground(COLOR_FONDO);

        // Panel superior: Estado de la caja
        JPanel panelSuperior = new JPanel(new GridLayout(2, 1, 10, 10));
        panelSuperior.setBackground(COLOR_FONDO);
        panelSuperior.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COLOR_PRIMARIO, 2),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));

        lblEstado = crearLabelEstado("CAJA CERRADA", COLOR_CAJA_CERRADA);
        lblSaldo = crearLabelSaldo("$0.00");
        lblHora = crearLabelHora();
        lblInfoAdicional = crearLabelInfo("");

        JPanel panelEstado = new JPanel(new BorderLayout(10, 10));
        panelEstado.setBackground(COLOR_FONDO);
        panelEstado.add(lblEstado, BorderLayout.NORTH);
        panelEstado.add(lblSaldo, BorderLayout.CENTER);

        panelSuperior.add(panelEstado);
        panelSuperior.add(lblInfoAdicional);

        // Panel central: Botones principales
        JPanel panelCentral = new JPanel(new GridLayout(2, 2, 15, 15));
        panelCentral.setBackground(COLOR_FONDO);
        panelCentral.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        btnAbrir = crearBotonEstilizado("Abrir Caja", COLOR_CAJA_ABIERTA);
        btnCerrar = crearBotonEstilizado("Cerrar Caja", COLOR_CAJA_CERRADA);
        btnDeposito = crearBotonEstilizado("Registrar Depósito", COLOR_PRIMARIO);
        btnRetiro = crearBotonEstilizado("Registrar Retiro", COLOR_SECUNDARIO);

        panelCentral.add(btnAbrir);
        panelCentral.add(btnDeposito);
        panelCentral.add(btnCerrar);
        panelCentral.add(btnRetiro);

        // Panel inferior: Botones secundarios
        JPanel panelInferior = new JPanel();
        panelInferior.setLayout(new BoxLayout(panelInferior, BoxLayout.X_AXIS));
        panelInferior.setBackground(COLOR_FONDO);
        panelInferior.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));

        btnHistorial = crearBotonEstilizado("Ver Historial", new Color(142, 68, 173));
        btnSalir = crearBotonEstilizado("Salir", COLOR_TEXTO_OSCURO);

        panelInferior.add(Box.createHorizontalGlue());
        panelInferior.add(btnHistorial);
        panelInferior.add(Box.createHorizontalStrut(15));
        panelInferior.add(btnSalir);
        panelInferior.add(Box.createHorizontalGlue());

        // Agregar paneles al panel principal
        panelPrincipal.add(panelSuperior, BorderLayout.NORTH);
        panelPrincipal.add(panelCentral, BorderLayout.CENTER);
        panelPrincipal.add(panelInferior, BorderLayout.SOUTH);

        add(panelPrincipal);
    }

    private JLabel crearLabelEstado(String texto, Color color) {
        JLabel label = new JLabel(texto, SwingConstants.CENTER);
        label.setFont(new Font("Segoe UI", Font.BOLD, 18));
        label.setForeground(COLOR_TEXTO);
        label.setBackground(color);
        label.setOpaque(true);
        label.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(color.darker(), 2),
            BorderFactory.createEmptyBorder(10, 15, 10, 15)
        ));
        return label;
    }

    private JLabel crearLabelSaldo(String texto) {
        JLabel label = new JLabel("Saldo: " + texto, SwingConstants.CENTER);
        label.setFont(new Font("Segoe UI", Font.BOLD, 24));
        label.setForeground(COLOR_TEXTO_OSCURO);
        label.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COLOR_PRIMARIO, 1),
            BorderFactory.createEmptyBorder(10, 15, 10, 15)
        ));
        return label;
    }

    private JLabel crearLabelHora() {
        JLabel label = new JLabel("", SwingConstants.CENTER);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        label.setForeground(COLOR_TEXTO_OSCURO);
        label.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COLOR_PRIMARIO, 1),
            BorderFactory.createEmptyBorder(10, 15, 10, 15)
        ));
        return label;
    }

    private JLabel crearLabelInfo(String texto) {
        JLabel label = new JLabel(texto, SwingConstants.CENTER);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        label.setForeground(COLOR_INFO);
        label.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COLOR_INFO, 1),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        return label;
    }

    private JButton crearBotonEstilizado(String texto, Color colorFondo) {
        JButton boton = new JButton(texto);
        boton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        boton.setForeground(COLOR_TEXTO);
        boton.setBackground(colorFondo);
        boton.setFocusPainted(false);
        boton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(colorFondo.darker(), 1),
            BorderFactory.createEmptyBorder(12, 20, 12, 20)
        ));
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        boton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                boton.setBackground(colorFondo.brighter());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                boton.setBackground(colorFondo);
            }
        });
        return boton;
    }

    public void actualizarInterfaz(double saldo, boolean cajaAbierta, String hora, String infoAdicional) {
        lblSaldo.setText("Saldo: $" + String.format("%.2f", saldo));
        lblEstado.setText(cajaAbierta ? "CAJA ABIERTA" : "CAJA CERRADA");
        lblEstado.setBackground(cajaAbierta ? COLOR_CAJA_ABIERTA : COLOR_CAJA_CERRADA);
        lblHora.setText(hora);
        if (infoAdicional != null && !infoAdicional.isEmpty()) {
            lblInfoAdicional.setText(infoAdicional);
            lblInfoAdicional.setVisible(true);
        } else {
            lblInfoAdicional.setVisible(false);
        }
    }

    public void actualizarEstadoBotones(boolean cajaAbierta, boolean hayMovimientos) {
        btnAbrir.setEnabled(!cajaAbierta);
        btnCerrar.setEnabled(cajaAbierta);
        btnDeposito.setEnabled(cajaAbierta);
        btnRetiro.setEnabled(cajaAbierta);
        btnHistorial.setEnabled(hayMovimientos);
    }

    public String pedirMonto(String mensaje) {
        return JOptionPane.showInputDialog(this, mensaje);
    }

    public int confirmarCierre(String mensaje) {
        return JOptionPane.showConfirmDialog(
            this,
            mensaje,
            "Confirmar Cierre",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE
        );
    }

    public void mostrarHistorial(String historial) {
        JTextArea area = new JTextArea(historial);
        area.setEditable(false);
        area.setFont(new Font("Monospaced", Font.PLAIN, 12));
        JScrollPane scrollPane = new JScrollPane(area);
        scrollPane.setPreferredSize(new Dimension(600, 400));
        JOptionPane.showMessageDialog(
            this,
            scrollPane,
            "Historial de Movimientos",
            JOptionPane.PLAIN_MESSAGE
        );
    }

    public void mostrarMensaje(String mensaje, String titulo) {
        JOptionPane.showMessageDialog(
            this,
            mensaje,
            titulo,
            JOptionPane.INFORMATION_MESSAGE
        );
    }

    public void mostrarError(String mensaje) {
        String mensajeLimpio = mensaje;
        if (mensaje.contains("Invalid column name")) {
            mensajeLimpio = "Error de configuración: Falta columna en la base de datos.\nContacte al administrador del sistema.";
        }
        JOptionPane.showMessageDialog(
            this,
            mensajeLimpio,
            "Error",
            JOptionPane.ERROR_MESSAGE
        );
    }

    // Métodos para los listeners
    public void setAbrirListener(ActionListener listener) {
        btnAbrir.addActionListener(listener);
    }

    public void setCerrarListener(ActionListener listener) {
        btnCerrar.addActionListener(listener);
    }

    public void setDepositoListener(ActionListener listener) {
        btnDeposito.addActionListener(listener);
    }

    public void setRetiroListener(ActionListener listener) {
        btnRetiro.addActionListener(listener);
    }

    public void setHistorialListener(ActionListener listener) {
        btnHistorial.addActionListener(listener);
    }

    public void setSalirListener(ActionListener listener) {
        btnSalir.addActionListener(listener);
    }
}