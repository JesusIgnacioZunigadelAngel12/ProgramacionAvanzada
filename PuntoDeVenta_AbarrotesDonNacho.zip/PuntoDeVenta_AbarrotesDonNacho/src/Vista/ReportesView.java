package Vista;

import javax.swing.*;
import java.awt.*;

public class ReportesView extends JFrame {
    private JButton btnVentasDiarias;
    private JButton btnProductosVendidos;
    private JButton btnMovimientosCaja;
    private JButton btnExportar;
    private JButton btnSalir;
    
    // Paleta de colores consistente
    private final Color COLOR_PRIMARIO = new Color(231, 76, 60); // Rojo anaranjado
    private final Color COLOR_SECUNDARIO = new Color(241, 196, 15); // Amarillo dorado
    private final Color COLOR_FONDO = new Color(253, 245, 230); // Beige claro
    private final Color COLOR_TEXTO = Color.WHITE;
    private final Color COLOR_TEXTO_OSCURO = new Color(51, 51, 51);
    private final Color COLOR_EXPORTAR = new Color(39, 174, 96); // Verde
    
    public ReportesView() {
        setTitle("GENERADOR DE REPORTES - La Esquinita");
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(COLOR_FONDO);

        JPanel panelPrincipal = new JPanel(new BorderLayout(15, 15));
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panelPrincipal.setBackground(COLOR_FONDO);

        // Panel de título
        JLabel lblTitulo = new JLabel("Generador de Reportes", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitulo.setForeground(COLOR_PRIMARIO);
        panelPrincipal.add(lblTitulo, BorderLayout.NORTH);

        // Panel central con opciones de reporte
        JPanel panelOpciones = new JPanel(new GridLayout(3, 1, 15, 15));
        panelOpciones.setBackground(COLOR_FONDO);
        panelOpciones.setBorder(BorderFactory.createEmptyBorder(30, 100, 30, 100));

        btnVentasDiarias = crearBotonEstilizado("Ventas Diarias", COLOR_PRIMARIO);
        btnProductosVendidos = crearBotonEstilizado("Productos Más Vendidos", COLOR_SECUNDARIO);
        btnMovimientosCaja = crearBotonEstilizado("Movimientos de Caja", new Color(41, 128, 185)); // Azul

        panelOpciones.add(btnVentasDiarias);
        panelOpciones.add(btnProductosVendidos);
        panelOpciones.add(btnMovimientosCaja);

        panelPrincipal.add(panelOpciones, BorderLayout.CENTER);

        // Panel inferior con botones de acción
        JPanel panelInferior = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        panelInferior.setBackground(COLOR_FONDO);
        
        btnExportar = crearBotonEstilizado("Exportar Reporte", COLOR_EXPORTAR);
        btnSalir = crearBotonEstilizado("Salir", COLOR_TEXTO_OSCURO);
        
        // Establecer tamaños más pequeños para estos botones
        Dimension tamanoPequeño = new Dimension(150, 35);
        btnExportar.setPreferredSize(tamanoPequeño);
        btnSalir.setPreferredSize(tamanoPequeño);
        
        panelInferior.add(btnExportar);
        panelInferior.add(btnSalir);

        panelPrincipal.add(panelInferior, BorderLayout.SOUTH);

        add(panelPrincipal);
    }

    private JButton crearBotonEstilizado(String texto, Color colorFondo) {
        JButton boton = new JButton(texto);
        boton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        boton.setForeground(COLOR_TEXTO);
        boton.setBackground(colorFondo);
        boton.setFocusPainted(false);
        boton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(colorFondo.darker(), 1),
            BorderFactory.createEmptyBorder(8, 15, 8, 15)
        ));
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        boton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                boton.setBackground(colorFondo.brighter());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                boton.setBackground(colorFondo);
            }
        });
        return boton;
    }
    
    // Métodos existentes (no se modifican para mantener la funcionalidad)
    public void mostrarReporte(String reporte, String titulo) {
        JOptionPane.showMessageDialog(this, reporte, titulo, JOptionPane.INFORMATION_MESSAGE);
    }
    
    public void mostrarMensaje(String mensaje, String titulo) {
        JOptionPane.showMessageDialog(this, mensaje, titulo, JOptionPane.INFORMATION_MESSAGE);
    }
    
    public void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(null, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
    }
    
    public JButton getBtnVentasDiarias() { return btnVentasDiarias; }
    public JButton getBtnProductosVendidos() { return btnProductosVendidos; }
    public JButton getBtnMovimientosCaja() { return btnMovimientosCaja; }
    public JButton getBtnExportar() { return btnExportar; }
    public JButton getBtnSalir() { return btnSalir; }
}