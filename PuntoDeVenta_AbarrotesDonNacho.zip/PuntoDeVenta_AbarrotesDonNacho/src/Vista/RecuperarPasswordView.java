package Vista;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class RecuperarPasswordView extends JDialog {
    private JTextField txtUsuario;
    private JTextField txtTelefono;
    private JPasswordField txtNuevaPassword;
    private JPasswordField txtConfirmarPassword;
    private JButton btnConfirmar;
    private JButton btnCancelar;

    // Paleta de colores consistente con el sistema
    private final Color COLOR_PRIMARIO = new Color(231, 76, 60); // Rojo anaranjado
    private final Color COLOR_SECUNDARIO = new Color(241, 196, 15); // Amarillo dorado
    private final Color COLOR_FONDO = new Color(253, 245, 230); // Beige claro
    private final Color COLOR_TEXTO = Color.WHITE;
    private final Color COLOR_TEXTO_OSCURO = new Color(51, 51, 51);

    public RecuperarPasswordView(JFrame parent) {
        super(parent, "Recuperar Contraseña", true);
        setSize(450, 350);
        setLocationRelativeTo(parent);
        setResizable(false);
        getContentPane().setBackground(COLOR_FONDO);
        setLayout(new BorderLayout(10, 10));

        // Panel principal con borde y padding
        JPanel panelPrincipal = new JPanel();
        panelPrincipal.setLayout(new BoxLayout(panelPrincipal, BoxLayout.Y_AXIS));
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));
        panelPrincipal.setBackground(COLOR_FONDO);

        // Título
        JLabel lblTitulo = new JLabel("Recuperar Contraseña", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTitulo.setForeground(COLOR_PRIMARIO);
        lblTitulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        panelPrincipal.add(lblTitulo);
        panelPrincipal.add(Box.createVerticalStrut(20));

        // Panel de campos de formulario
        JPanel panelCampos = new JPanel();
        panelCampos.setLayout(new GridLayout(4, 2, 10, 15));
        panelCampos.setBackground(COLOR_FONDO);
        panelCampos.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Estilo para las etiquetas
        Font fontLabel = new Font("Segoe UI", Font.BOLD, 12);

        // Campo Usuario
        JLabel lblUsuario = new JLabel("Usuario:");
        lblUsuario.setFont(fontLabel);
        lblUsuario.setForeground(COLOR_TEXTO_OSCURO);
        panelCampos.add(lblUsuario);

        txtUsuario = new JTextField();
        txtUsuario.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COLOR_PRIMARIO, 1),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        panelCampos.add(txtUsuario);

        // Campo Teléfono
        JLabel lblTelefono = new JLabel("Teléfono:");
        lblTelefono.setFont(fontLabel);
        lblTelefono.setForeground(COLOR_TEXTO_OSCURO);
        panelCampos.add(lblTelefono);

        txtTelefono = new JTextField();
        txtTelefono.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COLOR_PRIMARIO, 1),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        panelCampos.add(txtTelefono);

        // Campo Nueva Contraseña
        JLabel lblNuevaPassword = new JLabel("Nueva Contraseña:");
        lblNuevaPassword.setFont(fontLabel);
        lblNuevaPassword.setForeground(COLOR_TEXTO_OSCURO);
        panelCampos.add(lblNuevaPassword);

        txtNuevaPassword = new JPasswordField();
        txtNuevaPassword.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COLOR_PRIMARIO, 1),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        panelCampos.add(txtNuevaPassword);

        // Campo Confirmar Contraseña
        JLabel lblConfirmarPassword = new JLabel("Confirmar Contraseña:");
        lblConfirmarPassword.setFont(fontLabel);
        lblConfirmarPassword.setForeground(COLOR_TEXTO_OSCURO);
        panelCampos.add(lblConfirmarPassword);

        txtConfirmarPassword = new JPasswordField();
        txtConfirmarPassword.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COLOR_PRIMARIO, 1),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        panelCampos.add(txtConfirmarPassword);

        panelPrincipal.add(panelCampos);
        panelPrincipal.add(Box.createVerticalStrut(20));

        // Panel de botones
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        panelBotones.setBackground(COLOR_FONDO);

        btnConfirmar = crearBotonEstilizado("Confirmar", COLOR_PRIMARIO);
        btnCancelar = crearBotonEstilizado("Cancelar", COLOR_TEXTO_OSCURO);
        
        panelBotones.add(btnConfirmar);
        panelBotones.add(btnCancelar);

        panelPrincipal.add(panelBotones);

        add(panelPrincipal, BorderLayout.CENTER);
    }

    private JButton crearBotonEstilizado(String texto, Color colorFondo) {
        JButton boton = new JButton(texto);
        boton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        boton.setBackground(colorFondo);
        boton.setForeground(COLOR_TEXTO);
        boton.setFocusPainted(false);
        boton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(colorFondo.darker(), 1),
            BorderFactory.createEmptyBorder(8, 20, 8, 20)
        ));
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        boton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                boton.setBackground(colorFondo.brighter());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                boton.setBackground(colorFondo);
            }
        });
        
        return boton;
    }

    // Los métodos getters y de controladores se mantienen igual
    public String getUsuario() {
        return txtUsuario.getText().trim();
    }

    public String getTelefono() {
        return txtTelefono.getText().trim();
    }

    public String getNuevaPassword() {
        return new String(txtNuevaPassword.getPassword());
    }

    public String getConfirmarPassword() {
        return new String(txtConfirmarPassword.getPassword());
    }

    public void addConfirmarListener(ActionListener listener) {
        btnConfirmar.addActionListener(listener);
    }

    public void addCancelarListener(ActionListener listener) {
        btnCancelar.addActionListener(listener);
    }

    public void mostrarMensaje(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje);
    }

    public void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
    }

    public void cerrar() {
        dispose();
    }
}