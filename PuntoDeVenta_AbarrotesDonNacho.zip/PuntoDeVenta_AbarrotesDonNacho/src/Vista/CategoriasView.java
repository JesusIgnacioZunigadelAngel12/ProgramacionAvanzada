package Vista;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class CategoriasView extends JDialog {
    private DefaultListModel<String> modeloLista;
    private JList<String> listaCategorias;
    private JButton btnAgregar, btnEditar, btnEliminar, btnSalir;
    private JTextField txtCategoria;

    private final Color COLOR_PRIMARIO = new Color(231, 76, 60);
    private final Color COLOR_SECUNDARIO = new Color(241, 196, 15);
    private final Color COLOR_FONDO = new Color(253, 245, 230);
    private final Color COLOR_TEXTO_OSCURO = new Color(51, 51, 51);

    public CategoriasView(JFrame owner) {
        super(owner, "Gestión de Categorías", true);
        setSize(400, 300);
        setResizable(false); // Evita redimensionar
        setLocationRelativeTo(owner);
        setLayout(new BorderLayout());
        getContentPane().setBackground(COLOR_FONDO);

        // Campo de texto para nueva categoría
        JPanel panelEntrada = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        panelEntrada.setBackground(COLOR_FONDO);

        txtCategoria = new JTextField(20);
        txtCategoria.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        btnAgregar = crearBotonEstilizado("Agregar", COLOR_PRIMARIO);
        panelEntrada.add(txtCategoria);
        panelEntrada.add(btnAgregar);

        add(panelEntrada, BorderLayout.NORTH);

        // Lista de categorías
        modeloLista = new DefaultListModel<>();
        listaCategorias = new JList<>(modeloLista);
        JScrollPane scrollPane = new JScrollPane(listaCategorias);
        scrollPane.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(COLOR_PRIMARIO),
                "Categorías",
                javax.swing.border.TitledBorder.LEFT,
                javax.swing.border.TitledBorder.TOP,
                new Font("Segoe UI", Font.BOLD, 12),
                COLOR_PRIMARIO));

        add(scrollPane, BorderLayout.CENTER);

        // Botones inferiores
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        panelBotones.setBackground(COLOR_FONDO);

        btnEditar = crearBotonEstilizado("Editar", COLOR_SECUNDARIO);
        btnEliminar = crearBotonEstilizado("Eliminar", new Color(192, 57, 43));
        btnSalir = crearBotonEstilizado("Salir", new Color(142, 68, 173));

        panelBotones.add(btnEditar);
        panelBotones.add(btnEliminar);
        panelBotones.add(btnSalir);

        add(panelBotones, BorderLayout.SOUTH);
    }

    public JButton getBtnAgregar() { return btnAgregar; }
    public JButton getBtnEditar() { return btnEditar; }
    public JButton getBtnEliminar() { return btnEliminar; }
    public JButton getBtnSalir() { return btnSalir; }
    public JList<String> getListaCategorias() { return listaCategorias; }
    public JTextField getTxtCategoria() { return txtCategoria; }
    public DefaultListModel<String> getModeloLista() { return modeloLista; }

    // Método auxiliar para crear botones con estilo
    public JButton crearBotonEstilizado(String texto, Color colorFondo) {
        JButton boton = new JButton(texto);
        boton.setBackground(colorFondo);
        boton.setForeground(Color.WHITE);
        boton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        boton.setFocusPainted(false);
        boton.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
        return boton;
    }

    public void mostrarMensaje(String mensaje, String titulo) {
        JOptionPane.showMessageDialog(this, mensaje, titulo, JOptionPane.INFORMATION_MESSAGE);
    }

    public void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
    }

    public String pedirNuevoValor(String mensaje) {
        return JOptionPane.showInputDialog(this, mensaje);
    }
}