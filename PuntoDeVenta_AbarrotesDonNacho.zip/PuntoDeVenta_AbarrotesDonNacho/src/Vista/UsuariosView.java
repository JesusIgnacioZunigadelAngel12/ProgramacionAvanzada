package Vista;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class UsuariosView extends JFrame {
    private DefaultTableModel modeloTabla;
    private JTable tabla;
    private JButton btnAgregar;
    private JButton btnEditar;
    private JButton btnEliminar;
    private JButton btnBuscar;
    private JButton btnLimpiar;
    private JButton btnSalir;
    private JTextField txtBusqueda;

    // Paleta de colores
    private final Color COLOR_PRIMARIO = new Color(231, 76, 60); // Rojo anaranjado
    private final Color COLOR_SECUNDARIO = new Color(241, 196, 15); // Amarillo dorado
    private final Color COLOR_FONDO = new Color(253, 245, 230); // Beige claro
    private final Color COLOR_TEXTO = Color.WHITE;
    private final Color COLOR_TEXTO_OSCURO = new Color(51, 51, 51);
    private final Color COLOR_ELIMINAR = new Color(192, 57, 43); // Rojo oscuro

    public UsuariosView() {
        setTitle("GESTIÓN DE USUARIOS - La Esquinita");
        setSize(900, 650);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(COLOR_FONDO);

        JPanel panelPrincipal = new JPanel(new BorderLayout(15, 15));
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        panelPrincipal.setBackground(COLOR_FONDO);

        // Panel superior con barra de búsqueda
        JPanel panelSuperior = new JPanel(new BorderLayout(10, 10));
        panelSuperior.setBackground(COLOR_FONDO);

        txtBusqueda = new JTextField();
        txtBusqueda.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtBusqueda.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(COLOR_PRIMARIO, 1),
                BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        txtBusqueda.setToolTipText("Buscar por nombre de usuario");

        btnBuscar = crearBotonEstilizado("Buscar", COLOR_SECUNDARIO);
        btnBuscar.setPreferredSize(new Dimension(80, 30));

        btnLimpiar = crearBotonEstilizado("Limpiar", new Color(52, 152, 219)); // Azul cielo
        btnLimpiar.setPreferredSize(new Dimension(80, 30));

        // Panel para los botones de búsqueda (derecha)
        JPanel panelBotonesBusqueda = new JPanel(new FlowLayout(FlowLayout.RIGHT, 5, 0));
        panelBotonesBusqueda.setBackground(COLOR_FONDO);
        panelBotonesBusqueda.add(btnBuscar);
        panelBotonesBusqueda.add(btnLimpiar);

        // Panel principal de búsqueda
        JPanel panelBusqueda = new JPanel(new BorderLayout(5, 5));
        panelBusqueda.setBackground(COLOR_FONDO);
        panelBusqueda.add(txtBusqueda, BorderLayout.CENTER);
        panelBusqueda.add(panelBotonesBusqueda, BorderLayout.EAST);

        panelSuperior.add(panelBusqueda, BorderLayout.NORTH);
        panelPrincipal.add(panelSuperior, BorderLayout.NORTH);

        // Tabla de usuarios
        String[] columnas = {"Usuario", "Contraseña", "Rol", "Teléfono"};// 👈 Añadimos la columna "Rol"
        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tabla = new JTable(modeloTabla);
        tabla.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        tabla.setRowHeight(25);
        tabla.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        tabla.getTableHeader().setBackground(COLOR_PRIMARIO);
        tabla.getTableHeader().setForeground(COLOR_TEXTO);

        JScrollPane scrollPane = new JScrollPane(tabla);
        scrollPane.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(COLOR_PRIMARIO, 1),
                "Lista de Usuarios",
                javax.swing.border.TitledBorder.LEFT,
                javax.swing.border.TitledBorder.TOP,
                new Font("Segoe UI", Font.BOLD, 12),
                COLOR_PRIMARIO
        ));

        panelPrincipal.add(scrollPane, BorderLayout.CENTER);

        // Panel de botones
        JPanel panelBotones = new JPanel();
        panelBotones.setLayout(new BoxLayout(panelBotones, BoxLayout.X_AXIS));
        panelBotones.setBackground(COLOR_FONDO);
        panelBotones.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));

        btnAgregar = crearBotonEstilizado("Agregar", COLOR_PRIMARIO);
        btnEditar = crearBotonEstilizado("Editar", new Color(41, 128, 185)); // Azul
        btnEliminar = crearBotonEstilizado("Eliminar", COLOR_ELIMINAR);
        btnSalir = crearBotonEstilizado("Salir", new Color(142, 68, 173)); // Morado

        Dimension tamanoBoton = new Dimension(120, 35);
        btnAgregar.setPreferredSize(tamanoBoton);
        btnEditar.setPreferredSize(tamanoBoton);
        btnEliminar.setPreferredSize(tamanoBoton);
        btnSalir.setPreferredSize(tamanoBoton);

        panelBotones.add(Box.createHorizontalGlue());
        panelBotones.add(btnAgregar);
        panelBotones.add(Box.createHorizontalStrut(10));
        panelBotones.add(btnEditar);
        panelBotones.add(Box.createHorizontalStrut(10));
        panelBotones.add(btnEliminar);
        panelBotones.add(Box.createHorizontalStrut(10));
        panelBotones.add(btnSalir);
        panelBotones.add(Box.createHorizontalGlue());

        panelPrincipal.add(panelBotones, BorderLayout.SOUTH);

        add(panelPrincipal);
    }

    private JButton crearBotonEstilizado(String texto, Color colorFondo) {
        JButton boton = new JButton(texto);
        boton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        boton.setBackground(colorFondo);
        boton.setForeground(COLOR_TEXTO);
        boton.setFocusPainted(false);
        boton.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(colorFondo.darker(), 1),
                BorderFactory.createEmptyBorder(5, 15, 5, 15)
        ));

        boton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                boton.setBackground(colorFondo.brighter());
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                boton.setBackground(colorFondo);
            }
        });

        return boton;
    }

    public void cargarUsuarios(Object[][] datos) {
        modeloTabla.setRowCount(0);
        for (Object[] fila : datos) {
            modeloTabla.addRow(fila);
        }
    }

    public String getTextoBusqueda() {
        return txtBusqueda.getText().trim();
    }

    public void limpiarBusqueda() {
        txtBusqueda.setText("");
    }

    public int getFilaSeleccionada() {
        return tabla.getSelectedRow();
    }

    public DefaultTableModel getModeloTabla() {
        return modeloTabla;
    }

    public String mostrarDialogoUsuario(String titulo, String usuarioActual, String passwordActual) {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(253, 245, 230)); // COLOR_FONDO
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 10, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;

        // Estilo común
        Font fontLabel = new Font("Segoe UI", Font.BOLD, 12);
        Color colorTexto = new Color(51, 51, 51); // COLOR_TEXTO_OSCURO
        Color colorBorde = new Color(231, 76, 60); // COLOR_PRIMARIO

        // Campo Usuario
        JLabel lblUsuario = new JLabel("Usuario:");
        lblUsuario.setFont(fontLabel);
        lblUsuario.setForeground(colorTexto);
        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(lblUsuario, gbc);

        JTextField txtUsuario = new JTextField(usuarioActual, 20);
        estiloCampo(txtUsuario, colorBorde);
        gbc.gridx = 1; gbc.gridy = 0;
        panel.add(txtUsuario, gbc);

        // Campo Contraseña
        JLabel lblPassword = new JLabel("Contraseña:");
        lblPassword.setFont(fontLabel);
        lblPassword.setForeground(colorTexto);
        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(lblPassword, gbc);

        JPasswordField txtPassword = new JPasswordField(passwordActual, 20);
        estiloCampo(txtPassword, colorBorde);
        gbc.gridx = 1; gbc.gridy = 1;
        panel.add(txtPassword, gbc);

        // Campo Rol
        JLabel lblRol = new JLabel("Rol:");
        lblRol.setFont(fontLabel);
        lblRol.setForeground(colorTexto);
        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(lblRol, gbc);

        String[] roles = {"USUARIO", "ADMIN"};
        JComboBox<String> comboRol = new JComboBox<>(roles);
        if (!usuarioActual.isEmpty()) {
            comboRol.setSelectedItem(usuarioActual.equals("admin") ? "ADMIN" : "USUARIO");
        }
        estiloCampo(comboRol, colorBorde);
        gbc.gridx = 1; gbc.gridy = 2;
        panel.add(comboRol, gbc);

        // Campo Teléfono (nuevo)
        JLabel lblTelefono = new JLabel("Teléfono:");
        lblTelefono.setFont(fontLabel);
        lblTelefono.setForeground(colorTexto);
        gbc.gridx = 0; gbc.gridy = 3;
        panel.add(lblTelefono, gbc);

        JTextField txtTelefono = new JTextField(20);
        estiloCampo(txtTelefono, colorBorde);
        gbc.gridx = 1; gbc.gridy = 3;
        panel.add(txtTelefono, gbc);

        // Mostrar diálogo
        int result = JOptionPane.showOptionDialog(
            this, 
            panel, 
            titulo, 
            JOptionPane.OK_CANCEL_OPTION, 
            JOptionPane.PLAIN_MESSAGE, 
            null, 
            new Object[]{"Aceptar", "Cancelar"}, 
            "Aceptar"
        );

        if (result == JOptionPane.OK_OPTION) {
            return txtUsuario.getText() + ";" + 
                   new String(txtPassword.getPassword()) + ";" + 
                   comboRol.getSelectedItem() + ";" + 
                   txtTelefono.getText();
        }
        return null;
    }

    // Método auxiliar para estilizar campos
    private void estiloCampo(JComponent componente, Color colorBorde) {
        componente.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        componente.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(colorBorde, 1),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        componente.setBackground(Color.WHITE);
    }

    public void mostrarMensaje(String mensaje, String titulo) {
        JOptionPane.showMessageDialog(this, mensaje, titulo, JOptionPane.INFORMATION_MESSAGE);
    }

    public void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
    }

    // Getters para los botones
    public JButton getBtnAgregar() { return btnAgregar; }
    public JButton getBtnEditar() { return btnEditar; }
    public JButton getBtnEliminar() { return btnEliminar; }
    public JButton getBtnBuscar() { return btnBuscar; }
    public JButton getBtnLimpiar() { return btnLimpiar; }
    public JButton getBtnSalir() { return btnSalir; }
}