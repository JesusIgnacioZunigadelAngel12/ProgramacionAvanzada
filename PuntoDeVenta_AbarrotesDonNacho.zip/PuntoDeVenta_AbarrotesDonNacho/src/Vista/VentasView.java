package Vista;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class VentasView extends JFrame {
    private static final JLabel txtDesde = null;
	private static final JLabel txtHasta = null;
	private static final JTable tabla = null;
	private JButton btnFiltrar;
	private JButton btnDetalle;
	private JButton btnReimprimir;
	private JButton btnSalir;
	private DefaultTableModel modeloTabla;
    
	public VentasView() {
	    setTitle("HISTORIAL DE VENTAS");
	    setSize(900, 600);
	    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	    setLocationRelativeTo(null);

	    JPanel panel = new JPanel(new BorderLayout(10, 10));
	    panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

	    // Crear botones
	    btnFiltrar = new JButton("Filtrar");
	    btnDetalle = new JButton("Ver Detalle");
	    btnReimprimir = new JButton("Reimprimir Ticket");
	    btnSalir = new JButton("Salir");

	    // Configurar paneles
	    JPanel panelFiltros = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
	    JLabel lblDesde = new JLabel("Desde:");
	    JTextField txtDesde = new JTextField(10);
	    JLabel lblHasta = new JLabel("Hasta:");
	    JTextField txtHasta = new JTextField(10);
	    panelFiltros.add(lblDesde);
	    panelFiltros.add(txtDesde);
	    panelFiltros.add(lblHasta);
	    panelFiltros.add(txtHasta);
	    panelFiltros.add(btnFiltrar);

	    String[] columnas = {"Folio", "Fecha", "Hora", "Total", "Método Pago", "Atendió"};
	    modeloTabla = new DefaultTableModel(columnas, 0);
	    JTable tabla = new JTable(modeloTabla);

	    JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
	    panelBotones.add(btnDetalle);
	    panelBotones.add(btnReimprimir);
	    panelBotones.add(btnSalir);

	    panel.add(panelFiltros, BorderLayout.NORTH);
	    panel.add(new JScrollPane(tabla), BorderLayout.CENTER);
	    panel.add(panelBotones, BorderLayout.SOUTH);

	    add(panel);
	}
	
	public DefaultTableModel getModeloTabla() {
        return modeloTabla;
    }

    
    public void cargarVentas(Object[][] datos) {
        modeloTabla.setRowCount(0);
        for (Object[] fila : datos) {
            modeloTabla.addRow(fila);
        }
    }
    
    public String getFechaDesde() {
        return txtDesde.getText();
    }
    
    public String getFechaHasta() {
        return txtHasta.getText();
    }
    
    public int getFilaSeleccionada() {
        return tabla.getSelectedRow();
    }
    
    public String getFolioSeleccionado() {
        int fila = tabla.getSelectedRow();
        return fila >= 0 ? (String) modeloTabla.getValueAt(fila, 0) : null;
    }
    
    public void mostrarMensaje(String mensaje, String titulo) {
        JOptionPane.showMessageDialog(this, mensaje, titulo, JOptionPane.INFORMATION_MESSAGE);
    }
    
    public void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
    }
    
    public JButton getBtnFiltrar() { return btnFiltrar; }
    public JButton getBtnDetalle() { return btnDetalle; }
    public JButton getBtnReimprimir() { return btnReimprimir; }
    public JButton getBtnSalir() { return btnSalir; }
}