package Vista;

import javax.swing.*;
import java.util.List;
import Modelo.ProductoModel;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class AdministracionProductosView extends JFrame {
    private DefaultTableModel modeloTabla;
    private JTable tabla;
    private JButton btnAgregar, btnEditar, btnEliminar, btnReportePDF, btnSalir;
    private JTextField txtBusqueda;
    private JButton btnBuscar;
    private JButton btnLimpiar;
    private JLabel lblAlertaStock; // Nuevo: Label para la alerta de stock

    private final Color COLOR_PRIMARIO = new Color(231, 76, 60);
    private final Color COLOR_SECUNDARIO = new Color(241, 196, 15);
    private final Color COLOR_ELIMINAR = new Color(192, 57, 43);
    private final Color COLOR_FONDO = new Color(253, 245, 230);
    private final Color COLOR_TEXTO = Color.WHITE;
    private final Color COLOR_TEXTO_OSCURO = new Color(51, 51, 51);
    private final Color COLOR_AZUL = new Color(41, 128, 185);
    private final Color COLOR_ALERTA = new Color(231, 76, 60); // Color para la alerta

    public AdministracionProductosView() {
        setTitle("ADMINISTRACIÓN DE PRODUCTOS - La Esquinita");
        setSize(900, 650);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(COLOR_FONDO);

        JPanel panelPrincipal = new JPanel(new BorderLayout(15, 15));
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        panelPrincipal.setBackground(COLOR_FONDO);

        // Panel superior con barra de búsqueda
        JPanel panelSuperior = new JPanel(new BorderLayout(10, 10));
        panelSuperior.setBackground(COLOR_FONDO);
        
        txtBusqueda = new JTextField();
        txtBusqueda.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtBusqueda.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COLOR_PRIMARIO, 1),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        txtBusqueda.setToolTipText("Buscar por código o nombre del producto");
        
        btnBuscar = crearBotonEstilizado("Buscar", COLOR_SECUNDARIO);
        btnBuscar.setPreferredSize(new Dimension(100, 35));
        
        btnLimpiar = crearBotonEstilizado("Limpiar", COLOR_AZUL);
        btnLimpiar.setPreferredSize(new Dimension(100, 35));
        
        JPanel panelBotonesBusqueda = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        panelBotonesBusqueda.setBackground(COLOR_FONDO);
        panelBotonesBusqueda.add(btnBuscar);
        panelBotonesBusqueda.add(btnLimpiar);
        
        JPanel panelBusqueda = new JPanel(new BorderLayout(5, 5));
        panelBusqueda.setBackground(COLOR_FONDO);
        panelBusqueda.add(txtBusqueda, BorderLayout.CENTER);
        panelBusqueda.add(panelBotonesBusqueda, BorderLayout.EAST);
        
        // Panel para el título y la alerta de stock
        JPanel panelTitulo = new JPanel(new BorderLayout());
        panelTitulo.setBackground(COLOR_FONDO);
        
        // Crear y configurar la alerta de stock
        lblAlertaStock = new JLabel("0");
        lblAlertaStock.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblAlertaStock.setForeground(Color.WHITE);
        lblAlertaStock.setBackground(COLOR_ALERTA);
        lblAlertaStock.setOpaque(true);
        lblAlertaStock.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.WHITE, 1),
            BorderFactory.createEmptyBorder(2, 6, 2, 6)
        ));
        lblAlertaStock.setVisible(false); // Inicialmente oculto
        
        // Agregar componentes al panel de título
        panelTitulo.add(panelBusqueda, BorderLayout.CENTER);
        panelTitulo.add(lblAlertaStock, BorderLayout.EAST);
        
        panelSuperior.add(panelTitulo, BorderLayout.NORTH);
        panelPrincipal.add(panelSuperior, BorderLayout.NORTH);

        // Tabla de productos
        String[] columnas = {"Código", "Producto", "Precio", "Cantidad", "Categoría", "Descripción", "Proveedor"};
        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tabla = new JTable(modeloTabla);
        tabla.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        tabla.setRowHeight(25);
        tabla.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        tabla.getTableHeader().setBackground(COLOR_PRIMARIO);
        tabla.getTableHeader().setForeground(COLOR_TEXTO);
        tabla.getTableHeader().setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        JScrollPane scrollPane = new JScrollPane(tabla);
        scrollPane.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(COLOR_PRIMARIO, 1),
            "Lista de Productos",
            javax.swing.border.TitledBorder.LEFT,
            javax.swing.border.TitledBorder.TOP,
            new Font("Segoe UI", Font.BOLD, 12),
            COLOR_PRIMARIO
        ));

        panelPrincipal.add(scrollPane, BorderLayout.CENTER);

        // Panel de botones
        JPanel panelBotones = new JPanel();
        panelBotones.setLayout(new BoxLayout(panelBotones, BoxLayout.X_AXIS));
        panelBotones.setBackground(COLOR_FONDO);
        panelBotones.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
        
        btnAgregar = crearBotonEstilizado("Agregar", COLOR_PRIMARIO);
        btnEliminar = crearBotonEstilizado("Eliminar", COLOR_ELIMINAR);
        btnEditar = crearBotonEstilizado("Editar", COLOR_AZUL);
        btnReportePDF = crearBotonEstilizado("Generar Reporte PDF", new Color(0, 102, 102));
        btnSalir = crearBotonEstilizado("Salir", new Color(142, 68, 173));
        
        Dimension tamanoBoton = new Dimension(180, 35);
        btnAgregar.setPreferredSize(tamanoBoton);
        btnEliminar.setPreferredSize(tamanoBoton);
        btnEditar.setPreferredSize(tamanoBoton);
        btnReportePDF.setPreferredSize(tamanoBoton);
        btnSalir.setPreferredSize(tamanoBoton);
        
        panelBotones.add(Box.createHorizontalGlue());
        panelBotones.add(btnAgregar);
        panelBotones.add(Box.createHorizontalStrut(10));
        panelBotones.add(btnEliminar);
        panelBotones.add(Box.createHorizontalStrut(10));
        panelBotones.add(btnEditar);
        panelBotones.add(Box.createHorizontalStrut(10));
        panelBotones.add(btnReportePDF);
        panelBotones.add(Box.createHorizontalStrut(10));
        panelBotones.add(btnSalir);
        panelBotones.add(Box.createHorizontalGlue());
        
        panelPrincipal.add(panelBotones, BorderLayout.SOUTH);

        add(panelPrincipal);
    }

    // Método para actualizar la alerta de stock
    public void actualizarAlertaStock(int cantidadProductosBajoStock) {
        if (cantidadProductosBajoStock > 0) {
            lblAlertaStock.setText(String.valueOf(cantidadProductosBajoStock));
            lblAlertaStock.setVisible(true);
            
            // Opcional: Mostrar tooltip con más información
            lblAlertaStock.setToolTipText(cantidadProductosBajoStock + " productos con stock bajo");
        } else {
            lblAlertaStock.setVisible(false);
        }
    }

    public void limpiarBusqueda() {
        txtBusqueda.setText("");
    }
    
    private JButton crearBotonEstilizado(String texto, Color colorFondo) {
        JButton boton = new JButton(texto);
        boton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        boton.setForeground(COLOR_TEXTO);
        boton.setBackground(colorFondo);
        boton.setFocusPainted(false);
        boton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(colorFondo.darker(), 1),
            BorderFactory.createEmptyBorder(5, 15, 5, 15)
        ));
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        boton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                boton.setBackground(colorFondo.brighter());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                boton.setBackground(colorFondo);
            }
        });
        return boton;
    }

    // Resto de los métodos existentes se mantienen igual...
    public DefaultTableModel getModeloTabla() {
        return modeloTabla;
    }

    public String getTextoBusqueda() {
        return txtBusqueda.getText().trim();
    }

    public JButton getBtnAgregar() {
        return btnAgregar;
    }

    public JButton getBtnEditar() {
        return btnEditar;
    }

    public JButton getBtnBuscar() {
        return btnBuscar;
    }

    public JButton getBtnEliminar() {
        return btnEliminar;
    }

    public JButton getBtnReportePDF() {
        return btnReportePDF;
    }

    public JButton getBtnSalir() {
        return btnSalir;
    }

    public int getFilaSeleccionada() {
        return tabla.getSelectedRow();
    }

    public String getCodigoProductoSeleccionado() {
        int fila = tabla.getSelectedRow();
        return fila >= 0 ? (String) modeloTabla.getValueAt(fila, 0) : null;
    }

    public void cargarProductos(Object[][] datos) {
        String[] columnas = {"Código", "Producto", "Precio", "Precio con Impuesto", "Cantidad", "Categoría", "Descripción", "Proveedor", "Impuesto"};
        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        tabla.setModel(modeloTabla);
        
        for (Object[] fila : datos) {
            modeloTabla.addRow(fila);
        }
    }

    public void mostrarMensaje(String mensaje, String titulo) {
        JOptionPane.showMessageDialog(this, mensaje, titulo, JOptionPane.INFORMATION_MESSAGE);
    }

    public void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
    }

    public String pedirNuevoValor(String mensaje, Object valorActual) {
        return JOptionPane.showInputDialog(this, mensaje, valorActual);
    }

    public int mostrarOpcionesAjuste(String titulo, String mensaje, String[] opciones) {
        return JOptionPane.showOptionDialog(this, mensaje, titulo, JOptionPane.DEFAULT_OPTION,
                JOptionPane.PLAIN_MESSAGE, null, opciones, opciones[0]);
    }
    
    public JButton getBtnLimpiar() {
        return btnLimpiar;
    }
}