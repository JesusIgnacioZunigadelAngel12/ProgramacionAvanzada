package Vista;

import javax.swing.*;
import java.util.List;
import Modelo.ProductoModel;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

public class AdministracionProductosView extends JFrame {
    private DefaultTableModel modeloTabla;
    private JTable tabla;
    private JButton btnAgregar, btnEditar, btnEliminar, btnSalir;
    private JTextField txtBusqueda;
    private JButton btnBuscar;
    private JButton btnLimpiar;
    private JLabel lblAlertaStock;
    private JPanel panelImagen;
    private JLabel lblImagen;

    private final Color COLOR_PRIMARIO = new Color(231, 76, 60);
    private final Color COLOR_SECUNDARIO = new Color(241, 196, 15);
    private final Color COLOR_ELIMINAR = new Color(192, 57, 43);
    private final Color COLOR_FONDO = new Color(253, 245, 230);
    private final Color COLOR_TEXTO = Color.WHITE;
    private final Color COLOR_TEXTO_OSCURO = new Color(51, 51, 51);
    private final Color COLOR_AZUL = new Color(41, 128, 185);
    private final Color COLOR_ALERTA = new Color(231, 76, 60);

    public AdministracionProductosView() {
        setTitle("ADMINISTRACIÓN DE PRODUCTOS - Abarrites Don Nacho");
        setSize(1100, 650); // Aumentamos el ancho para acomodar el panel de imagen
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(COLOR_FONDO);

        JPanel panelPrincipal = new JPanel(new BorderLayout(15, 15));
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        panelPrincipal.setBackground(COLOR_FONDO);

        // Panel superior con barra de búsqueda
        JPanel panelSuperior = new JPanel(new BorderLayout(10, 10));
        panelSuperior.setBackground(COLOR_FONDO);
        
        txtBusqueda = new JTextField();
        txtBusqueda.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtBusqueda.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COLOR_PRIMARIO, 1),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        txtBusqueda.setToolTipText("Buscar por código o nombre del producto");
        
        btnBuscar = crearBotonEstilizado("Buscar", COLOR_SECUNDARIO);
        btnBuscar.setPreferredSize(new Dimension(100, 35));
        
        btnLimpiar = crearBotonEstilizado("Limpiar", COLOR_AZUL);
        btnLimpiar.setPreferredSize(new Dimension(100, 35));
        
        JPanel panelBotonesBusqueda = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        panelBotonesBusqueda.setBackground(COLOR_FONDO);
        panelBotonesBusqueda.add(btnBuscar);
        panelBotonesBusqueda.add(btnLimpiar);
        
        JPanel panelBusqueda = new JPanel(new BorderLayout(5, 5));
        panelBusqueda.setBackground(COLOR_FONDO);
        panelBusqueda.add(txtBusqueda, BorderLayout.CENTER);
        panelBusqueda.add(panelBotonesBusqueda, BorderLayout.EAST);
        
        // Panel para el título y la alerta de stock
        JPanel panelTitulo = new JPanel(new BorderLayout());
        panelTitulo.setBackground(COLOR_FONDO);
        
        lblAlertaStock = new JLabel("0");
        lblAlertaStock.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblAlertaStock.setForeground(Color.WHITE);
        lblAlertaStock.setBackground(COLOR_ALERTA);
        lblAlertaStock.setOpaque(true);
        lblAlertaStock.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.WHITE, 1),
            BorderFactory.createEmptyBorder(2, 6, 2, 6)
        ));
        lblAlertaStock.setVisible(false);
        
        panelTitulo.add(panelBusqueda, BorderLayout.CENTER);
        panelTitulo.add(lblAlertaStock, BorderLayout.EAST);
        
        panelSuperior.add(panelTitulo, BorderLayout.NORTH);
        panelPrincipal.add(panelSuperior, BorderLayout.NORTH);

        // Tabla de productos
        String[] columnas = {"Código", "Producto", "Precio", "Precio con Impuesto", "Cantidad", "Categoría", "Descripción", "Proveedor", "Impuesto", "Imagen"};
        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tabla = new JTable(modeloTabla);
        tabla.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        tabla.setRowHeight(25);
        tabla.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        tabla.getTableHeader().setBackground(COLOR_PRIMARIO);
        tabla.getTableHeader().setForeground(COLOR_TEXTO);
        tabla.getTableHeader().setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        
        // Ocultar la columna de imagen (solo la usaremos para mostrar en el panel)
        tabla.removeColumn(tabla.getColumnModel().getColumn(9));

        JScrollPane scrollPane = new JScrollPane(tabla);
        scrollPane.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(COLOR_PRIMARIO, 1),
            "Lista de Productos",
            javax.swing.border.TitledBorder.LEFT,
            javax.swing.border.TitledBorder.TOP,
            new Font("Segoe UI", Font.BOLD, 12),
            COLOR_PRIMARIO
        ));

        // Panel para mostrar la imagen del producto seleccionado
        panelImagen = new JPanel(new BorderLayout());
        panelImagen.setPreferredSize(new Dimension(250, 300));
        panelImagen.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(COLOR_PRIMARIO, 1),
            "Imagen del Producto",
            javax.swing.border.TitledBorder.LEFT,
            javax.swing.border.TitledBorder.TOP,
            new Font("Segoe UI", Font.BOLD, 12),
            COLOR_PRIMARIO
        ));
        
        lblImagen = new JLabel("", SwingConstants.CENTER);
        lblImagen.setPreferredSize(new Dimension(230, 270));
        panelImagen.add(lblImagen, BorderLayout.CENTER);
        
        // Panel central que contiene la tabla y el panel de imagen
        JPanel panelCentral = new JPanel(new BorderLayout(10, 10));
        panelCentral.add(scrollPane, BorderLayout.CENTER);
        panelCentral.add(panelImagen, BorderLayout.EAST);
        
        panelPrincipal.add(panelCentral, BorderLayout.CENTER);

        // Panel de botones
        JPanel panelBotones = new JPanel();
        panelBotones.setLayout(new BoxLayout(panelBotones, BoxLayout.X_AXIS));
        panelBotones.setBackground(COLOR_FONDO);
        panelBotones.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
        
        btnAgregar = crearBotonEstilizado("Agregar", COLOR_PRIMARIO);
        btnEliminar = crearBotonEstilizado("Eliminar", COLOR_ELIMINAR);
        btnEditar = crearBotonEstilizado("Editar", COLOR_AZUL);
        btnSalir = crearBotonEstilizado("Salir", new Color(142, 68, 173));
        
        Dimension tamanoBoton = new Dimension(180, 35);
        btnAgregar.setPreferredSize(tamanoBoton);
        btnEliminar.setPreferredSize(tamanoBoton);
        btnEditar.setPreferredSize(tamanoBoton);
        btnSalir.setPreferredSize(tamanoBoton);
        
        panelBotones.add(Box.createHorizontalGlue());
        panelBotones.add(btnAgregar);
        panelBotones.add(Box.createHorizontalStrut(10));
        panelBotones.add(btnEliminar);
        panelBotones.add(Box.createHorizontalStrut(10));
        panelBotones.add(btnEditar);
        panelBotones.add(Box.createHorizontalStrut(10));
        panelBotones.add(btnSalir);
        panelBotones.add(Box.createHorizontalGlue());
        
        panelPrincipal.add(panelBotones, BorderLayout.SOUTH);

        // Listener para mostrar la imagen cuando se selecciona un producto
        tabla.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                mostrarImagenProductoSeleccionado();
            }
        });

        add(panelPrincipal);
    }

    private void mostrarImagenProductoSeleccionado() {
        int fila = tabla.getSelectedRow();
        if (fila >= 0) {
            String imagenPath = (String) modeloTabla.getValueAt(fila, 9); // La imagen está en la columna 9
            mostrarImagen(imagenPath);
        } else {
            lblImagen.setIcon(null);
            lblImagen.setText("Seleccione un producto");
        }
    }

    public void mostrarImagen(String imagenPath) {
        if (imagenPath != null && !imagenPath.isEmpty()) {
            try {
                // Cargar la imagen y escalarla
                ImageIcon icon = new ImageIcon(imagenPath);
                Image img = icon.getImage();
                
                // Calcular las nuevas dimensiones manteniendo el aspect ratio
                int lblWidth = lblImagen.getWidth();
                int lblHeight = lblImagen.getHeight();
                double imgRatio = (double) icon.getIconWidth() / icon.getIconHeight();
                double lblRatio = (double) lblWidth / lblHeight;
                
                int newWidth, newHeight;
                if (imgRatio > lblRatio) {
                    newWidth = lblWidth;
                    newHeight = (int) (newWidth / imgRatio);
                } else {
                    newHeight = lblHeight;
                    newWidth = (int) (newHeight * imgRatio);
                }
                
                Image scaledImg = img.getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);
                lblImagen.setIcon(new ImageIcon(scaledImg));
                lblImagen.setText("");
            } catch (Exception e) {
                lblImagen.setIcon(null);
                lblImagen.setText("Imagen no disponible");
            }
        } else {
            lblImagen.setIcon(null);
            lblImagen.setText("Sin imagen");
        }
    }

    public void actualizarAlertaStock(int cantidadProductosBajoStock) {
        if (cantidadProductosBajoStock > 0) {
            lblAlertaStock.setText(String.valueOf(cantidadProductosBajoStock));
            lblAlertaStock.setVisible(true);
            lblAlertaStock.setToolTipText(cantidadProductosBajoStock + " productos con stock bajo");
        } else {
            lblAlertaStock.setVisible(false);
        }
    }

    public void limpiarBusqueda() {
        txtBusqueda.setText("");
    }
    
    private JButton crearBotonEstilizado(String texto, Color colorFondo) {
        JButton boton = new JButton(texto);
        boton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        boton.setForeground(COLOR_TEXTO);
        boton.setBackground(colorFondo);
        boton.setFocusPainted(false);
        boton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(colorFondo.darker(), 1),
            BorderFactory.createEmptyBorder(5, 15, 5, 15)
        ));
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        boton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                boton.setBackground(colorFondo.brighter());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                boton.setBackground(colorFondo);
            }
        });
        return boton;
    }

    // Métodos getter
    public DefaultTableModel getModeloTabla() {
        return modeloTabla;
    }

    public String getTextoBusqueda() {
        return txtBusqueda.getText().trim();
    }

    public JButton getBtnAgregar() {
        return btnAgregar;
    }

    public JButton getBtnEditar() {
        return btnEditar;
    }

    public JButton getBtnBuscar() {
        return btnBuscar;
    }

    public JButton getBtnEliminar() {
        return btnEliminar;
    }

    public JButton getBtnSalir() {
        return btnSalir;
    }

    public int getFilaSeleccionada() {
        return tabla.getSelectedRow();
    }

    public String getCodigoProductoSeleccionado() {
        int fila = tabla.getSelectedRow();
        return fila >= 0 ? (String) modeloTabla.getValueAt(fila, 0) : null;
    }

    public void cargarProductos(Object[][] datos) {
        String[] columnas = {"Código", "Producto", "Precio", "Precio con Impuesto", "Cantidad", "Categoría", "Descripción", "Proveedor", "Impuesto", "Imagen"};
        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        tabla.setModel(modeloTabla);
        
        for (Object[] fila : datos) {
            modeloTabla.addRow(fila);
        }
        
        // Ocultar la columna de imagen (mostramos solo en el panel lateral)
        tabla.removeColumn(tabla.getColumnModel().getColumn(9));
    }

    public void mostrarMensaje(String mensaje, String titulo) {
        JOptionPane.showMessageDialog(this, mensaje, titulo, JOptionPane.INFORMATION_MESSAGE);
    }

    public void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
    }

    public String pedirNuevoValor(String mensaje, Object valorActual) {
        return JOptionPane.showInputDialog(this, mensaje, valorActual);
    }

    public int mostrarOpcionesAjuste(String titulo, String mensaje, String[] opciones) {
        return JOptionPane.showOptionDialog(this, mensaje, titulo, JOptionPane.DEFAULT_OPTION,
                JOptionPane.PLAIN_MESSAGE, null, opciones, opciones[0]);
    }
    
    public JButton getBtnLimpiar() {
        return btnLimpiar;
    }
}