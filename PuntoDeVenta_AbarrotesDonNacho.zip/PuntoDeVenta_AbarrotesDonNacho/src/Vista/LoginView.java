package Vista;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;

public class LoginView extends JFrame {
    private JTextField txtUsuario;
    private JPasswordField txtPassword;
    private JButton btnEntrar;
    private JButton btnSalir;

    // Nuevos componentes
    private JButton btnRegistrarUsuario;
    private JButton btnRecuperarContrasena;

    public LoginView() {
        // Configuración básica de la ventana
        setTitle("Abarrotes Don Nacho - Sistema de Punto de Venta");
        setSize(450, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setUndecorated(true);
        setShape(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 20, 20));

        // Panel principal con sombra
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));
        mainPanel.setBackground(new Color(245, 245, 245));

        // Panel del título
        JPanel titlePanel = new JPanel();
        titlePanel.setLayout(new BoxLayout(titlePanel, BoxLayout.Y_AXIS));
        titlePanel.setOpaque(false);

        JLabel lblTitle = new JLabel("Abarrotes Don Nacho");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitle.setForeground(new Color(0, 120, 215));
        lblTitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel lblSubtitle = new JLabel("Sistema de Punto de Venta");
        lblSubtitle.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblSubtitle.setForeground(new Color(70, 70, 70));
        lblSubtitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        titlePanel.add(Box.createVerticalStrut(20));
        titlePanel.add(lblTitle);
        titlePanel.add(lblSubtitle);
        titlePanel.add(Box.createVerticalStrut(40));

        // Panel del formulario
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridBagLayout());
        formPanel.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Campo Usuario
        JLabel lblUsuario = new JLabel("Usuario:");
        lblUsuario.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST;
        formPanel.add(lblUsuario, gbc);

        txtUsuario = new JTextField(20);
        txtUsuario.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtUsuario.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(8, 10, 8, 10)
        ));
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.ipady = 8;
        formPanel.add(txtUsuario, gbc);

        // Campo Contraseña
        JLabel lblPassword = new JLabel("Contraseña:");
        lblPassword.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.ipady = 0;
        formPanel.add(lblPassword, gbc);

        txtPassword = new JPasswordField(20);
        txtPassword.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtPassword.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(8, 10, 8, 10)
        ));
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.ipady = 8;
        formPanel.add(txtPassword, gbc);

        // Botón Entrar
        btnEntrar = new JButton("INICIAR SESIÓN");
        btnEntrar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnEntrar.setForeground(Color.WHITE);
        btnEntrar.setBackground(new Color(0, 120, 215));
        btnEntrar.setFocusPainted(false);
        btnEntrar.setBorderPainted(false);
        btnEntrar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnEntrar.setPreferredSize(new Dimension(200, 40));
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.ipady = 0;
        gbc.insets = new Insets(20, 10, 10, 10);
        formPanel.add(btnEntrar, gbc);

        // Botón Salir
        btnSalir = new JButton("Salir");
        btnSalir.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        btnSalir.setForeground(new Color(100, 100, 100));
        btnSalir.setContentAreaFilled(false);
        btnSalir.setBorderPainted(false);
        btnSalir.setCursor(new Cursor(Cursor.HAND_CURSOR));
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.insets = new Insets(0, 10, 10, 10);
        formPanel.add(btnSalir, gbc);

        // Acción para el botón Salir
        btnSalir.addActionListener(e -> System.exit(0));

        // Agregar paneles al contenedor principal
        mainPanel.add(titlePanel, BorderLayout.NORTH);
        mainPanel.add(formPanel, BorderLayout.CENTER);

        // Panel inferior para botones adicionales
        JPanel panelAcciones = new JPanel(new GridLayout(1, 2, 10, 0)); // 1 fila, 2 columnas, espacio horizontal
        panelAcciones.setBackground(new Color(245, 245, 245));

        // Botón Registrar Nuevo Usuario
        btnRegistrarUsuario = new JButton("Registrar Nuevo Usuario");
        btnRegistrarUsuario.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        btnRegistrarUsuario.setForeground(new Color(0, 120, 215));
        btnRegistrarUsuario.setContentAreaFilled(false);
        btnRegistrarUsuario.setBorderPainted(false);
        btnRegistrarUsuario.setCursor(new Cursor(Cursor.HAND_CURSOR));
        panelAcciones.add(btnRegistrarUsuario);

        // Botón Olvidé mi Contraseña
        btnRecuperarContrasena = new JButton("Olvidé mi Contraseña");
        btnRecuperarContrasena.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        btnRecuperarContrasena.setForeground(new Color(0, 120, 215));
        btnRecuperarContrasena.setContentAreaFilled(false);
        btnRecuperarContrasena.setBorderPainted(false);
        btnRecuperarContrasena.setCursor(new Cursor(Cursor.HAND_CURSOR));
        panelAcciones.add(btnRecuperarContrasena);

        // Agregar panel de acciones al mainPanel
        mainPanel.add(panelAcciones, BorderLayout.SOUTH);

        // Agregar sombra (simulada con bordes)
        JPanel shadowPanel = new JPanel(new BorderLayout());
        shadowPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        shadowPanel.setBackground(new Color(245, 245, 245));
        shadowPanel.add(mainPanel);

        add(shadowPanel);

        // Forzar el foco al campo de usuario
        SwingUtilities.invokeLater(() -> txtUsuario.requestFocusInWindow());
    }

    // Métodos de acceso existentes
    public JButton getBtnEntrar() {
        return btnEntrar;
    }

    public String getUsuario() {
        return txtUsuario.getText();
    }

    public String getPassword() {
        return new String(txtPassword.getPassword());
    }

    public void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Error de autenticación", JOptionPane.ERROR_MESSAGE);
    }
    
    public void mostrarMensaje(String mensaje, String titulo) {
        JOptionPane.showMessageDialog(this, mensaje, titulo, JOptionPane.INFORMATION_MESSAGE);
    }

    // Métodos nuevos para acceder a los botones adicionales
    public JButton getBtnRegistrarUsuario() {
        return btnRegistrarUsuario;
    }

    public JButton getBtnRecuperarContrasena() {
        return btnRecuperarContrasena;
    }

    // Método para mostrar diálogo de autenticación del admin
    public boolean autenticarAdmin() {
        String usuario = JOptionPane.showInputDialog(this, "Ingrese el usuario del administrador:");
        String contrasena = JOptionPane.showInputDialog(this, "Ingrese la contraseña del administrador:");
        return "admin".equals(usuario) && "123".equals(contrasena);
    }

    // Método para mostrar diálogo de registro de nuevo usuario
    public String mostrarDialogoRegistro() {
        JPanel panel = new JPanel(new GridLayout(2, 2, 10, 10));
        JTextField txtUsuario = new JTextField();
        JPasswordField txtPassword = new JPasswordField();
        panel.add(new JLabel("Nuevo Usuario:"));
        panel.add(txtUsuario);
        panel.add(new JLabel("Nueva Contraseña:"));
        panel.add(txtPassword);

        int result = JOptionPane.showConfirmDialog(this, panel, "Registrar Nuevo Usuario",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result == JOptionPane.OK_OPTION) {
            return txtUsuario.getText() + ";" + new String(txtPassword.getPassword());
        }
        return null;
    }

    // Método para mostrar diálogo de recuperación de contraseña
    public String[] mostrarDialogoRecuperacion() {
        String username = JOptionPane.showInputDialog(this, "Ingrese el nombre de usuario:");
        if (username == null || username.trim().isEmpty()) return null;

        String nuevaPassword = JOptionPane.showInputDialog(this, "Ingrese la nueva contraseña:");
        if (nuevaPassword == null || nuevaPassword.trim().isEmpty()) return null;

        return new String[]{username, nuevaPassword};
    }

}