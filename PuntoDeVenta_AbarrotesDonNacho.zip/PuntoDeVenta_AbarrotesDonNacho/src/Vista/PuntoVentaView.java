package Vista;

import Modelo.ClienteModel;
import Modelo.ProductoModel;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

public class PuntoVentaView extends JFrame {
    private DefaultTableModel modeloTablaProductos;
    private JTable tablaProductos;
    private DefaultTableModel modeloTablaVenta;
    private JTable tablaVenta;
    private JTextField txtBusqueda;
    private JLabel lblTotal;
    private JButton btnBuscar, btnAgregar, btnPagar, btnSalir, btnEditarCantidad, btnCancelarVenta, btnEliminarProducto, btnLimpiar;
    private JComboBox<ClienteModel.Cliente> comboClientes;

    // Paleta de colores
    private final Color COLOR_PRIMARIO = new Color(231, 76, 60); // Rojo anaranjado
    private final Color COLOR_SECUNDARIO = new Color(241, 196, 15); // Amarillo dorado
    private final Color COLOR_FONDO = new Color(253, 245, 230); // Beige claro
    private final Color COLOR_TEXTO = Color.WHITE;
    private final Color COLOR_TEXTO_OSCURO = new Color(51, 51, 51);
    private final Color COLOR_CAJA_ABIERTA = new Color(39, 174, 96); // Verde
    private final Color COLOR_CAJA_CERRADA = new Color(192, 57, 43); // Rojo oscuro
    private final Color COLOR_INFO = new Color(41, 128, 185); // Azul
    
    public PuntoVentaView() {
        setTitle("PUNTO DE VENTA - Abarrotes Don Nacho");
        setSize(1100, 750);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(COLOR_FONDO);

        JPanel panelPrincipal = new JPanel(new BorderLayout(10, 10));
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        panelPrincipal.setBackground(COLOR_FONDO);

        // Panel superior: Buscar productos y selección de cliente
        JPanel panelSuperior = new JPanel(new BorderLayout(10, 10));
        panelSuperior.setBackground(COLOR_FONDO);
        
        // Panel de búsqueda
        txtBusqueda = new JTextField();
        txtBusqueda.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtBusqueda.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COLOR_PRIMARIO, 1),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        txtBusqueda.setToolTipText("Buscar por código o nombre del producto");
        
        btnBuscar = crearBotonEstilizado("Buscar", COLOR_PRIMARIO);
        btnBuscar.setPreferredSize(new Dimension(100, 35));
        
        btnLimpiar = crearBotonEstilizado("Limpiar", COLOR_INFO);
        btnLimpiar.setPreferredSize(new Dimension(100, 35));
        
        JPanel panelBotonesBusqueda = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        panelBotonesBusqueda.setBackground(COLOR_FONDO);
        panelBotonesBusqueda.add(btnBuscar);
        panelBotonesBusqueda.add(btnLimpiar);
        
        JPanel panelBusqueda = new JPanel(new BorderLayout(5, 5));
        panelBusqueda.setBackground(COLOR_FONDO);
        panelBusqueda.add(txtBusqueda, BorderLayout.CENTER);
        panelBusqueda.add(panelBotonesBusqueda, BorderLayout.EAST);
        
        panelSuperior.add(panelBusqueda, BorderLayout.NORTH);
        
        // Panel de selección de cliente
        initComponentesCliente();
        panelSuperior.add(crearPanelCliente(), BorderLayout.SOUTH);
        
        panelPrincipal.add(panelSuperior, BorderLayout.NORTH);

        // Tabla de productos disponibles
        String[] columnasProductos = {"Código", "Nombre", "Precio(Con IVA)", "Cantidad"};
        modeloTablaProductos = new DefaultTableModel(columnasProductos, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tablaProductos = new JTable(modeloTablaProductos);
        tablaProductos.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        tablaProductos.setRowHeight(25);
        tablaProductos.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        tablaProductos.getTableHeader().setBackground(COLOR_PRIMARIO);
        tablaProductos.getTableHeader().setForeground(COLOR_TEXTO);
        
        // Agregar listener para doble clic
        tablaProductos.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    int fila = tablaProductos.rowAtPoint(e.getPoint());
                    if (fila >= 0) {
                        String codigo = (String) modeloTablaProductos.getValueAt(fila, 0);
                        String nombre = (String) modeloTablaProductos.getValueAt(fila, 1);
                        double precio = (Double) modeloTablaProductos.getValueAt(fila, 2);
                        int stock = (Integer) modeloTablaProductos.getValueAt(fila, 3);
                        
                        // Pedir cantidad directamente
                        String cantidadStr = JOptionPane.showInputDialog(
                            PuntoVentaView.this, 
                            "Ingrese cantidad para " + nombre + " (Stock: " + stock + "):", 
                            "1");
                        
                        try {
                            int cantidad = cantidadStr != null ? Integer.parseInt(cantidadStr) : 0;
                            if (cantidad > 0 && cantidad <= stock) {
                                // Agregar directamente a la venta
                                Object[] productoVenta = {codigo, nombre, precio, cantidad};
                                agregarProductoAVenta(productoVenta);
                            } else if (cantidad > stock) {
                                mostrarError("No hay suficiente stock. Disponible: " + stock);
                            }
                        } catch (NumberFormatException ex) {
                            mostrarError("Ingrese un número válido");
                        }
                    }
                }
            }
        });
        
        JScrollPane scrollPaneProductos = new JScrollPane(tablaProductos);
        scrollPaneProductos.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(COLOR_PRIMARIO, 1),
            "Productos Disponibles",
            javax.swing.border.TitledBorder.LEFT,
            javax.swing.border.TitledBorder.TOP,
            new Font("Segoe UI", Font.BOLD, 12),
            COLOR_PRIMARIO
        ));

        // Tabla de venta actual
        String[] columnasVenta = {"Código", "Nombre", "Precio", "Cantidad"};
        modeloTablaVenta = new DefaultTableModel(columnasVenta, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        tablaVenta = new JTable(modeloTablaVenta);
        tablaVenta.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        tablaVenta.setRowHeight(25);
        tablaVenta.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        tablaVenta.getTableHeader().setBackground(COLOR_PRIMARIO);
        tablaVenta.getTableHeader().setForeground(COLOR_TEXTO);
        JScrollPane scrollPaneVenta = new JScrollPane(tablaVenta);
        scrollPaneVenta.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(COLOR_PRIMARIO, 1),
            "Venta Actual",
            javax.swing.border.TitledBorder.LEFT,
            javax.swing.border.TitledBorder.TOP,
            new Font("Segoe UI", Font.BOLD, 12),
            COLOR_PRIMARIO
        ));

        // Panel central: Dividir tablas
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, scrollPaneProductos, scrollPaneVenta);
        splitPane.setDividerLocation(550);
        splitPane.setBackground(COLOR_FONDO);

        // Panel inferior: Total y botones
        JPanel panelInferior = new JPanel(new BorderLayout(10, 10));
        panelInferior.setBackground(COLOR_FONDO);
        
        lblTotal = new JLabel("Total: $0.00", SwingConstants.CENTER);
        lblTotal.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblTotal.setForeground(COLOR_PRIMARIO);
        lblTotal.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panelInferior.add(lblTotal, BorderLayout.CENTER);

        JPanel panelBotones = new JPanel();
        panelBotones.setLayout(new BoxLayout(panelBotones, BoxLayout.X_AXIS));
        panelBotones.setBackground(COLOR_FONDO);
        panelBotones.setBorder(BorderFactory.createEmptyBorder(5, 0, 5, 0));
        
        btnAgregar = crearBotonEstilizado("Agregar a Venta", COLOR_PRIMARIO);
        btnEliminarProducto = crearBotonEstilizado("Eliminar Producto", new Color(192, 57, 43));
        btnPagar = crearBotonEstilizado("Pagar", new Color(39, 174, 96));
        btnCancelarVenta = crearBotonEstilizado("Cancelar Venta", new Color(192, 57, 43));
        btnEditarCantidad = crearBotonEstilizado("Editar Cantidad", COLOR_SECUNDARIO);
        btnSalir = crearBotonEstilizado("Salir", new Color(142, 68, 173));
        
        Dimension tamanoBoton = new Dimension(150, 40);
        btnAgregar.setPreferredSize(tamanoBoton);
        btnEliminarProducto.setPreferredSize(tamanoBoton);
        btnPagar.setPreferredSize(tamanoBoton);
        btnCancelarVenta.setPreferredSize(tamanoBoton);
        btnEditarCantidad.setPreferredSize(tamanoBoton);
        btnSalir.setPreferredSize(tamanoBoton);
        
        panelBotones.add(Box.createHorizontalGlue());
        panelBotones.add(btnAgregar);
        panelBotones.add(Box.createHorizontalStrut(10));
        panelBotones.add(btnEliminarProducto);
        panelBotones.add(Box.createHorizontalStrut(10));
        panelBotones.add(btnPagar);
        panelBotones.add(Box.createHorizontalStrut(10));
        panelBotones.add(btnCancelarVenta);
        panelBotones.add(Box.createHorizontalStrut(10));
        panelBotones.add(btnEditarCantidad);
        panelBotones.add(Box.createHorizontalStrut(10));
        panelBotones.add(btnSalir);
        panelBotones.add(Box.createHorizontalGlue());
        
        panelInferior.add(panelBotones, BorderLayout.SOUTH);

        // Agregar paneles al panel principal
        panelPrincipal.add(splitPane, BorderLayout.CENTER);
        panelPrincipal.add(panelInferior, BorderLayout.SOUTH);

        add(panelPrincipal);
    }

    private void initComponentesCliente() {
        comboClientes = new JComboBox<>();
        comboClientes.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, 
                    int index, boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (value instanceof ClienteModel.Cliente) {
                    ClienteModel.Cliente c = (ClienteModel.Cliente) value;
                    setText(c.getNombre() + " (" + c.getTelefono() + ")");
                } else if (value == null) {
                    setText("Cliente general");
                }
                return this;
            }
        });
        comboClientes.setPreferredSize(new Dimension(250, 30));
    }

    private JPanel crearPanelCliente() {
        JPanel panelCliente = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelCliente.setBackground(COLOR_FONDO);
        
        panelCliente.add(new JLabel("Cliente:"));
        panelCliente.add(comboClientes);
        
        return panelCliente;
    }

    private JButton crearBotonEstilizado(String texto, Color colorFondo) {
        JButton boton = new JButton(texto);
        boton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        boton.setForeground(COLOR_TEXTO);
        boton.setBackground(colorFondo);
        boton.setFocusPainted(false);
        boton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(colorFondo.darker(), 1),
            BorderFactory.createEmptyBorder(5, 15, 5, 15)
        ));
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        boton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                boton.setBackground(colorFondo.brighter());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                boton.setBackground(colorFondo);
            }
        });
        return boton;
    }

    // Métodos para acceder a los componentes
    public DefaultTableModel getModeloTablaProductos() {
        return modeloTablaProductos;
    }

    public DefaultTableModel getModeloTablaVenta() {
        return modeloTablaVenta;
    }

    public String getTextoBusqueda() {
        return txtBusqueda.getText().trim();
    }

    public int getFilaSeleccionada() {
        return tablaProductos.getSelectedRow();
    }

    public int getFilaSeleccionadaVenta() {
        return tablaVenta.getSelectedRow();
    }

    public ClienteModel.Cliente getClienteSeleccionado() {
        return (ClienteModel.Cliente) comboClientes.getSelectedItem();
    }
    
    public JComboBox<ClienteModel.Cliente> getComboClientes() {
        return comboClientes;
    }

    public void cargarClientes(List<ClienteModel.Cliente> clientes) {
        comboClientes.removeAllItems();
        comboClientes.addItem(null); // Opción para cliente general
        for (ClienteModel.Cliente c : clientes) {
            comboClientes.addItem(c);
        }
    }
    
    public void limpiarBusqueda() {
        txtBusqueda.setText("");
    }

    public void cargarProductos(Object[][] datos) {
        modeloTablaProductos.setRowCount(0);
        for (Object[] fila : datos) {
            modeloTablaProductos.addRow(fila);
        }
    }

    public void agregarProductoAVenta(Object[] producto) {
        String codigo = (String) producto[0];
        int cantidad = (Integer) producto[3];
        
        // Verificar si el producto ya está en la venta
        boolean encontrado = false;
        for (int i = 0; i < modeloTablaVenta.getRowCount(); i++) {
            if (codigo.equals(modeloTablaVenta.getValueAt(i, 0))) {
                int cantidadActual = (Integer) modeloTablaVenta.getValueAt(i, 3);
                modeloTablaVenta.setValueAt(cantidadActual + cantidad, i, 3);
                encontrado = true;
                break;
            }
        }
        
        if (!encontrado) {
            modeloTablaVenta.addRow(producto);
        }
        
        actualizarTotal();
    }

    public void actualizarTotal() {
        double total = 0;
        for (int i = 0; i < modeloTablaVenta.getRowCount(); i++) {
            double precio = (Double) modeloTablaVenta.getValueAt(i, 2);
            int cantidad = (Integer) modeloTablaVenta.getValueAt(i, 3);
            total += precio * cantidad;
        }
        lblTotal.setText("Total: $" + String.format("%.2f", total));
    }

    public void mostrarMensaje(String mensaje, String titulo) {
        JOptionPane.showMessageDialog(this, mensaje, titulo, JOptionPane.INFORMATION_MESSAGE);
    }

    public void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
    }

    // Métodos para los listeners
    public void setBuscarListener(ActionListener listener) {
        btnBuscar.addActionListener(listener);
    }

    public void setAgregarListener(ActionListener listener) {
        btnAgregar.addActionListener(listener);
    }

    public void setEliminarProductoListener(ActionListener listener) {
        btnEliminarProducto.addActionListener(listener);
    }

    public void setPagarListener(ActionListener listener) {
        btnPagar.addActionListener(listener);
    }

    public void setCancelarVentaListener(ActionListener listener) {
        btnCancelarVenta.addActionListener(listener);
    }

    public void setEditarCantidadListener(ActionListener listener) {
        btnEditarCantidad.addActionListener(listener);
    }

    public void setSalirListener(ActionListener listener) {
        btnSalir.addActionListener(listener);
    }
    
    public void setLimpiarListener(ActionListener listener) {
        btnLimpiar.addActionListener(listener);
    }
}