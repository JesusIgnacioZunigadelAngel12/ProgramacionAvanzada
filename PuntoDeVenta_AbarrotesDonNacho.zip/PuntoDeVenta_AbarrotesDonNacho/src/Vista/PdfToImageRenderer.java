package Vista;

import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.rendering.PDFRenderer;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class PdfToImageRenderer extends JDialog {

    public PdfToImageRenderer(JFrame parent, byte[] pdfBytes) {
        super(parent, "Vista Previa del Ticket", false);
        setSize(600, 800);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        setModalityType(ModalityType.MODELESS);
        setLayout(new BorderLayout());

        try {
            // Cargar el PDF desde bytes
            PDDocument document = Loader.loadPDF(pdfBytes);
            PDFRenderer renderer = new PDFRenderer(document);

            // Renderizar la primera página como imagen
            BufferedImage image = renderer.renderImage(0, 1.5f); // Zoom 1.5x
            JLabel label = new JLabel(new ImageIcon(image));
            JScrollPane scrollPane = new JScrollPane(label);
            add(scrollPane, BorderLayout.CENTER);

            // Botón para cerrar
            JButton btnCerrar = new JButton("Cerrar");
            btnCerrar.addActionListener(e -> dispose());

            // Botón para guardar
            JButton btnGuardar = new JButton("Guardar");
            btnGuardar.addActionListener(e -> guardarPDF(pdfBytes));

            JPanel panelBotones = new JPanel();
            panelBotones.add(btnGuardar);
            panelBotones.add(btnCerrar);
            add(panelBotones, BorderLayout.SOUTH);

            document.close();

        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, 
                "Error al mostrar el PDF: " + ex.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
            dispose();
        }
    }

    private void guardarPDF(byte[] pdfBytes) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Guardar Ticket como PDF");
        fileChooser.setSelectedFile(new File("ticket_venta_" + System.currentTimeMillis() + ".pdf"));
        fileChooser.setFileFilter(new javax.swing.filechooser.FileFilter() {
            public boolean accept(File f) {
                return f.isDirectory() || f.getName().toLowerCase().endsWith(".pdf");
            }
            public String getDescription() {
                return "Archivos PDF (*.pdf)";
            }
        });

        int userSelection = fileChooser.showSaveDialog(this);
        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            if (!fileToSave.getName().toLowerCase().endsWith(".pdf")) {
                fileToSave = new File(fileToSave.getAbsolutePath() + ".pdf");
            }

            try (FileOutputStream fos = new FileOutputStream(fileToSave)) {
                fos.write(pdfBytes);
                JOptionPane.showMessageDialog(this, 
                    "Ticket guardado correctamente.", 
                    "Éxito", 
                    JOptionPane.INFORMATION_MESSAGE);
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, 
                    "No se pudo guardar el archivo: " + ex.getMessage(), 
                    "Error", 
                    JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}