package Vista;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class RegistroView extends JDialog {
    // Paleta de colores consistente
    private final Color COLOR_PRIMARIO = new Color(231, 76, 60); // Rojo anaranjado
    private final Color COLOR_SECUNDARIO = new Color(241, 196, 15); // Amarillo dorado
    private final Color COLOR_FONDO = new Color(253, 245, 230); // Beige claro
    private final Color COLOR_TEXTO = Color.WHITE;
    private final Color COLOR_TEXTO_OSCURO = new Color(51, 51, 51);
    
    private JTextField txtAdminUser;
    private JPasswordField txtAdminPassword;
    private JTextField txtNuevoUsuario;
    private JPasswordField txtNuevoPassword;
    private JPasswordField txtConfirmPassword;
    private JTextField txtTelefono;
    private JButton btnRegistrar;
    private JButton btnCancelar;
    private JComboBox<String> comboRol;

    public RegistroView(JFrame parent) {
        super(parent, "REGISTRO DE USUARIOS - La Esquinita", true);
        setSize(500, 500);
        setLocationRelativeTo(parent);
        getContentPane().setBackground(COLOR_FONDO);
        
        // Panel principal con borde
        JPanel panelPrincipal = new JPanel(new BorderLayout(15, 15));
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panelPrincipal.setBackground(COLOR_FONDO);
        
        // Panel de título
        JLabel lblTitulo = new JLabel("Registro de Nuevo Usuario (Solo Admin)", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTitulo.setForeground(COLOR_PRIMARIO);
        panelPrincipal.add(lblTitulo, BorderLayout.NORTH);
        
        // Panel de contenido con pestañas
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.setBackground(COLOR_FONDO);
        tabbedPane.setFont(new Font("Segoe UI", Font.BOLD, 12));
        
        // Pestaña 1: Autenticación de Admin
        JPanel panelAdmin = crearPanelAutenticacion();
        tabbedPane.addTab("Autenticación Admin", panelAdmin);
        
        // Pestaña 2: Datos del Nuevo Usuario
        JPanel panelNuevoUsuario = crearPanelNuevoUsuario();
        tabbedPane.addTab("Datos del Usuario", panelNuevoUsuario);
        
        panelPrincipal.add(tabbedPane, BorderLayout.CENTER);
        
        // Panel de botones
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        panelBotones.setBackground(COLOR_FONDO);
        
        btnRegistrar = crearBotonEstilizado("Registrar", COLOR_PRIMARIO);
        btnCancelar = crearBotonEstilizado("Cancelar", new Color(142, 68, 173)); // Morado
        
        panelBotones.add(btnRegistrar);
        panelBotones.add(btnCancelar);
        
        panelPrincipal.add(panelBotones, BorderLayout.SOUTH);
        
        add(panelPrincipal);
    }
    
    private JPanel crearPanelAutenticacion() {
        JPanel panel = new JPanel(new GridLayout(4, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panel.setBackground(COLOR_FONDO);
        
        // Estilo para las etiquetas
        Font fontLabel = new Font("Segoe UI", Font.BOLD, 12);
        
        JLabel lblAdmin = new JLabel("Usuario Admin:");
        lblAdmin.setFont(fontLabel);
        lblAdmin.setForeground(COLOR_TEXTO_OSCURO);
        panel.add(lblAdmin);
        
        txtAdminUser = new JTextField();
        txtAdminUser.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COLOR_PRIMARIO, 1),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        panel.add(txtAdminUser);
        
        JLabel lblPass = new JLabel("Contraseña Admin:");
        lblPass.setFont(fontLabel);
        lblPass.setForeground(COLOR_TEXTO_OSCURO);
        panel.add(lblPass);
        
        txtAdminPassword = new JPasswordField();
        txtAdminPassword.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COLOR_PRIMARIO, 1),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        panel.add(txtAdminPassword);
        
        // Espaciador
        panel.add(new JLabel());
        panel.add(new JLabel());
        
        JLabel lblNota = new JLabel("<html><i>Debe ser administrador para registrar nuevos usuarios</i></html>");
        lblNota.setForeground(new Color(100, 100, 100));
        panel.add(lblNota);
        
        return panel;
    }
    
    private JPanel crearPanelNuevoUsuario() {
        JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panel.setBackground(COLOR_FONDO);
        
        Font fontLabel = new Font("Segoe UI", Font.BOLD, 12);
        
        JLabel lblUsuario = new JLabel("Nuevo Usuario:");
        lblUsuario.setFont(fontLabel);
        lblUsuario.setForeground(COLOR_TEXTO_OSCURO);
        panel.add(lblUsuario);
        
        txtNuevoUsuario = new JTextField();
        txtNuevoUsuario.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COLOR_PRIMARIO, 1),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        panel.add(txtNuevoUsuario);
        
        JLabel lblPass = new JLabel("Contraseña:");
        lblPass.setFont(fontLabel);
        lblPass.setForeground(COLOR_TEXTO_OSCURO);
        panel.add(lblPass);
        
        txtNuevoPassword = new JPasswordField();
        txtNuevoPassword.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COLOR_PRIMARIO, 1),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        panel.add(txtNuevoPassword);
        
        JLabel lblConfirm = new JLabel("Confirmar Contraseña:");
        lblConfirm.setFont(fontLabel);
        lblConfirm.setForeground(COLOR_TEXTO_OSCURO);
        panel.add(lblConfirm);
        
        txtConfirmPassword = new JPasswordField();
        txtConfirmPassword.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COLOR_PRIMARIO, 1),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        panel.add(txtConfirmPassword);
        
        JLabel lblTelefono = new JLabel("Teléfono:");
        lblTelefono.setFont(fontLabel);
        lblTelefono.setForeground(COLOR_TEXTO_OSCURO);
        panel.add(lblTelefono);
        
        txtTelefono = new JTextField();
        txtTelefono.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COLOR_PRIMARIO, 1),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        panel.add(txtTelefono);
        
        JLabel lblRol = new JLabel("Rol:");
        lblRol.setFont(fontLabel);
        lblRol.setForeground(COLOR_TEXTO_OSCURO);
        panel.add(lblRol);
        
        comboRol = new JComboBox<>(new String[]{"USUARIO", "ADMIN"});
        comboRol.setBackground(Color.WHITE);
        comboRol.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COLOR_PRIMARIO, 1),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        panel.add(comboRol);
        
        return panel;
    }
    
    private JButton crearBotonEstilizado(String texto, Color colorFondo) {
        JButton boton = new JButton(texto);
        boton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        boton.setBackground(colorFondo);
        boton.setForeground(COLOR_TEXTO);
        boton.setFocusPainted(false);
        boton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(colorFondo.darker(), 1),
            BorderFactory.createEmptyBorder(8, 20, 8, 20)
        ));
        
        boton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                boton.setBackground(colorFondo.brighter());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                boton.setBackground(colorFondo);
            }
        });
        
        return boton;
    }

    // Getters (se mantienen igual que antes)
    public String getAdminUser() { return txtAdminUser.getText().trim(); }
    public String getAdminPassword() { return new String(txtAdminPassword.getPassword()); }
    public String getNuevoUsuario() { return txtNuevoUsuario.getText().trim(); }
    public String getNuevoPassword() { return new String(txtNuevoPassword.getPassword()); }
    public String getConfirmPassword() { return new String(txtConfirmPassword.getPassword()); }
    public String getTelefono() { return txtTelefono.getText().trim(); }
    public String getRol() { return comboRol.getSelectedItem().toString(); }

    // Métodos para controladores (se mantienen igual que antes)
    public void addRegistrarListener(ActionListener listener) { btnRegistrar.addActionListener(listener); }
    public void addCancelarListener(ActionListener listener) { btnCancelar.addActionListener(listener); }
    public void mostrarMensaje(String mensaje) { JOptionPane.showMessageDialog(this, mensaje); }
    public void mostrarError(String mensaje) { JOptionPane.showMessageDialog(this, mensaje, "Error", JOptionPane.ERROR_MESSAGE); }
    public void cerrar() { dispose(); }
}