package Vista;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class ProveedoresView extends JFrame {
    public DefaultTableModel modeloTabla;
    private JTable tabla;
    private JButton btnNuevo;
    private JButton btnBuscar;
    private JButton btnEliminar;
    private JButton btnEditar;
    private JButton btnSalir;
    private JButton btnLimpiar; // Nuevo botón
    private JTextField txtBusqueda;
    
    // Colores basados en la paleta del fondo
    private final Color COLOR_PRIMARIO = new Color(231, 76, 60); // Rojo anaranjado
    private final Color COLOR_SECUNDARIO = new Color(241, 196, 15); // Amarillo dorado
    private final Color COLOR_FONDO = new Color(253, 245, 230); // Beige claro
    private final Color COLOR_TEXTO = Color.WHITE;
    private final Color COLOR_TEXTO_OSCURO = new Color(51, 51, 51);
    private final Color COLOR_AZUL = new Color(41, 128, 185); // Azul para el botón Limpiar
    
    public ProveedoresView() {
        setTitle("PROVEEDORES - La Esquinita");
        setSize(900, 650);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(COLOR_FONDO);
        
        JPanel panel = new JPanel(new BorderLayout(15, 15));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        panel.setBackground(COLOR_FONDO);

        // Panel superior con barra de búsqueda
        JPanel panelSuperior = new JPanel(new BorderLayout(10, 10));
        panelSuperior.setBackground(COLOR_FONDO);
        
        txtBusqueda = new JTextField();
        txtBusqueda.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtBusqueda.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COLOR_PRIMARIO, 1),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        txtBusqueda.setToolTipText("Buscar por ID, empresa o contacto");
        
        btnBuscar = crearBotonEstilizado("Buscar", COLOR_SECUNDARIO);
        btnBuscar.setPreferredSize(new Dimension(100, 35));
        
        btnLimpiar = crearBotonEstilizado("Limpiar", COLOR_AZUL); // Botón nuevo
        btnLimpiar.setPreferredSize(new Dimension(100, 35));
        
        JPanel panelBotonesBusqueda = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        panelBotonesBusqueda.setBackground(COLOR_FONDO);
        panelBotonesBusqueda.add(btnBuscar);
        panelBotonesBusqueda.add(btnLimpiar);
        
        JPanel panelBusqueda = new JPanel(new BorderLayout(5, 5));
        panelBusqueda.setBackground(COLOR_FONDO);
        panelBusqueda.add(txtBusqueda, BorderLayout.CENTER);
        panelBusqueda.add(panelBotonesBusqueda, BorderLayout.EAST);
        
        panelSuperior.add(panelBusqueda, BorderLayout.NORTH);
        panel.add(panelSuperior, BorderLayout.NORTH);
        
        String[] columnas = { "ID", "Empresa", "Contacto", "Numero de Telefono" };
        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        tabla = new JTable(modeloTabla);
        tabla.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        tabla.setRowHeight(25);
        tabla.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        tabla.getTableHeader().setBackground(COLOR_PRIMARIO);
        tabla.getTableHeader().setForeground(COLOR_TEXTO);
        
        JScrollPane scrollPane = new JScrollPane(tabla);
        scrollPane.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(COLOR_PRIMARIO, 1),
            "Lista de Proveedores",
            javax.swing.border.TitledBorder.LEFT,
            javax.swing.border.TitledBorder.TOP,
            new Font("Segoe UI", Font.BOLD, 12),
            COLOR_PRIMARIO
        ));
        
        panel.add(scrollPane, BorderLayout.CENTER);
        
        // Panel de botones
        JPanel panelBotones = new JPanel();
        panelBotones.setLayout(new BoxLayout(panelBotones, BoxLayout.X_AXIS));
        panelBotones.setBackground(COLOR_FONDO);
        panelBotones.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
        
        btnNuevo = crearBotonEstilizado("Nuevo", COLOR_PRIMARIO);
        btnEliminar = crearBotonEstilizado("Eliminar", new Color(192, 57, 43));
        btnEditar = crearBotonEstilizado("Editar", COLOR_AZUL);
        btnSalir = crearBotonEstilizado("Salir", new Color(142, 68, 173));
        
        Dimension tamanoBoton = new Dimension(120, 35);
        btnNuevo.setPreferredSize(tamanoBoton);
        btnEliminar.setPreferredSize(tamanoBoton);
        btnEditar.setPreferredSize(tamanoBoton);
        btnSalir.setPreferredSize(tamanoBoton);
        
        panelBotones.add(Box.createHorizontalGlue());
        panelBotones.add(btnNuevo);
        panelBotones.add(Box.createHorizontalStrut(10));
        panelBotones.add(btnEliminar);
        panelBotones.add(Box.createHorizontalStrut(10));
        panelBotones.add(btnEditar);
        panelBotones.add(Box.createHorizontalStrut(10));
        panelBotones.add(btnSalir);
        panelBotones.add(Box.createHorizontalGlue());
        
        panel.add(panelBotones, BorderLayout.SOUTH);
        
        add(panel);
    }
    
    public String getTextoBusqueda() {
        return txtBusqueda.getText().trim();
    }
    
    public void limpiarBusqueda() {
        txtBusqueda.setText("");
    }
    
    private JButton crearBotonEstilizado(String texto, Color colorFondo) {
        JButton boton = new JButton(texto);
        boton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        boton.setBackground(colorFondo);
        boton.setForeground(COLOR_TEXTO);
        boton.setFocusPainted(false);
        boton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(colorFondo.darker(), 1),
            BorderFactory.createEmptyBorder(5, 15, 5, 15)));
        
        // Efecto hover
        boton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                boton.setBackground(colorFondo.brighter());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                boton.setBackground(colorFondo);
            }
        });
        
        return boton;
    }
    
    public void cargarProveedores(Object[][] datos) {
        modeloTabla.setRowCount(0);
        for (Object[] fila : datos) {
            modeloTabla.addRow(fila);
        }
    }
    
    public DefaultTableModel getModeloTabla() {
        return modeloTabla;
    }
    
    public String obtenerBusqueda() {
        return txtBusqueda.getText().trim();
    }
    
    public int getFilaSeleccionada() {
        return tabla.getSelectedRow();
    }
    
    public void mostrarMensaje(String mensaje, String titulo) {
        JOptionPane.showMessageDialog(this, mensaje, titulo, JOptionPane.INFORMATION_MESSAGE);
    }
    
    public void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
    }
    
    public JButton getBtnNuevo() {
        return btnNuevo;
    }

    public JButton getBtnBuscar() {
        return btnBuscar;
    }
    
    public JButton getBtnEliminar() {
        return btnEliminar;
    }

    public JButton getBtnEditar() {
        return btnEditar;
    }

    public JButton getBtnSalir() {
        return btnSalir;
    }
    
    public JButton getBtnLimpiar() {
        return btnLimpiar;
    }
}