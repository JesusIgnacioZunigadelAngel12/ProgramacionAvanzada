package Vista;

import javax.swing.*;
import java.awt.*;

public class MainMenuView extends JFrame {
    private static MainMenuView instance;
    private String usuarioActivo;
    
    // Componentes del menú
    private JMenuBar menuBar;
    private JMenu menuVentas;
    private JMenu menuCatalogos;
    private JMenu menuOperaciones;
    private JMenu menuReportes;
    private JMenu menuSistema;
    
    // Items del menú (equivalentes a los botones anteriores)
    private JMenuItem itemPuntoVenta;
    private JMenuItem itemProveedores;
    private JMenuItem itemClientes;
    private JMenuItem itemProductos;
    private JMenuItem itemCategorias;
    private JMenuItem itemCaja;
    private JMenuItem itemUsuarios;
    private JMenuItem itemReportes;
    private JMenuItem itemSalir;
    
    // Panel para mostrar información del usuario
    private JPanel panelUsuario;
    private JLabel lblUsuario;

    private MainMenuView() {
        setTitle("¡BIENVENIDO! - SISTEMA DE PUNTO DE VENTA");
        setSize(900, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Crear la barra de menú
        crearBarraMenu();
        
        // Panel de información del usuario
        panelUsuario = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelUsuario.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 15));
        lblUsuario = new JLabel();
        lblUsuario.setFont(new Font("Arial", Font.BOLD, 12));
        panelUsuario.add(lblUsuario);

        // Panel principal (podrías agregar aquí un panel de bienvenida o dashboard)
        JPanel panelPrincipal = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                // Cargar la imagen (asegúrate de tener el archivo en la ruta correcta)
                ImageIcon imageIcon = new ImageIcon(getClass().getResource("/imagenes/fondomenu.jpg"));
                Image image = imageIcon.getImage();
                // Dibujar la imagen ajustada al tamaño del panel
                g.drawImage(image, 0, 0, getWidth(), getHeight(), this);
            }
        };
        panelPrincipal.setLayout(new BorderLayout());

        // Agregar componentes al frame
        add(panelPrincipal, BorderLayout.CENTER);
        add(panelUsuario, BorderLayout.SOUTH);
    }


    private void crearBarraMenu() {
        menuBar = new JMenuBar();
        
        // Menú Ventas
        menuVentas = new JMenu("Ventas");
        menuVentas.setMnemonic('V'); // Alt+V para acceder
        
        itemPuntoVenta = new JMenuItem("Punto de Venta");
        itemPuntoVenta.setAccelerator(KeyStroke.getKeyStroke('P', Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        menuVentas.add(itemPuntoVenta);
        
        menuBar.add(menuVentas);
        
        // Menú Catálogos
        menuCatalogos = new JMenu("Catálogos");
        menuCatalogos.setMnemonic('C');
        
        itemProveedores = new JMenuItem("Proveedores");
        itemClientes = new JMenuItem("Clientes");
        itemProductos = new JMenuItem("Productos");
        itemCategorias = new JMenuItem("Categorías");
        
        menuCatalogos.add(itemProveedores);
        menuCatalogos.add(itemClientes);
        menuCatalogos.addSeparator();
        menuCatalogos.add(itemProductos);
        menuCatalogos.add(itemCategorias);
        
        menuBar.add(menuCatalogos);
        
        // Menú Operaciones
        menuOperaciones = new JMenu("Operaciones");
        menuOperaciones.setMnemonic('O');
        
        itemCaja = new JMenuItem("Control de Caja");
        menuOperaciones.add(itemCaja);
        
        menuBar.add(menuOperaciones);
        
        // Menú Reportes
        menuReportes = new JMenu("Reportes");
        menuReportes.setMnemonic('R');
        
        itemReportes = new JMenuItem("Generar Reportes");
        menuReportes.add(itemReportes);
        
        menuBar.add(menuReportes);
        
        // Menú Sistema
        menuSistema = new JMenu("Sistema");
        menuSistema.setMnemonic('S');
        
        itemUsuarios = new JMenuItem("Usuarios");
        itemSalir = new JMenuItem("Salir");
        itemSalir.setAccelerator(KeyStroke.getKeyStroke('Q', Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        
        menuSistema.add(itemUsuarios);
        menuSistema.addSeparator();
        menuSistema.add(itemSalir);
        
        menuBar.add(menuSistema);
        
        // Establecer la barra de menú en el frame
        setJMenuBar(menuBar);
    }

    public static MainMenuView getInstance() {
        if (instance == null) {
            instance = new MainMenuView();
        }
        return instance;
    }
    public String getUsuarioActivo() {
        return usuarioActivo;
    }

    public void setUsuarioActivo(String usuario) {
        this.usuarioActivo = usuario;
        lblUsuario.setText("Usuario: " + usuario);
    }
    
    // Getters para los items del menú
    public JMenuItem getItemPuntoVenta() { return itemPuntoVenta; }
    public JMenuItem getItemProveedores() { return itemProveedores; }
    public JMenuItem getItemClientes() { return itemClientes; }
    public JMenuItem getItemProductos() { return itemProductos; }
    public JMenuItem getItemCategorias() { return itemCategorias; }
    public JMenuItem getItemCaja() { return itemCaja; }
    public JMenuItem getItemUsuarios() { return itemUsuarios; }
    public JMenuItem getItemReportes() { return itemReportes; }
    public JMenuItem getItemSalir() { return itemSalir; }
}