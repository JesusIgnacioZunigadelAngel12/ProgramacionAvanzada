/**
 * 
 */
/**
 * 
 */
module PuntoDeVenta_LaEsquinita {
	requires java.desktop;
	requires pdfbox.app;
	requires java.sql;
	
}