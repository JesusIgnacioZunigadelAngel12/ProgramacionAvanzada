/**
 * 
 */
/**
 * 
 */
module PuntoDeVenta_LaEsquinita {
    
	    requires java.desktop;  // Para Swing/JOptionPane
	    requires java.sql;
		requires pdfbox.app;
		
}